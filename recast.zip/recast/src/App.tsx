import { lazy, Suspense } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { isSupabaseConfigured } from "@/lib/supabase";
import { MarketingLayout } from "@/components/layout/MarketingLayout";
import { AppLayout } from "@/components/layout/AppLayout";
import { ProtectedRoute, PublicOnlyRoute } from "@/components/layout/guards";
import { SetupRequired } from "@/components/SetupRequired";
import { Skeleton } from "@/components/ui/misc";

const Home = lazy(() => import("@/pages/marketing/Home"));
const Pricing = lazy(() => import("@/pages/marketing/Pricing"));
const NotFound = lazy(() => import("@/pages/NotFound"));
const Login = lazy(() => import("@/pages/auth/Login"));
const Signup = lazy(() => import("@/pages/auth/Signup"));
const ForgotPassword = lazy(() => import("@/pages/auth/ForgotPassword"));
const ResetPassword = lazy(() => import("@/pages/auth/ResetPassword"));
const VerifyEmail = lazy(() => import("@/pages/auth/VerifyEmail"));
const Onboarding = lazy(() => import("@/pages/auth/Onboarding"));
const Overview = lazy(() => import("@/pages/app/Overview"));
const Create = lazy(() => import("@/pages/app/Create"));
const Projects = lazy(() => import("@/pages/app/Projects"));
const ProjectDetail = lazy(() => import("@/pages/app/ProjectDetail"));
const Library = lazy(() => import("@/pages/app/Library"));
const Brands = lazy(() => import("@/pages/app/Brands"));
const Calendar = lazy(() => import("@/pages/app/Calendar"));
const Usage = lazy(() => import("@/pages/app/Usage"));
const Settings = lazy(() => import("@/pages/app/Settings"));

function Fallback() {
  return (
    <div className="mx-auto max-w-5xl space-y-4 p-6">
      <Skeleton className="h-8 w-56" />
      <Skeleton className="h-40 w-full" />
      <Skeleton className="h-40 w-full" />
    </div>
  );
}

export default function App() {
  if (!isSupabaseConfigured) return <SetupRequired />;
  return (
    <Suspense fallback={<Fallback />}>
      <Routes>
        <Route element={<MarketingLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/pricing" element={<Pricing />} />
        </Route>

        <Route element={<PublicOnlyRoute />}>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
        </Route>
        <Route path="/verify-email" element={<VerifyEmail />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        <Route element={<ProtectedRoute />}>
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/app" element={<AppLayout />}>
            <Route index element={<Overview />} />
            <Route path="create" element={<Create />} />
            <Route path="projects" element={<Projects />} />
            <Route path="projects/:id" element={<ProjectDetail />} />
            <Route path="library" element={<Library />} />
            <Route path="brands" element={<Brands />} />
            <Route path="calendar" element={<Calendar />} />
            <Route path="usage" element={<Usage />} />
            <Route path="settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/app" replace />} />
          </Route>
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}

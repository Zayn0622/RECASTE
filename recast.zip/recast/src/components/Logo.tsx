import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={cn("h-8 w-8", className)} aria-hidden>
      <defs>
        <linearGradient id="recast-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8065F5" />
          <stop offset="1" stopColor="#52C7D8" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill="url(#recast-g)" />
      <path d="M20 46V18h14a9 9 0 0 1 2 17.8L44 46h-8l-6-9h-4v9z M26 25v7h8a3.5 3.5 0 0 0 0-7z" fill="#fff" fillRule="evenodd" />
    </svg>
  );
}

export function Logo({ to = "/", className, showText = true }: { to?: string; className?: string; showText?: boolean }) {
  return (
    <Link to={to} className={cn("flex items-center gap-2.5", className)}>
      <LogoMark />
      {showText && <span className="text-lg font-extrabold tracking-tight">RECAST</span>}
    </Link>
  );
}

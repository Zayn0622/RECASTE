import { Logo } from "./Logo";
import { Card } from "./ui/card";

export function SetupRequired() {
  return (
    <div className="hero-glow flex min-h-screen items-center justify-center p-6">
      <Card className="w-full max-w-xl p-8">
        <Logo />
        <h1 className="mt-6 text-2xl font-bold">Connect Supabase to get started</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          RECAST needs a Supabase project for auth, database and storage. Create a <code>.env</code> file in the project
          root with your project's public values:
        </p>
        <pre className="mt-4 overflow-x-auto rounded-xl bg-navy p-4 text-xs leading-relaxed text-white">
{`VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR-ANON-PUBLIC-KEY`}
        </pre>
        <p className="mt-4 text-sm text-muted-foreground">
          Then apply the SQL in <code>supabase/migrations</code> and deploy the Edge Functions. The full walkthrough is in
          the README. Never put your service-role key or AI keys in this file.
        </p>
      </Card>
    </div>
  );
}

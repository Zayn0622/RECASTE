import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import {
  CalendarDays, Coins, FolderKanban, LayoutDashboard, Library, Menu, Palette, Settings, Sparkles, X,
} from "lucide-react";
import { Logo } from "@/components/Logo";
import { Topbar } from "./Topbar";
import { cn } from "@/lib/utils";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { Skeleton } from "@/components/ui/misc";

const NAV = [
  { to: "/app", label: "Overview", icon: LayoutDashboard, end: true },
  { to: "/app/create", label: "Create Content", icon: Sparkles },
  { to: "/app/projects", label: "My Projects", icon: FolderKanban },
  { to: "/app/library", label: "Content Library", icon: Library },
  { to: "/app/brands", label: "Brand Voice", icon: Palette },
  { to: "/app/calendar", label: "Content Calendar", icon: CalendarDays },
  { to: "/app/usage", label: "Usage & Credits", icon: Coins },
  { to: "/app/settings", label: "Settings", icon: Settings },
];

function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav className="flex flex-col gap-1 px-3">
      {NAV.map((n) => (
        <NavLink
          key={n.to}
          to={n.to}
          end={n.end}
          onClick={onNavigate}
          className={({ isActive }) =>
            cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
              isActive
                ? "bg-brand-gradient text-white shadow-glow"
                : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
            )
          }
        >
          <n.icon className="h-4 w-4" />
          {n.label}
        </NavLink>
      ))}
    </nav>
  );
}

export function AppLayout() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { loading, current } = useWorkspace();

  useEffect(() => { setOpen(false); }, [location.pathname]);

  return (
    <div className="flex min-h-screen">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r bg-card lg:flex">
        <div className="flex h-16 items-center px-6"><Logo to="/app" /></div>
        <div className="flex-1 overflow-y-auto py-2"><SidebarNav /></div>
        <div className="m-3 rounded-2xl bg-navy p-4 text-white">
          <p className="text-xs font-semibold text-cyan">One Source. Endless Content.</p>
          <p className="mt-1 text-xs text-white/70">Paste an article and recast it for every platform.</p>
        </div>
      </aside>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-navy/60 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 flex h-full w-72 flex-col bg-card shadow-soft animate-in slide-in-from-left">
            <div className="flex h-16 items-center justify-between px-5">
              <Logo to="/app" />
              <button onClick={() => setOpen(false)} aria-label="Close menu" className="rounded-lg p-2 hover:bg-muted"><X className="h-5 w-5" /></button>
            </div>
            <div className="flex-1 overflow-y-auto py-2"><SidebarNav onNavigate={() => setOpen(false)} /></div>
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar menuButton={
          <button className="rounded-lg p-2 hover:bg-muted lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu className="h-5 w-5" />
          </button>
        } />
        <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">
          <div className="mx-auto w-full min-w-0 max-w-6xl">
            {loading ? (
              <div className="space-y-4"><Skeleton className="h-9 w-64" /><Skeleton className="h-40 w-full" /></div>
            ) : !current ? (
              <div className="rounded-2xl border border-dashed p-10 text-center">
                <p className="font-medium">No workspace found</p>
                <p className="mt-1 text-sm text-muted-foreground">Your account has no workspace yet. Make sure the database migration has been applied, then sign out and back in.</p>
              </div>
            ) : (
              <Outlet />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

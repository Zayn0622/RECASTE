import type { ReactNode } from "react";
import { Logo } from "@/components/Logo";
import { Sparkles } from "lucide-react";

export function AuthShell({ title, subtitle, children, footer }: { title: string; subtitle?: string; children: ReactNode; footer?: ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex flex-col justify-between p-6 sm:p-10">
        <Logo />
        <div className="mx-auto w-full max-w-sm py-10">
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{title}</h1>
          {subtitle && <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>}
          <div className="mt-8">{children}</div>
          {footer && <div className="mt-6 text-center text-sm text-muted-foreground">{footer}</div>}
        </div>
        <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} RECAST</p>
      </div>
      <div className="relative hidden overflow-hidden bg-navy lg:block">
        <div className="absolute -left-20 top-10 h-72 w-72 rounded-full bg-violet/40 blur-3xl" />
        <div className="absolute -right-10 bottom-10 h-72 w-72 rounded-full bg-cyan/30 blur-3xl" />
        <div className="relative flex h-full flex-col justify-center p-14 text-white">
          <Sparkles className="h-8 w-8 text-cyan" />
          <h2 className="mt-6 text-4xl font-extrabold leading-tight tracking-tight">One Source.<br />Endless Content.</h2>
          <p className="mt-4 max-w-md text-white/70">
            Turn a single article or transcript into Reels, Shorts, LinkedIn posts, carousels, threads and blog articles —
            written natively for each platform.
          </p>
        </div>
      </div>
    </div>
  );
}

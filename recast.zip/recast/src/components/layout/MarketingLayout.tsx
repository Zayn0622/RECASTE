import { useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { Menu, Moon, Sun, X } from "lucide-react";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useTheme } from "@/contexts/ThemeContext";

function scrollToId(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export function MarketingLayout() {
  const { session } = useAuth();
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const onHome = location.pathname === "/";

  const featureLink = onHome ? (
    <button onClick={() => { scrollToId("features"); setOpen(false); }} className="text-sm font-medium text-muted-foreground hover:text-foreground">
      Features
    </button>
  ) : (
    <Link to="/#features" className="text-sm font-medium text-muted-foreground hover:text-foreground">Features</Link>
  );

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur-lg">
        <div className="container flex h-16 items-center justify-between">
          <Logo />
          <nav className="hidden items-center gap-7 md:flex">
            {featureLink}
            <NavLink to="/pricing" className={({ isActive }) => `text-sm font-medium ${isActive ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
              Pricing
            </NavLink>
          </nav>
          <div className="hidden items-center gap-2 md:flex">
            <Button variant="ghost" size="icon" onClick={toggle} aria-label="Toggle theme">
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            {session ? (
              <Button asChild variant="brand"><Link to="/app">Open app</Link></Button>
            ) : (
              <>
                <Button asChild variant="ghost"><Link to="/login">Log in</Link></Button>
                <Button asChild variant="brand"><Link to="/signup">Start free</Link></Button>
              </>
            )}
          </div>
          <button className="rounded-lg p-2 md:hidden" onClick={() => setOpen((o) => !o)} aria-label="Menu">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
        {open && (
          <div className="container flex flex-col gap-3 border-t py-4 md:hidden">
            {onHome ? (
              <button className="text-left text-sm font-medium" onClick={() => { scrollToId("features"); setOpen(false); }}>Features</button>
            ) : (
              <Link to="/#features" onClick={() => setOpen(false)} className="text-sm font-medium">Features</Link>
            )}
            <Link to="/pricing" onClick={() => setOpen(false)} className="text-sm font-medium">Pricing</Link>
            <div className="flex gap-2 pt-2">
              <Button variant="outline" size="icon" onClick={toggle} aria-label="Toggle theme">
                {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
              {session ? (
                <Button asChild variant="brand" className="flex-1"><Link to="/app">Open app</Link></Button>
              ) : (
                <>
                  <Button asChild variant="outline" className="flex-1"><Link to="/login">Log in</Link></Button>
                  <Button asChild variant="brand" className="flex-1"><Link to="/signup">Start free</Link></Button>
                </>
              )}
            </div>
          </div>
        )}
      </header>

      <main><Outlet /></main>

      <footer className="border-t bg-card/50">
        <div className="container grid gap-8 py-12 md:grid-cols-4">
          <div className="md:col-span-2">
            <Logo />
            <p className="mt-3 max-w-sm text-sm text-muted-foreground">One Source. Endless Content. Turn a single idea into platform-ready content for every channel.</p>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold">Product</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/#features" className="hover:text-foreground">Features</Link></li>
              <li><Link to="/pricing" className="hover:text-foreground">Pricing</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold">Account</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/login" className="hover:text-foreground">Log in</Link></li>
              <li><Link to="/signup" className="hover:text-foreground">Sign up</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t py-5 text-center text-xs text-muted-foreground">© {new Date().getFullYear()} RECAST. All rights reserved.</div>
      </footer>
    </div>
  );
}

import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { Bell, Check, ChevronsUpDown, LogOut, Moon, Plus, Search, Settings as SettingsIcon, Sun } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { useTheme } from "@/contexts/ThemeContext";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Spinner } from "@/components/ui/misc";
import { errMessage, formatDate } from "@/lib/utils";
import type { Generation } from "@/types/db";

function WorkspaceSwitcher() {
  const { workspaces, current, setCurrent, refresh } = useWorkspace();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  async function create() {
    if (!name.trim()) return;
    setBusy(true);
    const { data, error } = await supabase.rpc("create_workspace", { p_name: name.trim() });
    setBusy(false);
    if (error) {
      toast.error(error.message.includes("workspace_limit") ? "You can own up to 5 workspaces." : errMessage(error));
      return;
    }
    await refresh();
    setCurrent(data as string);
    setOpen(false);
    setName("");
    toast.success("Workspace created");
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex max-w-[150px] items-center gap-2 rounded-xl border bg-card px-2.5 py-2 text-sm font-medium hover:bg-accent sm:max-w-[220px] sm:px-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-brand-gradient text-xs font-bold text-white">
              {current?.name?.[0]?.toUpperCase() ?? "W"}
            </span>
            <span className="truncate">{current?.name ?? "Workspace"}</span>
            <ChevronsUpDown className="h-3.5 w-3.5 shrink-0 opacity-60" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-64">
          <DropdownMenuLabel>Workspaces</DropdownMenuLabel>
          {workspaces.map((w) => (
            <DropdownMenuItem key={w.id} onSelect={() => setCurrent(w.id)}>
              <span className="flex-1 truncate">{w.name}</span>
              <span className="text-xs capitalize text-muted-foreground">{w.role}</span>
              {current?.id === w.id && <Check className="h-4 w-4 text-primary" />}
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={() => setOpen(true)}><Plus className="h-4 w-4" /> New workspace</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New workspace</DialogTitle>
            <DialogDescription>
              Use separate workspaces for clients or brands. New workspaces start with 0 credits until a plan is attached.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="ws-name">Name</Label>
            <Input id="ws-name" value={name} maxLength={80} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && create()} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={create} disabled={busy || !name.trim()}>{busy && <Spinner />} Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function Notifications() {
  const { current } = useWorkspace();
  const navigate = useNavigate();
  const [items, setItems] = useState<(Generation & { projects: { title: string } | null })[]>([]);
  const [loaded, setLoaded] = useState(false);

  async function load() {
    if (!current) return;
    const { data } = await supabase
      .from("generations")
      .select("*, projects(title)")
      .eq("workspace_id", current.id)
      .order("created_at", { ascending: false })
      .limit(8);
    setItems((data as any) ?? []);
    setLoaded(true);
  }

  return (
    <DropdownMenu onOpenChange={(o) => o && load()}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Notifications"><Bell className="h-4 w-4" /></Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel>Recent activity</DropdownMenuLabel>
        {!loaded && <div className="flex justify-center p-4"><Spinner /></div>}
        {loaded && items.length === 0 && <p className="px-3 py-4 text-center text-sm text-muted-foreground">Nothing yet. Generate some content to see activity here.</p>}
        {items.map((g) => (
          <DropdownMenuItem key={g.id} onSelect={() => navigate(`/app/projects/${g.project_id}`)} className="flex-col items-start gap-0.5">
            <span className="w-full truncate font-medium">{g.projects?.title ?? "Project"}</span>
            <span className="text-xs text-muted-foreground">
              {g.status === "completed" ? "Generation completed" : g.status === "failed" ? "Generation failed — credits refunded" : "Generation in progress"} · {formatDate(g.created_at)}
            </span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function Topbar({ menuButton }: { menuButton: ReactNode }) {
  const navigate = useNavigate();
  const { profile, user, signOut } = useAuth();
  const { theme, toggle } = useTheme();
  const [q, setQ] = useState("");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        document.getElementById("global-search")?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function onSearch(e: FormEvent) {
    e.preventDefault();
    navigate(`/app/projects${q.trim() ? `?q=${encodeURIComponent(q.trim())}` : ""}`);
  }

  const initials = (profile?.full_name ?? user?.email ?? "U").split(/\s+/).map((s) => s[0]).slice(0, 2).join("").toUpperCase();

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-1 border-b bg-background/80 px-3 backdrop-blur-lg sm:gap-3 sm:px-6">
      {menuButton}
      <WorkspaceSwitcher />
      <form onSubmit={onSearch} className="relative ml-1 hidden max-w-md flex-1 md:block">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input id="global-search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search projects…  ⌘K" className="pl-9" />
      </form>
      <div className="ml-auto flex items-center gap-1">
        <Button variant="ghost" size="icon" onClick={() => navigate(`/app/projects${q.trim() ? `?q=${encodeURIComponent(q.trim())}` : ""}`)} className="md:hidden" aria-label="Search projects">
          <Search className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" onClick={toggle} aria-label="Toggle theme" className="hidden sm:inline-flex">
          {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </Button>
        <Notifications />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="ml-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-gradient text-xs font-bold text-white" aria-label="Account menu">
              {initials}
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="truncate">{profile?.full_name ?? user?.email}</DropdownMenuLabel>
            <p className="truncate px-2.5 pb-1 text-xs text-muted-foreground">{user?.email}</p>
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => navigate("/app/settings")}><SettingsIcon className="h-4 w-4" /> Settings</DropdownMenuItem>
            <DropdownMenuItem onSelect={async () => { await signOut(); navigate("/"); }} destructive><LogOut className="h-4 w-4" /> Sign out</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}

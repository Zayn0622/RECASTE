import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Spinner } from "@/components/ui/misc";

function FullScreenLoader() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <Spinner className="h-6 w-6 text-primary" />
    </div>
  );
}

export function ProtectedRoute() {
  const { session, profile, loading, profileLoading, signOut } = useAuth();
  const location = useLocation();
  if (loading) return <FullScreenLoader />;
  if (!session) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  if (!session.user.email_confirmed_at && !session.user.confirmed_at) {
    return <Navigate to="/verify-email" replace />;
  }
  // Wait for the profile row to load before deciding on onboarding
  if (profileLoading) return <FullScreenLoader />;
  if (!profile) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 p-6 text-center">
        <p className="font-medium">We couldn't load your profile.</p>
        <p className="max-w-sm text-sm text-muted-foreground">
          This usually means the database migration hasn't been applied yet. Check the README, then try again.
        </p>
        <div className="flex gap-2">
          <button className="rounded-xl border px-4 py-2 text-sm" onClick={() => window.location.reload()}>Retry</button>
          <button className="rounded-xl border px-4 py-2 text-sm" onClick={() => signOut()}>Sign out</button>
        </div>
      </div>
    );
  }
  if (!profile.onboarded && location.pathname !== "/onboarding") return <Navigate to="/onboarding" replace />;
  return <Outlet />;
}

export function PublicOnlyRoute() {
  const { session, loading } = useAuth();
  if (loading) return <FullScreenLoader />;
  if (session) return <Navigate to="/app" replace />;
  return <Outlet />;
}

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const FAQS = [
  {
    q: "What can I turn into content?",
    a: "Paste an article or transcript, upload a PDF or TXT file, or add a YouTube link. For YouTube, RECAST only uses captions that are publicly available; if none can be accessed you'll be asked to paste or upload the transcript instead.",
  },
  {
    q: "Is the output just my source rewritten?",
    a: "No. RECAST first analyses your source, pulls out the key ideas and your audience goal, then writes each format natively — a Reel script is structured differently from a LinkedIn post or a blog article.",
  },
  {
    q: "How do credits work?",
    a: "Each generation uses credits based on how many formats you pick and how long your source is. Regenerating a single asset costs 1 credit. If a generation fails, the credits are automatically refunded.",
  },
  {
    q: "Can I edit what's generated?",
    a: "Yes. Every asset is an editable card. You can edit, save drafts, copy, export, or regenerate — and regenerating never overwrites your text until you confirm.",
  },
  {
    q: "Does RECAST post to my social accounts?",
    a: "Not in this version. The content calendar is a planning tool. Automatic publishing isn't available yet.",
  },
  {
    q: "Are payments live?",
    a: "Not yet. The prices shown are proposed launch pricing, and every account currently starts on the Free plan.",
  },
];

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="mx-auto max-w-3xl divide-y rounded-2xl border bg-card shadow-soft">
      {FAQS.map((f, i) => (
        <div key={f.q}>
          <button
            className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left font-medium"
            onClick={() => setOpen(open === i ? null : i)}
            aria-expanded={open === i}
          >
            {f.q}
            <ChevronDown className={cn("h-4 w-4 shrink-0 transition-transform", open === i && "rotate-180")} />
          </button>
          {open === i && <p className="px-5 pb-5 text-sm leading-relaxed text-muted-foreground">{f.a}</p>}
        </div>
      ))}
    </div>
  );
}

import { Link } from "react-router-dom";
import { Check } from "lucide-react";
import { PLANS } from "@/lib/config";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";

export function PricingCards() {
  const { session } = useAuth();
  return (
    <div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {PLANS.map((p) => (
          <div
            key={p.id}
            className={cn(
              "relative flex flex-col rounded-2xl border bg-card p-6 shadow-soft",
              p.highlight && "border-primary ring-1 ring-primary/40 shadow-glow",
            )}
          >
            {p.highlight && (
              <span className="absolute -top-3 left-6 rounded-full bg-brand-gradient px-3 py-0.5 text-xs font-semibold text-white">
                Most popular
              </span>
            )}
            <h3 className="text-lg font-semibold">{p.name}</h3>
            <p className="mt-1 min-h-[40px] text-sm text-muted-foreground">{p.blurb}</p>
            <div className="mt-4 flex items-baseline gap-1">
              <span className="text-4xl font-extrabold tracking-tight">₹{p.priceInr.toLocaleString("en-IN")}</span>
              <span className="text-sm text-muted-foreground">/month</span>
            </div>
            <ul className="mt-5 flex-1 space-y-2.5">
              {p.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
            <Button asChild variant={p.highlight ? "brand" : "outline"} className="mt-6 w-full">
              <Link to={session ? "/app/usage" : "/signup"}>
                {p.id === "free" ? (session ? "Your current plan" : "Start free") : session ? "View plan details" : `Get ${p.name}`}
              </Link>
            </Button>
          </div>
        ))}
      </div>
      <p className="mt-6 text-center text-xs text-muted-foreground">
        Proposed launch pricing — subject to change. Paid checkout is not active yet; every account starts on the Free plan.
      </p>
    </div>
  );
}

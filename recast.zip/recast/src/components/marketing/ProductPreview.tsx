import { useState } from "react";
import { PLATFORMS, type PlatformId } from "@/lib/platforms";
import { cn } from "@/lib/utils";
import { Sparkles } from "lucide-react";

// Illustrative sample only — clearly labelled as such. Not real output or metrics.
const SAMPLES: Partial<Record<PlatformId, { title: string; body: string }>> = {
  instagram_reels: {
    title: "Reel script · 30s",
    body: "HOOK (0–3s): Your best idea is dying in one format.\n\nBEAT 1: One long post can feed a whole week of content.\nBEAT 2: Pull the three sharpest ideas — each becomes its own piece.\nCTA: Save this and repurpose your next post.",
  },
  linkedin_post: {
    title: "LinkedIn post",
    body: "Most creators write once and publish once.\n\nThat's a waste.\n\nOne solid article contains a dozen angles. Here's how to find them:\n\n1. Highlight the claims people would argue about\n2. Turn each into a standalone post\n3. Rewrite for the platform, not the source",
  },
  x_thread: {
    title: "X thread · 4 posts",
    body: "1/ One article is not one piece of content. It's ten.\n\n2/ Start with the sharpest claim. That's your hook.\n\n3/ Give each idea its own post. Cut the rest.\n\n4/ End with a question so people reply.",
  },
  instagram_carousel: {
    title: "Carousel · 5 slides",
    body: "Slide 1 — Stop posting once.\nSlide 2 — Find the 3 big ideas.\nSlide 3 — Rewrite per platform.\nSlide 4 — Keep one voice.\nSlide 5 — Save & share.",
  },
};

const TABS: PlatformId[] = ["instagram_reels", "linkedin_post", "x_thread", "instagram_carousel"];

export function ProductPreview() {
  const [active, setActive] = useState<PlatformId>("instagram_reels");
  const sample = SAMPLES[active]!;
  return (
    <div className="mx-auto w-full max-w-4xl rounded-3xl border bg-card p-3 text-left shadow-glow">
      <div className="flex items-center gap-1.5 px-3 pb-3 pt-1">
        <span className="h-2.5 w-2.5 rounded-full bg-red-400/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber-400/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/80" />
        <span className="ml-3 rounded-md bg-muted px-2 py-0.5 text-[11px] text-muted-foreground">Sample preview</span>
      </div>
      <div className="grid gap-3 md:grid-cols-5">
        <div className="rounded-2xl border bg-background p-4 md:col-span-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Source</p>
          <p className="mt-2 text-sm font-medium">"Why one article should never be one post"</p>
          <p className="mt-2 line-clamp-6 text-sm leading-relaxed text-muted-foreground">
            Most writers publish a piece once and move on. But a good article holds several distinct ideas, each of which
            can reach a different audience on a different platform if it's reshaped to fit the way people read there…
          </p>
          <div className="mt-4 flex items-center gap-2 text-xs text-primary">
            <Sparkles className="h-3.5 w-3.5" /> Analyse → extract ideas → write per platform
          </div>
        </div>
        <div className="rounded-2xl border bg-background p-4 md:col-span-3">
          <div className="flex flex-wrap gap-1.5">
            {TABS.map((id) => {
              const p = PLATFORMS.find((x) => x.id === id)!;
              const Icon = p.icon;
              return (
                <button
                  key={id}
                  onClick={() => setActive(id)}
                  className={cn(
                    "flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition",
                    active === id ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:bg-muted",
                  )}
                >
                  <Icon className={cn("h-3.5 w-3.5", p.tint)} /> {p.short}
                </button>
              );
            })}
          </div>
          <p className="mt-4 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{sample.title}</p>
          <pre className="mt-2 whitespace-pre-wrap font-sans text-sm leading-relaxed">{sample.body}</pre>
        </div>
      </div>
    </div>
  );
}

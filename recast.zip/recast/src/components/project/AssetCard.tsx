import { useEffect, useState } from "react";
import { CalendarPlus, CheckCircle2, Copy, Download, Edit3, MoreHorizontal, RefreshCw, Save, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { PLATFORM_MAP } from "@/lib/platforms";
import { assetCopyText, exportAsset } from "@/lib/export";
import { copyToClipboard, errMessage, formatDate, wordCount } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Spinner } from "@/components/ui/misc";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ConfirmDialog, Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";
import type { ContentAsset } from "@/types/db";

function xPostStats(content: string) {
  const posts = content.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
  const longest = posts.reduce((m, p) => Math.max(m, p.length), 0);
  return { count: posts.length, longest, over: posts.filter((p) => p.length > 280).length };
}

export function AssetCard({
  asset, canEdit, regenerating, onChange, onDeleted, onRegenerate, onDirtyChange, showProject,
}: {
  asset: ContentAsset;
  canEdit: boolean;
  regenerating?: boolean;
  onChange: (a: ContentAsset) => void;
  onDeleted: (id: string) => void;
  onRegenerate?: (a: ContentAsset) => void;
  onDirtyChange?: (id: string, dirty: boolean) => void;
  showProject?: boolean;
}) {
  const { user } = useAuth();
  const info = PLATFORM_MAP[asset.platform];
  const Icon = info?.icon;
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(asset.title ?? "");
  const [content, setContent] = useState(asset.content);
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [calOpen, setCalOpen] = useState(false);

  // Reset local draft whenever the saved asset changes (e.g. after regenerate/replace)
  useEffect(() => { setTitle(asset.title ?? ""); setContent(asset.content); setEditing(false); }, [asset.id, asset.version]);

  const dirty = editing && (content !== asset.content || title !== (asset.title ?? ""));
  useEffect(() => { onDirtyChange?.(asset.id, dirty); }, [dirty]); // eslint-disable-line react-hooks/exhaustive-deps

  const text = editing ? content : asset.content;
  const isDemo = !!(asset.metadata as { demo?: boolean })?.demo;
  const hashtags = ((asset.metadata as { hashtags?: string[] })?.hashtags ?? []).filter(Boolean);
  const x = asset.platform === "x_thread" ? xPostStats(text) : null;

  async function save(status?: "draft" | "final") {
    if (!content.trim()) return toast.error("Content can't be empty.");
    setSaving(true);
    const patch: Partial<ContentAsset> = { title: title.trim() || null, content };
    if (status) patch.status = status;
    const { data, error } = await supabase.from("content_assets").update(patch).eq("id", asset.id).select("*").single();
    setSaving(false);
    if (error || !data) return toast.error(errMessage(error));
    onChange({ ...asset, ...(data as ContentAsset) });
    setEditing(false);
    toast.success("Saved");
  }

  async function toggleStatus() {
    const next = asset.status === "final" ? "draft" : "final";
    const { data, error } = await supabase.from("content_assets").update({ status: next }).eq("id", asset.id).select("*").single();
    if (error || !data) return toast.error(errMessage(error));
    onChange({ ...asset, ...(data as ContentAsset) });
    toast.success(next === "final" ? "Marked as final" : "Moved back to draft");
  }

  async function copy() {
    const ok = await copyToClipboard(assetCopyText({ content: text, metadata: asset.metadata }));
    ok ? toast.success("Copied to clipboard") : toast.error("Couldn't copy. Select the text and copy manually.");
  }

  async function remove() {
    setDeleting(true);
    const { error } = await supabase.from("content_assets").delete().eq("id", asset.id);
    setDeleting(false);
    if (error) return toast.error(errMessage(error));
    setConfirmDelete(false);
    onDeleted(asset.id);
    toast.success("Asset deleted");
  }

  return (
    <Card className="overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b bg-muted/40 px-4 py-3 sm:px-5">
        <div className="flex min-w-0 items-center gap-2.5">
          {Icon && <Icon className={`h-5 w-5 shrink-0 ${info.tint}`} />}
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{info?.label ?? asset.platform}</p>
            {showProject && asset.projects?.title && <p className="truncate text-xs text-muted-foreground">{asset.projects.title}</p>}
          </div>
          <Badge variant={asset.status === "final" ? "success" : "muted"}>{asset.status === "final" ? "Final" : "Draft"}</Badge>
          {isDemo && <Badge variant="warning">Demo</Badge>}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={copy}><Copy className="h-3.5 w-3.5" /> Copy</Button>
          {canEdit && !editing && <Button variant="ghost" size="sm" onClick={() => setEditing(true)}><Edit3 className="h-3.5 w-3.5" /> Edit</Button>}
          <DropdownMenu>
            <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" aria-label="More actions"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              {canEdit && onRegenerate && (
                <DropdownMenuItem disabled={regenerating} onSelect={() => onRegenerate(asset)}><RefreshCw className="h-4 w-4" /> Regenerate</DropdownMenuItem>
              )}
              {canEdit && <DropdownMenuItem onSelect={toggleStatus}><CheckCircle2 className="h-4 w-4" /> {asset.status === "final" ? "Move to draft" : "Mark as final"}</DropdownMenuItem>}
              {canEdit && <DropdownMenuItem onSelect={() => setCalOpen(true)}><CalendarPlus className="h-4 w-4" /> Add to calendar</DropdownMenuItem>}
              <DropdownMenuSeparator />
              <DropdownMenuLabel>Export</DropdownMenuLabel>
              <DropdownMenuItem onSelect={() => exportAsset({ ...asset, content: text }, "md")}><Download className="h-4 w-4" /> Markdown (.md)</DropdownMenuItem>
              <DropdownMenuItem onSelect={() => exportAsset({ ...asset, content: text }, "txt")}><Download className="h-4 w-4" /> Plain text (.txt)</DropdownMenuItem>
              {canEdit && <><DropdownMenuSeparator /><DropdownMenuItem destructive onSelect={() => setConfirmDelete(true)}><Trash2 className="h-4 w-4" /> Delete</DropdownMenuItem></>}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="space-y-3 p-4 sm:p-5">
        {regenerating ? (
          <div className="flex items-center gap-2 py-10 text-sm text-muted-foreground"><Spinner className="text-primary" /> Writing a fresh version…</div>
        ) : editing ? (
          <>
            <div className="space-y-1.5">
              <Label htmlFor={`t-${asset.id}`}>Title</Label>
              <Input id={`t-${asset.id}`} value={title} maxLength={300} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <Textarea value={content} onChange={(e) => setContent(e.target.value)} className="min-h-[260px] font-mono text-[13px] leading-relaxed" aria-label="Asset content" />
          </>
        ) : (
          <>
            {asset.title && <h3 className="text-base font-semibold">{asset.title}</h3>}
            <p className="whitespace-pre-wrap text-sm leading-relaxed">{asset.content}</p>
          </>
        )}

        {!regenerating && hashtags.length > 0 && !editing && (
          <div className="flex flex-wrap gap-1.5">
            {hashtags.map((h) => <span key={h} className="rounded-full bg-accent px-2 py-0.5 text-xs text-accent-foreground">{h.startsWith("#") ? h : `#${h}`}</span>)}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2 border-t pt-3 text-xs text-muted-foreground">
          <span>
            {text.length.toLocaleString()} characters · {wordCount(text).toLocaleString()} words
            {x && ` · ${x.count} posts (longest ${x.longest})`}
            {x && x.over > 0 && <span className="ml-1 font-medium text-destructive">· {x.over} over 280 chars</span>}
          </span>
          <span>v{asset.version} · {formatDate(asset.updated_at)}</span>
        </div>

        {editing && (
          <div className="flex flex-wrap justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => { setTitle(asset.title ?? ""); setContent(asset.content); setEditing(false); }} disabled={saving}><X className="h-3.5 w-3.5" /> Cancel</Button>
            <Button size="sm" onClick={() => save()} disabled={saving || !dirty}>{saving ? <Spinner /> : <Save className="h-3.5 w-3.5" />} Save draft</Button>
            <Button size="sm" variant="brand" onClick={() => save("final")} disabled={saving}>Save & mark final</Button>
          </div>
        )}
      </div>

      <ConfirmDialog
        open={confirmDelete} onOpenChange={setConfirmDelete} destructive loading={deleting}
        title="Delete this asset?" description="This permanently removes the asset and its edits. This can't be undone."
        confirmLabel="Delete" onConfirm={remove}
      />
      <AddToCalendar open={calOpen} onOpenChange={setCalOpen} asset={asset} userId={user?.id ?? ""} />
    </Card>
  );
}

function AddToCalendar({ open, onOpenChange, asset, userId }: { open: boolean; onOpenChange: (o: boolean) => void; asset: ContentAsset; userId: string }) {
  const info = PLATFORM_MAP[asset.platform];
  const [date, setDate] = useState(new Date(Date.now() + 86400000).toISOString().slice(0, 10));
  const [busy, setBusy] = useState(false);

  async function add() {
    if (!date) return;
    setBusy(true);
    const { error } = await supabase.from("calendar_items").insert({
      workspace_id: asset.workspace_id, created_by: userId, asset_id: asset.id,
      title: (asset.title ?? info?.label ?? "Content").slice(0, 200),
      platform: info?.calendarPlatform ?? "Social", scheduled_for: date,
    });
    setBusy(false);
    if (error) return toast.error(errMessage(error));
    toast.success("Added to your content calendar");
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add to content calendar</DialogTitle>
          <DialogDescription>Planning only — RECAST doesn't publish automatically.</DialogDescription>
        </DialogHeader>
        <div className="space-y-1.5">
          <Label htmlFor="cal-date">Planned date</Label>
          <Input id="cal-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={add} disabled={busy || !date}>{busy && <Spinner />} Add</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { Badge } from "@/components/ui/badge";
import type { Project } from "@/types/db";

const MAP: Record<Project["status"], { label: string; variant: "success" | "warning" | "danger" | "muted" }> = {
  ready: { label: "Ready", variant: "success" },
  generating: { label: "Generating", variant: "warning" },
  failed: { label: "Failed", variant: "danger" },
  draft: { label: "Draft", variant: "muted" },
};

export function StatusBadge({ status }: { status: Project["status"] }) {
  const m = MAP[status] ?? MAP.draft;
  return <Badge variant={m.variant}>{m.label}</Badge>;
}

import { useRef, useState } from "react";
import { ClipboardPaste, FileText, FileUp, Link2, Trash2, Youtube, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { invokeFunction, type TranscriptResult } from "@/lib/api";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress, Spinner } from "@/components/ui/misc";
import { cn, errMessage, wordCount } from "@/lib/utils";
import type { AppConfig } from "@/hooks/useAppConfig";

export interface UploadedFile {
  name: string;
  size: number;
  path: string;
  text?: string;        // available for TXT only (client-side preview)
  wordsGuess: number;
}

export interface SourceState {
  tab: "text" | "file" | "youtube";
  title: string;
  text: string;               // pasted text
  transcript: string;         // fetched / edited YouTube transcript
  file: UploadedFile | null;
  youtubeUrl: string;
}

export const EMPTY_SOURCE: SourceState = { tab: "text", title: "", text: "", transcript: "", file: null, youtubeUrl: "" };

export function sourceWords(s: SourceState): number {
  if (s.tab === "file") return s.file ? (s.file.text ? wordCount(s.file.text) : s.file.wordsGuess) : 0;
  if (s.tab === "youtube") return wordCount(s.transcript);
  return wordCount(s.text);
}

const ACCEPT = { "application/pdf": ".pdf", "text/plain": ".txt" } as const;

function safeName(name: string) {
  return name.replace(/[^A-Za-z0-9._-]+/g, "_").slice(-100) || "file";
}

function uploadWithProgress(path: string, file: File, token: string, onProgress: (p: number) => void): Promise<void> {
  return new Promise((resolve, reject) => {
    const url = `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/sources/${path.split("/").map(encodeURIComponent).join("/")}`;
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url);
    xhr.setRequestHeader("Authorization", `Bearer ${token}`);
    xhr.setRequestHeader("apikey", import.meta.env.VITE_SUPABASE_ANON_KEY as string);
    xhr.setRequestHeader("Content-Type", file.type || "application/octet-stream");
    xhr.setRequestHeader("x-upsert", "false");
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) return resolve();
      let msg = "Upload failed";
      try { msg = JSON.parse(xhr.responseText).message ?? msg; } catch { /* ignore */ }
      reject(new Error(msg));
    };
    xhr.onerror = () => reject(new Error("Network error during upload"));
    xhr.send(file);
  });
}

export function SourceStep({
  value, onChange, workspaceId, cfg,
}: {
  value: SourceState;
  onChange: (v: SourceState) => void;
  workspaceId: string;
  cfg: AppConfig;
}) {
  const set = (patch: Partial<SourceState>) => onChange({ ...value, ...patch });
  const fileInput = useRef<HTMLInputElement>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [fetching, setFetching] = useState(false);
  const [ytError, setYtError] = useState<string | null>(null);

  const words = wordCount(value.text);

  async function pasteFromClipboard() {
    try {
      const t = await navigator.clipboard.readText();
      if (!t.trim()) return toast.info("Your clipboard is empty.");
      set({ text: value.text ? `${value.text}\n\n${t}` : t });
    } catch {
      toast.error("Couldn't read the clipboard. Paste with Ctrl/⌘ + V instead.");
    }
  }

  async function handleFile(file: File | undefined) {
    if (!file) return;
    const lower = file.name.toLowerCase();
    const okType = lower.endsWith(".pdf") || lower.endsWith(".txt");
    if (!okType || (file.type && !Object.keys(ACCEPT).includes(file.type))) {
      return toast.error("Only PDF and TXT files are supported.");
    }
    if (file.size === 0) return toast.error("That file is empty.");
    if (file.size > cfg.maxFileMb * 1024 * 1024) return toast.error(`File is too large. The limit is ${cfg.maxFileMb} MB.`);

    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    if (!token) return toast.error("Your session expired. Please sign in again.");

    // remove any previously uploaded file
    if (value.file) await supabase.storage.from("sources").remove([value.file.path]);

    const path = `${workspaceId}/${crypto.randomUUID()}/${safeName(file.name)}`;
    setProgress(0);
    try {
      await uploadWithProgress(path, file, token, setProgress);
      const text = lower.endsWith(".txt") ? await file.text() : undefined;
      set({
        file: { name: file.name, size: file.size, path, text, wordsGuess: Math.round(file.size / 12) },
        title: value.title || file.name.replace(/\.[^.]+$/, ""),
      });
      toast.success("File uploaded");
    } catch (e) {
      toast.error(errMessage(e));
    } finally {
      setProgress(null);
    }
  }

  async function removeFile() {
    if (!value.file) return;
    await supabase.storage.from("sources").remove([value.file.path]);
    set({ file: null });
  }

  async function fetchTranscript() {
    setYtError(null);
    if (!value.youtubeUrl.trim()) return setYtError("Paste a YouTube link first.");
    setFetching(true);
    try {
      const r = await invokeFunction<TranscriptResult>("youtube-transcript", { url: value.youtubeUrl.trim() });
      set({ transcript: r.transcript, title: value.title || r.title || "YouTube video" });
      toast.success("Transcript loaded from public captions");
    } catch (e) {
      setYtError(errMessage(e));
    } finally {
      setFetching(false);
    }
  }

  return (
    <Tabs value={value.tab} onValueChange={(t) => set({ tab: t as SourceState["tab"] })}>
      <TabsList className="grid w-full grid-cols-3 sm:inline-flex sm:w-auto">
        <TabsTrigger value="text" className="sm:flex-none"><FileText className="h-4 w-4" /> Paste Text</TabsTrigger>
        <TabsTrigger value="file" className="sm:flex-none"><FileUp className="h-4 w-4" /> Upload File</TabsTrigger>
        <TabsTrigger value="youtube" className="sm:flex-none"><Youtube className="h-4 w-4" /> YouTube URL</TabsTrigger>
      </TabsList>

      <div className="mt-4 space-y-1.5">
        <Label htmlFor="src-title">Source title</Label>
        <Input id="src-title" value={value.title} maxLength={200} onChange={(e) => set({ title: e.target.value })} placeholder="e.g. Why one article should never be one post" />
      </div>

      <TabsContent value="text" className="space-y-2">
        <Textarea
          value={value.text}
          onChange={(e) => set({ text: e.target.value })}
          placeholder="Paste your article, blog post, newsletter or video transcript here…"
          className="min-h-[300px] resize-y leading-relaxed"
        />
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className={cn("text-xs", words > cfg.maxSourceWords ? "text-destructive" : "text-muted-foreground")}>
            {words.toLocaleString()} words {words > 0 && words < 30 && "· need at least 30"} {words > cfg.maxSourceWords && `· over the ${cfg.maxSourceWords.toLocaleString()} word limit`}
          </span>
          <div className="flex gap-2">
            <Button type="button" variant="outline" size="sm" onClick={pasteFromClipboard}><ClipboardPaste className="h-3.5 w-3.5" /> Paste</Button>
            <Button type="button" variant="outline" size="sm" disabled={!value.text} onClick={() => set({ text: "" })}><Trash2 className="h-3.5 w-3.5" /> Clear</Button>
          </div>
        </div>
      </TabsContent>

      <TabsContent value="file">
        {value.file ? (
          <div className="flex items-center justify-between gap-3 rounded-2xl border bg-card p-4">
            <div className="flex min-w-0 items-center gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-foreground"><FileText className="h-5 w-5" /></span>
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{value.file.name}</p>
                <p className="text-xs text-muted-foreground">
                  {(value.file.size / 1024).toFixed(0)} KB{value.file.text ? ` · ${wordCount(value.file.text).toLocaleString()} words` : " · text is read when you generate"}
                </p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={removeFile} aria-label="Remove file"><X className="h-4 w-4" /></Button>
          </div>
        ) : (
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files?.[0]); }}
            className={cn("flex flex-col items-center justify-center rounded-2xl border-2 border-dashed bg-card/50 px-6 py-14 text-center transition", dragOver && "border-primary bg-accent")}
          >
            {progress !== null ? (
              <div className="w-full max-w-xs space-y-2">
                <p className="text-sm font-medium">Uploading… {progress}%</p>
                <Progress value={progress} />
              </div>
            ) : (
              <>
                <FileUp className="h-8 w-8 text-primary" />
                <p className="mt-3 font-medium">Drag & drop a file here</p>
                <p className="mt-1 text-xs text-muted-foreground">PDF or TXT · up to {cfg.maxFileMb} MB · stored privately</p>
                <Button type="button" variant="outline" className="mt-4" onClick={() => fileInput.current?.click()}>Choose file</Button>
              </>
            )}
            <input ref={fileInput} type="file" accept=".pdf,.txt,application/pdf,text/plain" className="hidden"
              onChange={(e) => { handleFile(e.target.files?.[0]); e.target.value = ""; }} />
          </div>
        )}
        <p className="mt-2 text-xs text-muted-foreground">Scanned PDFs (images of text) can't be read — paste the text instead.</p>
      </TabsContent>

      <TabsContent value="youtube" className="space-y-3">
        <div className="flex flex-col gap-2 sm:flex-row">
          <div className="relative flex-1">
            <Link2 className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={value.youtubeUrl} onChange={(e) => set({ youtubeUrl: e.target.value })} placeholder="https://www.youtube.com/watch?v=…" className="pl-9" />
          </div>
          <Button type="button" onClick={fetchTranscript} disabled={fetching}>{fetching && <Spinner />} Get transcript</Button>
        </div>
        <p className="text-xs text-muted-foreground">
          RECAST only uses captions that are publicly available for the video. It never downloads video or audio.
        </p>
        {ytError && (
          <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-sm">
            <p>{ytError}</p>
            <button className="mt-1.5 font-medium text-primary underline-offset-4 hover:underline" onClick={() => set({ tab: "text" })}>
              Paste the transcript instead →
            </button>
          </div>
        )}
        {value.transcript && (
          <div className="space-y-2">
            <Label>Transcript (you can edit it)</Label>
            <Textarea value={value.transcript} onChange={(e) => set({ transcript: e.target.value })} className="min-h-[220px]" />
            <p className="text-xs text-muted-foreground">{wordCount(value.transcript).toLocaleString()} words</p>
          </div>
        )}
      </TabsContent>
    </Tabs>
  );
}

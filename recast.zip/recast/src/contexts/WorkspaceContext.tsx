import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "./AuthContext";
import type { Role, WorkspaceWithRole } from "@/types/db";

interface WsState {
  workspaces: WorkspaceWithRole[];
  current: WorkspaceWithRole | null;
  loading: boolean;
  canEdit: boolean;
  setCurrent: (id: string) => void;
  refresh: () => Promise<void>;
}

const Ctx = createContext<WsState | null>(null);
const KEY = "recast-workspace";

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const { user, profile } = useAuth();
  const [workspaces, setWorkspaces] = useState<WorkspaceWithRole[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(() => {
    try { return localStorage.getItem(KEY); } catch { return null; }
  });
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!user) { setWorkspaces([]); setLoading(false); return; }
    const { data, error } = await supabase
      .from("workspace_members")
      .select("role, workspaces(*)")
      .eq("user_id", user.id);
    if (error) { setLoading(false); return; }
    const list: WorkspaceWithRole[] = (data ?? [])
      .filter((r: any) => r.workspaces)
      .map((r: any) => ({ ...r.workspaces, role: r.role as Role }));
    setWorkspaces(list);
    setLoading(false);
  }, [user]);

  useEffect(() => { refresh(); }, [refresh, profile?.default_workspace_id]);

  const current =
    workspaces.find((w) => w.id === currentId) ??
    workspaces.find((w) => w.id === profile?.default_workspace_id) ??
    workspaces[0] ??
    null;

  const setCurrent = (id: string) => {
    setCurrentId(id);
    try { localStorage.setItem(KEY, id); } catch { /* ignore */ }
  };

  return (
    <Ctx.Provider
      value={{ workspaces, current, loading, canEdit: !!current && current.role !== "viewer", setCurrent, refresh }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useWorkspace() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useWorkspace must be used inside WorkspaceProvider");
  return c;
}

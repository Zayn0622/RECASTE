import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { CREDIT_COSTS, LONG_SOURCE_WORDS, MAX_SOURCE_WORDS, MAX_FILE_MB } from "@/lib/config";

export interface AppConfig {
  costs: { basic: number; multi: number; longTranscript: number; regeneration: number };
  longSourceWords: number;
  maxSourceWords: number;
  maxFileMb: number;
}

const DEFAULTS: AppConfig = {
  costs: { ...CREDIT_COSTS },
  longSourceWords: LONG_SOURCE_WORDS,
  maxSourceWords: MAX_SOURCE_WORDS,
  maxFileMb: MAX_FILE_MB,
};

let cache: AppConfig | null = null;

/** Reads server-side configuration (credit costs, limits) so the UI estimate matches the server. */
export function useAppConfig(): AppConfig {
  const [cfg, setCfg] = useState<AppConfig>(cache ?? DEFAULTS);
  useEffect(() => {
    if (cache) return;
    supabase.from("app_config").select("key, value").then(({ data }) => {
      if (!data) return;
      const map = Object.fromEntries(data.map((r: any) => [r.key, r.value]));
      const c = map.credit_costs ?? {};
      const l = map.limits ?? {};
      cache = {
        costs: {
          basic: c.basic ?? DEFAULTS.costs.basic,
          multi: c.multi ?? DEFAULTS.costs.multi,
          longTranscript: c.long_transcript ?? DEFAULTS.costs.longTranscript,
          regeneration: c.regeneration ?? DEFAULTS.costs.regeneration,
        },
        longSourceWords: l.long_source_words ?? DEFAULTS.longSourceWords,
        maxSourceWords: l.max_source_words ?? DEFAULTS.maxSourceWords,
        maxFileMb: l.max_file_mb ?? DEFAULTS.maxFileMb,
      };
      setCfg(cache);
    });
  }, []);
  return cfg;
}

export function estimateCreditsWith(cfg: AppConfig, platformCount: number, sourceWords: number): number {
  if (platformCount <= 0) return 0;
  if (sourceWords > cfg.longSourceWords) return cfg.costs.longTranscript;
  return platformCount >= 2 ? cfg.costs.multi : cfg.costs.basic;
}

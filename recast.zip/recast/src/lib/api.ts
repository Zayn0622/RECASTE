import { supabase } from "./supabase";

export class ApiError extends Error {
  constructor(public code: string, message: string, public status?: number) {
    super(message);
  }
}

/** Calls a Supabase Edge Function and converts failures into ApiError with a user-safe message. */
export async function invokeFunction<T>(name: string, body: unknown): Promise<T> {
  const { data, error } = await supabase.functions.invoke(name, { body: body as Record<string, unknown> });
  if (error) {
    let payload: { code?: string; message?: string } | null = null;
    const ctx = (error as { context?: Response }).context;
    if (ctx && typeof ctx.json === "function") {
      try { payload = await ctx.json(); } catch { /* not JSON */ }
    }
    if (payload?.message) throw new ApiError(payload.code ?? "error", payload.message, ctx?.status);
    if (ctx?.status === 404) {
      throw new ApiError("not_deployed", `The "${name}" Edge Function isn't deployed yet. See the README for deployment steps.`, 404);
    }
    throw new ApiError("network_error", "We couldn't reach the server. Check your connection and try again.");
  }
  if (data && (data as { ok?: boolean }).ok === false) {
    const d = data as { code?: string; message?: string };
    throw new ApiError(d.code ?? "error", d.message ?? "Request failed");
  }
  return data as T;
}

export interface AiStatus { ok: true; ai_configured: boolean; demo_mode: boolean; provider: string | null }
export interface GenerateResult {
  ok: true; generation_id: string; assets_count: number; credits_charged: number; balance: number | null; demo: boolean;
}
export interface RegenResult {
  ok: true; credits_charged: number; balance: number | null; demo: boolean;
  proposal: { title: string; content: string; metadata: Record<string, unknown> };
}
export interface TranscriptResult { ok: true; video_id: string; title: string | null; transcript: string; source: string }

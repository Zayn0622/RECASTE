// Central, configurable product settings. Prices and credit costs here are
// PROPOSED values. The authoritative credit costs live on the server
// (supabase/functions/_shared/config.ts) — keep both in sync.

export type PlanId = "free" | "creator" | "pro" | "agency";

export interface Plan {
  id: PlanId;
  name: string;
  priceInr: number;
  credits: number;
  blurb: string;
  features: string[];
  highlight?: boolean;
}

export const PLANS: Plan[] = [
  {
    id: "free", name: "Free", priceInr: 0, credits: 10,
    blurb: "Try RECAST on your first few ideas.",
    features: ["10 credits / month", "All content formats", "1 brand voice", "Project library"],
  },
  {
    id: "creator", name: "Creator", priceInr: 499, credits: 150,
    blurb: "For solo creators publishing weekly.",
    features: ["150 credits / month", "All content formats", "3 brand voices", "Content calendar", "Export to Markdown"],
  },
  {
    id: "pro", name: "Pro", priceInr: 999, credits: 400, highlight: true,
    blurb: "For full-time creators and freelancers.",
    features: ["400 credits / month", "Long transcript support", "10 brand voices", "Content calendar", "Priority generation"],
  },
  {
    id: "agency", name: "Agency", priceInr: 2499, credits: 1500,
    blurb: "For teams managing multiple clients.",
    features: ["1,500 credits / month", "Unlimited brand voices", "Team workspaces & roles", "Client-ready exports", "Priority support"],
  },
];

export const CREDIT_COSTS = {
  basic: 1,        // single platform, short source
  multi: 3,        // 2+ platforms
  longTranscript: 5, // source > LONG_SOURCE_WORDS
  regeneration: 1,
} as const;

export const LONG_SOURCE_WORDS = 3000;
export const MAX_SOURCE_WORDS = 20000;
export const MAX_FILE_MB = 10;

export function estimateCredits(platformCount: number, sourceWords: number): number {
  if (platformCount <= 0) return 0;
  if (sourceWords > LONG_SOURCE_WORDS) return CREDIT_COSTS.longTranscript;
  return platformCount >= 2 ? CREDIT_COSTS.multi : CREDIT_COSTS.basic;
}

export const TONES = ["Professional", "Conversational", "Educational", "Funny", "Inspirational", "Persuasive", "Storytelling"] as const;
export const GOALS = ["Grow audience", "Generate leads", "Educate", "Drive sales", "Build authority", "Entertain", "Drive traffic"] as const;
export const LENGTHS = ["Short", "Medium", "Long"] as const;
export const LANGUAGES = ["English", "Hindi", "Hinglish", "Spanish", "French", "German", "Portuguese", "Arabic", "Bengali", "Tamil", "Marathi"] as const;

import { PLATFORM_MAP } from "./platforms";
import { downloadText, slugify } from "./utils";
import type { ContentAsset } from "@/types/db";

function hashtagsOf(a: Pick<ContentAsset, "metadata">): string[] {
  const h = (a.metadata as { hashtags?: unknown })?.hashtags;
  return Array.isArray(h) ? h.filter((x): x is string => typeof x === "string") : [];
}

/** Text placed on the clipboard: body plus hashtags (if they aren't already in the body). */
export function assetCopyText(a: Pick<ContentAsset, "content" | "metadata">): string {
  const tags = hashtagsOf(a);
  if (!tags.length || a.content.includes(tags[0])) return a.content;
  return `${a.content}\n\n${tags.join(" ")}`;
}

export function assetToMarkdown(a: ContentAsset): string {
  const label = PLATFORM_MAP[a.platform]?.label ?? a.platform;
  return `## ${label}${a.title ? ` — ${a.title}` : ""}\n\n${assetCopyText(a)}\n`;
}

export function projectToMarkdown(title: string, assets: ContentAsset[]): string {
  return `# ${title}\n\n` + assets.map(assetToMarkdown).join("\n---\n\n");
}

export function exportAsset(a: ContentAsset, format: "md" | "txt") {
  const base = slugify(`${PLATFORM_MAP[a.platform]?.short ?? a.platform}-${a.title ?? ""}`);
  if (format === "md") downloadText(`${base}.md`, assetToMarkdown(a), "text/markdown");
  else downloadText(`${base}.txt`, assetCopyText(a));
}

export function exportProject(title: string, assets: ContentAsset[]) {
  downloadText(`${slugify(title)}.md`, projectToMarkdown(title, assets), "text/markdown");
}

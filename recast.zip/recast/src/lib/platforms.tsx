import { Instagram, Youtube, Linkedin, GalleryHorizontal, Twitter, FileText, Hash, type LucideIcon } from "lucide-react";

export type PlatformId =
  | "instagram_reels" | "youtube_shorts" | "linkedin_post" | "instagram_carousel"
  | "x_thread" | "blog_article" | "captions";

export interface PlatformInfo {
  id: PlatformId;
  label: string;
  short: string;
  description: string;
  icon: LucideIcon;
  tint: string; // tailwind text color class
  calendarPlatform: string;
}

export const PLATFORMS: PlatformInfo[] = [
  { id: "instagram_reels", label: "Instagram Reels", short: "Reels", description: "Hook-first short video scripts with on-screen text.", icon: Instagram, tint: "text-pink-500", calendarPlatform: "Instagram" },
  { id: "youtube_shorts", label: "YouTube Shorts", short: "Shorts", description: "Punchy vertical scripts built for retention.", icon: Youtube, tint: "text-red-500", calendarPlatform: "YouTube" },
  { id: "linkedin_post", label: "LinkedIn Post", short: "LinkedIn", description: "Professional storytelling with a strong opener.", icon: Linkedin, tint: "text-sky-600", calendarPlatform: "LinkedIn" },
  { id: "instagram_carousel", label: "Instagram Carousel", short: "Carousel", description: "Slide-by-slide copy plus caption.", icon: GalleryHorizontal, tint: "text-fuchsia-500", calendarPlatform: "Instagram" },
  { id: "x_thread", label: "X Thread", short: "X Thread", description: "Numbered thread with a scroll-stopping first post.", icon: Twitter, tint: "text-foreground", calendarPlatform: "X" },
  { id: "blog_article", label: "Blog Article", short: "Blog", description: "SEO-aware long-form article with headings.", icon: FileText, tint: "text-emerald-500", calendarPlatform: "Blog" },
  { id: "captions", label: "Social Media Captions", short: "Captions", description: "Captions, hooks, headlines and hashtags.", icon: Hash, tint: "text-amber-500", calendarPlatform: "Social" },
];

export const PLATFORM_MAP: Record<string, PlatformInfo> = Object.fromEntries(PLATFORMS.map((p) => [p.id, p]));

export const CALENDAR_PLATFORMS = ["Instagram", "YouTube", "LinkedIn", "X", "Blog", "Social"] as const;

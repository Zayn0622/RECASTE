import { useCallback, useEffect, useState } from "react";
import { Palette, Pencil, Plus, Star, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { TONES } from "@/lib/config";
import { errMessage } from "@/lib/utils";
import { PageHeader, EmptyState, ErrorState, Skeleton, Spinner } from "@/components/ui/misc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ConfirmDialog, Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { Brand } from "@/types/db";

interface Form {
  name: string; description: string; target_audience: string; preferred_tone: string;
  writing_style: string; words_to_use: string[]; words_to_avoid: string[]; instructions: string;
}
const EMPTY: Form = {
  name: "", description: "", target_audience: "", preferred_tone: "Conversational",
  writing_style: "", words_to_use: [], words_to_avoid: [], instructions: "",
};

function TagInput({ label, value, onChange, placeholder }: { label: string; value: string[]; onChange: (v: string[]) => void; placeholder: string }) {
  const [draft, setDraft] = useState("");
  function add() {
    const items = draft.split(",").map((s) => s.trim()).filter(Boolean);
    if (!items.length) return;
    onChange(Array.from(new Set([...value, ...items])).slice(0, 40));
    setDraft("");
  }
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <div className="flex gap-2">
        <Input value={draft} maxLength={60} onChange={(e) => setDraft(e.target.value)} placeholder={placeholder}
          onKeyDown={(e) => { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); add(); } }} />
        <Button type="button" variant="outline" onClick={add}>Add</Button>
      </div>
      {value.length > 0 && (
        <div className="flex flex-wrap gap-1.5 pt-1">
          {value.map((w) => (
            <span key={w} className="inline-flex items-center gap-1 rounded-full bg-accent px-2.5 py-1 text-xs text-accent-foreground">
              {w}
              <button type="button" aria-label={`Remove ${w}`} onClick={() => onChange(value.filter((x) => x !== w))}><X className="h-3 w-3" /></button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Brands() {
  const { user } = useAuth();
  const { current, canEdit } = useWorkspace();
  const [brands, setBrands] = useState<Brand[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Brand | null>(null);
  const [form, setForm] = useState<Form>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Brand | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    if (!current) return;
    setError(null);
    const { data, error } = await supabase.from("brands").select("*").eq("workspace_id", current.id).order("created_at");
    if (error) return setError(error.message);
    setBrands((data as Brand[]) ?? []);
  }, [current?.id]);

  useEffect(() => { setBrands(null); load(); }, [load]);

  function openNew() { setEditing(null); setForm(EMPTY); setOpen(true); }
  function openEdit(b: Brand) {
    setEditing(b);
    setForm({
      name: b.name, description: b.description ?? "", target_audience: b.target_audience ?? "",
      preferred_tone: b.preferred_tone ?? "Conversational", writing_style: b.writing_style ?? "",
      words_to_use: b.words_to_use ?? [], words_to_avoid: b.words_to_avoid ?? [], instructions: b.instructions ?? "",
    });
    setOpen(true);
  }

  async function save() {
    if (!current || !user) return;
    if (!form.name.trim()) return toast.error("Give your brand a name.");
    setSaving(true);
    const payload = {
      name: form.name.trim(), description: form.description.trim() || null, target_audience: form.target_audience.trim() || null,
      preferred_tone: form.preferred_tone, writing_style: form.writing_style.trim() || null,
      words_to_use: form.words_to_use, words_to_avoid: form.words_to_avoid, instructions: form.instructions.trim() || null,
    };
    const res = editing
      ? await supabase.from("brands").update(payload).eq("id", editing.id)
      : await supabase.from("brands").insert({ ...payload, workspace_id: current.id, created_by: user.id, is_default: (brands?.length ?? 0) === 0 });
    setSaving(false);
    if (res.error) return toast.error(errMessage(res.error));
    toast.success(editing ? "Brand voice updated" : "Brand voice created");
    setOpen(false);
    load();
  }

  async function makeDefault(b: Brand) {
    // Only one default per workspace (unique partial index) — clear the old one first
    const prev = brands?.find((x) => x.is_default);
    if (prev) {
      const { error } = await supabase.from("brands").update({ is_default: false }).eq("id", prev.id);
      if (error) return toast.error(errMessage(error));
    }
    const { error } = await supabase.from("brands").update({ is_default: true }).eq("id", b.id);
    if (error) return toast.error(errMessage(error));
    toast.success(`"${b.name}" will be pre-selected when you create content`);
    load();
  }

  async function remove() {
    if (!deleteTarget) return;
    setDeleting(true);
    const { error } = await supabase.from("brands").delete().eq("id", deleteTarget.id);
    setDeleting(false);
    if (error) return toast.error(errMessage(error));
    setDeleteTarget(null);
    toast.success("Brand voice deleted");
    load();
  }

  return (
    <div className="animate-fade-up">
      <PageHeader title="Brand Voice" description="Save how your brand sounds. Pick a profile in the Create step and RECAST will write in it."
        actions={canEdit && <Button variant="brand" onClick={openNew}><Plus className="h-4 w-4" /> New brand voice</Button>} />

      {error ? <ErrorState message={error} onRetry={load} /> : brands === null ? (
        <div className="grid gap-4 md:grid-cols-2">{[0, 1].map((i) => <Skeleton key={i} className="h-48" />)}</div>
      ) : brands.length === 0 ? (
        <EmptyState icon={Palette} title="No brand voices yet" description="Create a profile with your tone, style and preferred words so every generation sounds like you."
          action={canEdit ? <Button variant="brand" onClick={openNew}>Create brand voice</Button> : undefined} />
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {brands.map((b) => (
            <Card key={b.id}>
              <CardContent className="space-y-3 p-5 sm:p-6">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <h3 className="flex items-center gap-2 font-semibold"><span className="truncate">{b.name}</span>{b.is_default && <Badge>Default</Badge>}</h3>
                    {b.preferred_tone && <p className="text-xs text-muted-foreground">Tone: {b.preferred_tone}</p>}
                  </div>
                  {canEdit && (
                    <div className="flex shrink-0">
                      {!b.is_default && <Button variant="ghost" size="icon" aria-label="Set as default" title="Set as default" onClick={() => makeDefault(b)}><Star className="h-4 w-4" /></Button>}
                      <Button variant="ghost" size="icon" aria-label="Edit" onClick={() => openEdit(b)}><Pencil className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" aria-label="Delete" onClick={() => setDeleteTarget(b)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    </div>
                  )}
                </div>
                {b.description && <p className="line-clamp-3 text-sm text-muted-foreground">{b.description}</p>}
                {b.target_audience && <p className="text-xs"><b>Audience:</b> {b.target_audience}</p>}
                <div className="flex flex-wrap gap-1.5">
                  {b.words_to_use.slice(0, 6).map((w) => <Badge key={`u${w}`} variant="success">{w}</Badge>)}
                  {b.words_to_avoid.slice(0, 6).map((w) => <Badge key={`a${w}`} variant="danger">{w}</Badge>)}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={(o) => !saving && setOpen(o)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit brand voice" : "New brand voice"}</DialogTitle>
            <DialogDescription>These details are sent to the AI with every generation that uses this profile.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5"><Label htmlFor="bn">Brand name *</Label><Input id="bn" maxLength={80} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="space-y-1.5"><Label htmlFor="bd">Brand description</Label><Textarea id="bd" maxLength={2000} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What you do and what you stand for" /></div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5"><Label htmlFor="ba">Target audience</Label><Input id="ba" maxLength={500} value={form.target_audience} onChange={(e) => setForm({ ...form, target_audience: e.target.value })} /></div>
              <div className="space-y-1.5">
                <Label>Preferred tone</Label>
                <Select value={form.preferred_tone} onValueChange={(v) => setForm({ ...form, preferred_tone: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TONES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5"><Label htmlFor="bw">Writing style</Label><Textarea id="bw" maxLength={1000} value={form.writing_style} onChange={(e) => setForm({ ...form, writing_style: e.target.value })} placeholder="e.g. Short sentences. Plain language. Light humour." /></div>
            <TagInput label="Words to use" value={form.words_to_use} onChange={(v) => setForm({ ...form, words_to_use: v })} placeholder="Type a word, press Enter" />
            <TagInput label="Words to avoid" value={form.words_to_avoid} onChange={(v) => setForm({ ...form, words_to_avoid: v })} placeholder="Type a word, press Enter" />
            <div className="space-y-1.5"><Label htmlFor="bi">Brand-specific instructions</Label><Textarea id="bi" maxLength={2000} value={form.instructions} onChange={(e) => setForm({ ...form, instructions: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>Cancel</Button>
            <Button variant="brand" onClick={save} disabled={saving}>{saving && <Spinner />} {editing ? "Save changes" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)} destructive loading={deleting}
        title={`Delete "${deleteTarget?.name ?? ""}"?`} description="Past content is unaffected. This brand voice will no longer be available for new generations."
        confirmLabel="Delete" onConfirm={remove} />
    </div>
  );
}

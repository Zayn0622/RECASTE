import { useCallback, useEffect, useMemo, useState } from "react";
import {
  addDays, addMonths, addWeeks, endOfMonth, endOfWeek, format, isSameMonth, isToday, startOfMonth, startOfWeek, subMonths, subWeeks,
} from "date-fns";
import { CalendarDays, ChevronLeft, ChevronRight, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { CALENDAR_PLATFORMS } from "@/lib/platforms";
import { cn, errMessage } from "@/lib/utils";
import { PageHeader, ErrorState, Spinner } from "@/components/ui/misc";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ConfirmDialog, Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { CalendarItem, ContentAsset } from "@/types/db";

const DOT: Record<string, string> = {
  Instagram: "bg-pink-500", YouTube: "bg-red-500", LinkedIn: "bg-sky-600", X: "bg-foreground", Blog: "bg-emerald-500", Social: "bg-amber-500",
};
const ymd = (d: Date) => format(d, "yyyy-MM-dd");

interface Draft { id?: string; title: string; platform: string; date: string; notes: string; status: "planned" | "done"; asset_id: string }

export default function Calendar() {
  const { user } = useAuth();
  const { current, canEdit } = useWorkspace();
  const [view, setView] = useState<"month" | "week">("month");
  const [cursor, setCursor] = useState(new Date());
  const [platform, setPlatform] = useState("all");
  const [items, setItems] = useState<CalendarItem[]>([]);
  const [assets, setAssets] = useState<Pick<ContentAsset, "id" | "title" | "platform">[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [draft, setDraft] = useState<Draft | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const range = useMemo(() => {
    if (view === "week") return { from: startOfWeek(cursor, { weekStartsOn: 1 }), to: endOfWeek(cursor, { weekStartsOn: 1 }) };
    return { from: startOfWeek(startOfMonth(cursor), { weekStartsOn: 1 }), to: endOfWeek(endOfMonth(cursor), { weekStartsOn: 1 }) };
  }, [view, cursor]);

  const days = useMemo(() => {
    const out: Date[] = [];
    for (let d = range.from; d <= range.to; d = addDays(d, 1)) out.push(d);
    return out;
  }, [range]);

  const load = useCallback(async () => {
    if (!current) return;
    setError(null);
    const { data, error } = await supabase.from("calendar_items").select("*").eq("workspace_id", current.id)
      .gte("scheduled_for", ymd(range.from)).lte("scheduled_for", ymd(range.to)).order("scheduled_for");
    if (error) setError(error.message); else setItems((data as CalendarItem[]) ?? []);
    setLoading(false);
  }, [current?.id, range.from.getTime(), range.to.getTime()]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!current) return;
    supabase.from("content_assets").select("id, title, platform").eq("workspace_id", current.id)
      .order("created_at", { ascending: false }).limit(100).then(({ data }) => setAssets((data as any) ?? []));
  }, [current?.id]);

  const visible = platform === "all" ? items : items.filter((i) => i.platform === platform);
  const byDay = useMemo(() => {
    const m = new Map<string, CalendarItem[]>();
    for (const i of visible) m.set(i.scheduled_for, [...(m.get(i.scheduled_for) ?? []), i]);
    return m;
  }, [visible]);

  const step = (dir: 1 | -1) => setCursor((c) => (view === "month" ? (dir === 1 ? addMonths(c, 1) : subMonths(c, 1)) : dir === 1 ? addWeeks(c, 1) : subWeeks(c, 1)));
  const title = view === "month" ? format(cursor, "MMMM yyyy") : `${format(range.from, "d MMM")} – ${format(range.to, "d MMM yyyy")}`;

  function openNew(d: Date) {
    if (!canEdit) return;
    setDraft({ title: "", platform: "Instagram", date: ymd(d), notes: "", status: "planned", asset_id: "none" });
  }
  function openEdit(i: CalendarItem) {
    setDraft({ id: i.id, title: i.title, platform: i.platform, date: i.scheduled_for, notes: i.notes ?? "", status: i.status, asset_id: i.asset_id ?? "none" });
  }

  async function save() {
    if (!draft || !current || !user) return;
    if (!draft.title.trim()) return toast.error("Add a title.");
    if (!draft.date) return toast.error("Pick a date.");
    setSaving(true);
    const payload = {
      title: draft.title.trim().slice(0, 200), platform: draft.platform, scheduled_for: draft.date,
      notes: draft.notes.trim() || null, status: draft.status, asset_id: draft.asset_id === "none" ? null : draft.asset_id,
    };
    const res = draft.id
      ? await supabase.from("calendar_items").update(payload).eq("id", draft.id)
      : await supabase.from("calendar_items").insert({ ...payload, workspace_id: current.id, created_by: user.id });
    setSaving(false);
    if (res.error) return toast.error(errMessage(res.error));
    toast.success(draft.id ? "Updated" : "Added to calendar");
    setDraft(null);
    load();
  }

  async function remove() {
    if (!deleteTarget) return;
    setDeleting(true);
    const { error } = await supabase.from("calendar_items").delete().eq("id", deleteTarget);
    setDeleting(false);
    if (error) return toast.error(errMessage(error));
    setDeleteTarget(null);
    setDraft(null);
    toast.success("Removed from calendar");
    load();
  }

  const chip = (i: CalendarItem) => (
    <button key={i.id} onClick={(e) => { e.stopPropagation(); openEdit(i); }}
      className={cn("flex w-full items-center gap-1.5 truncate rounded-md bg-muted px-1.5 py-1 text-left text-xs hover:bg-accent", i.status === "done" && "line-through opacity-60")}>
      <span className={cn("h-2 w-2 shrink-0 rounded-full", DOT[i.platform])} /><span className="truncate">{i.title}</span>
    </button>
  );

  return (
    <div className="animate-fade-up">
      <PageHeader title="Content Calendar" description="Plan what goes out and when. This is a planning tool — RECAST doesn't publish to social accounts."
        actions={canEdit && <Button variant="brand" onClick={() => openNew(new Date())}><Plus className="h-4 w-4" /> Add item</Button>} />

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1">
          <Button variant="outline" size="icon" onClick={() => step(-1)} aria-label="Previous"><ChevronLeft className="h-4 w-4" /></Button>
          <Button variant="outline" size="icon" onClick={() => step(1)} aria-label="Next"><ChevronRight className="h-4 w-4" /></Button>
          <Button variant="outline" size="sm" className="ml-1" onClick={() => setCursor(new Date())}>Today</Button>
          <h2 className="ml-3 text-lg font-semibold">{title}</h2>
        </div>
        <div className="flex gap-2">
          <div className="inline-flex rounded-xl bg-muted p-1">
            {(["month", "week"] as const).map((v) => (
              <button key={v} onClick={() => setView(v)} className={cn("rounded-lg px-3 py-1 text-sm font-medium capitalize", view === v ? "bg-card shadow-sm" : "text-muted-foreground")}>{v}</button>
            ))}
          </div>
          <Select value={platform} onValueChange={setPlatform}>
            <SelectTrigger className="w-40" aria-label="Filter by platform"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All platforms</SelectItem>
              {CALENDAR_PLATFORMS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {error ? <ErrorState message={error} onRetry={load} /> : (
        <div className="overflow-x-auto rounded-2xl border bg-card shadow-soft">
          <div className="min-w-[640px]">
            <div className="grid grid-cols-7 border-b bg-muted/40 text-center text-xs font-medium text-muted-foreground">
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => <div key={d} className="py-2">{d}</div>)}
            </div>
            <div className="grid grid-cols-7">
              {days.map((d) => {
                const list = byDay.get(ymd(d)) ?? [];
                const faded = view === "month" && !isSameMonth(d, cursor);
                return (
                  <div key={d.toISOString()} onClick={() => openNew(d)}
                    className={cn("border-b border-r p-1.5 transition", view === "month" ? "min-h-[104px]" : "min-h-[260px]", canEdit && "cursor-pointer hover:bg-accent/40", faded && "bg-muted/30 text-muted-foreground")}>
                    <span className={cn("mb-1 inline-flex h-6 w-6 items-center justify-center rounded-full text-xs", isToday(d) && "bg-primary font-semibold text-primary-foreground")}>{format(d, "d")}</span>
                    <div className="space-y-1">
                      {(view === "month" ? list.slice(0, 3) : list).map(chip)}
                      {view === "month" && list.length > 3 && <p className="px-1 text-[11px] text-muted-foreground">+{list.length - 3} more</p>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
      {loading && <div className="mt-4 flex justify-center"><Spinner className="text-primary" /></div>}
      {!loading && !error && items.length === 0 && (
        <p className="mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground"><CalendarDays className="h-4 w-4" /> Nothing planned in this range. Click a day to add content.</p>
      )}

      <Dialog open={!!draft} onOpenChange={(o) => !o && !saving && setDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{draft?.id ? "Edit scheduled content" : "Plan content"}</DialogTitle>
            <DialogDescription>Planning only — nothing is posted automatically.</DialogDescription>
          </DialogHeader>
          {draft && (
            <div className="space-y-4">
              <div className="space-y-1.5"><Label htmlFor="ct">Title</Label><Input id="ct" autoFocus maxLength={200} value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} disabled={!canEdit} /></div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5"><Label htmlFor="cd">Date</Label><Input id="cd" type="date" value={draft.date} onChange={(e) => setDraft({ ...draft, date: e.target.value })} disabled={!canEdit} /></div>
                <div className="space-y-1.5">
                  <Label>Platform</Label>
                  <Select value={draft.platform} onValueChange={(v) => setDraft({ ...draft, platform: v })} disabled={!canEdit}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{CALENDAR_PLATFORMS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Linked draft (optional)</Label>
                <Select value={draft.asset_id} onValueChange={(v) => setDraft({ ...draft, asset_id: v })} disabled={!canEdit}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {assets.map((a) => <SelectItem key={a.id} value={a.id}>{(a.title ?? a.platform).slice(0, 60)}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label htmlFor="cn">Notes</Label><Textarea id="cn" maxLength={2000} value={draft.notes} onChange={(e) => setDraft({ ...draft, notes: e.target.value })} disabled={!canEdit} /></div>
              {draft.id && (
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={draft.status === "done"} disabled={!canEdit} onChange={(e) => setDraft({ ...draft, status: e.target.checked ? "done" : "planned" })} /> Mark as done
                </label>
              )}
            </div>
          )}
          <DialogFooter className="sm:justify-between">
            {draft?.id && canEdit ? <Button variant="ghost" className="text-destructive" onClick={() => setDeleteTarget(draft.id!)}><Trash2 className="h-4 w-4" /> Delete</Button> : <span />}
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setDraft(null)} disabled={saving}>Close</Button>
              {canEdit && <Button variant="brand" onClick={save} disabled={saving}>{saving && <Spinner />} Save</Button>}
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)} destructive loading={deleting}
        title="Remove from calendar?" description="The scheduled entry is deleted. Any linked draft stays in your library." confirmLabel="Remove" onConfirm={remove} />
    </div>
  );
}

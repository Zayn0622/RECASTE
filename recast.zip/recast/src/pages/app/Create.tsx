import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { AlertTriangle, ArrowLeft, ArrowRight, Check, Coins, Info, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { useAppConfig, estimateCreditsWith } from "@/hooks/useAppConfig";
import { ApiError, invokeFunction, type AiStatus, type GenerateResult } from "@/lib/api";
import { PLATFORMS, type PlatformId } from "@/lib/platforms";
import { GOALS, LANGUAGES, LENGTHS, TONES } from "@/lib/config";
import { cn, errMessage, wordCount } from "@/lib/utils";
import { SourceStep, EMPTY_SOURCE, sourceWords, type SourceState } from "@/components/studio/SourceStep";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress, Spinner, PageHeader } from "@/components/ui/misc";
import type { Brand } from "@/types/db";

const STEPS = ["Source", "Formats", "Customize", "Generate"] as const;

interface Options {
  audience: string; goal: string; tone: string; language: string; length: string; brandId: string; instructions: string;
}
const DEFAULT_OPTIONS: Options = {
  audience: "", goal: "Grow audience", tone: "Conversational", language: "English", length: "Medium", brandId: "none", instructions: "",
};

const STAGES = [
  "Analysing your source…",
  "Extracting the key ideas…",
  "Understanding audience and goal…",
  "Writing each format…",
  "Validating and saving…",
];

export default function Create() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const { user } = useAuth();
  const { current, canEdit, refresh } = useWorkspace();
  const cfg = useAppConfig();
  const draftKey = `recast-draft-${current?.id}`;

  const [step, setStep] = useState(0);
  const [source, setSource] = useState<SourceState>(EMPTY_SOURCE);
  const [platforms, setPlatforms] = useState<PlatformId[]>(() => {
    const p = params.get("platform");
    return PLATFORMS.some((x) => x.id === p) ? [p as PlatformId] : [];
  });
  const [options, setOptions] = useState<Options>(DEFAULT_OPTIONS);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [aiStatus, setAiStatus] = useState<AiStatus | null>(null);
  const [aiStatusError, setAiStatusError] = useState<string | null>(null);

  const [generating, setGenerating] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [genError, setGenError] = useState<string | null>(null);

  // Retry safety: one project + one idempotency key per attempt
  const projectRef = useRef<{ id: string; snapshot: string } | null>(null);
  const keyRef = useRef<string>(crypto.randomUUID());

  // ── Restore draft (text fields only — files are never auto-restored)
  useEffect(() => {
    if (!current) return;
    try {
      const raw = localStorage.getItem(draftKey);
      if (!raw) return;
      const d = JSON.parse(raw);
      if (d.source?.text || d.source?.transcript || d.source?.title) {
        setSource({ ...EMPTY_SOURCE, ...d.source, file: null, tab: d.source.tab === "file" ? "text" : d.source.tab });
        if (!params.get("platform") && Array.isArray(d.platforms)) setPlatforms(d.platforms);
        if (d.options) setOptions({ ...DEFAULT_OPTIONS, ...d.options });
        toast.info("Restored your unsaved draft");
      }
    } catch { /* ignore */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.id]);

  // ── Auto-save draft
  useEffect(() => {
    if (!current) return;
    const t = setTimeout(() => {
      try {
        if (!source.text && !source.transcript && !source.title) return;
        localStorage.setItem(draftKey, JSON.stringify({ source: { ...source, file: null }, platforms, options }));
      } catch { /* ignore */ }
    }, 600);
    return () => clearTimeout(t);
  }, [source, platforms, options, current?.id, draftKey]);

  // ── Load brands + AI status
  useEffect(() => {
    if (!current) return;
    supabase.from("brands").select("*").eq("workspace_id", current.id).order("created_at").then(({ data }) => {
      const list = (data as Brand[]) ?? [];
      setBrands(list);
      const def = list.find((b) => b.is_default);
      if (def) setOptions((o) => (o.brandId === "none" ? { ...o, brandId: def.id } : o));
    });
  }, [current?.id]);

  useEffect(() => {
    invokeFunction<AiStatus>("generate", { action: "status" })
      .then(setAiStatus)
      .catch((e) => setAiStatusError(errMessage(e)));
  }, []);

  // ── Progress ticker while generating
  useEffect(() => {
    if (!generating) return;
    setElapsed(0);
    const t = setInterval(() => setElapsed((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, [generating]);

  const words = sourceWords(source);
  const estimate = estimateCreditsWith(cfg, platforms.length, words);
  const demo = aiStatus?.demo_mode ?? false;
  const cost = demo ? 0 : estimate;
  const balance = current?.credits ?? 0;
  const notEnough = !demo && cost > balance;

  const sourceError = useMemo(() => {
    if (source.tab === "file") return source.file ? null : "Upload a PDF or TXT file to continue.";
    if (words < 30) return "Add at least 30 words of source content to continue.";
    if (words > cfg.maxSourceWords) return `Your source is over the ${cfg.maxSourceWords.toLocaleString()} word limit.`;
    return null;
  }, [source, words, cfg.maxSourceWords]);

  function next() {
    if (step === 0 && sourceError) return toast.error(sourceError);
    if (step === 1 && platforms.length === 0) return toast.error("Select at least one content format.");
    setStep((s) => Math.min(3, s + 1));
  }

  function togglePlatform(id: PlatformId) {
    setPlatforms((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  }

  async function generate() {
    if (!current || !user) return;
    if (!canEdit) return toast.error("Your role in this workspace is view-only.");
    if (sourceError) { setStep(0); return toast.error(sourceError); }
    if (platforms.length === 0) { setStep(1); return toast.error("Select at least one format."); }
    if (notEnough) return toast.error("You don't have enough credits for this generation.");

    setGenError(null);
    setGenerating(true);
    try {
      const title = (source.title.trim() || (source.tab === "file" ? source.file?.name : "") || `Untitled project`).slice(0, 200);
      const sourceText = source.tab === "text" ? source.text : source.tab === "youtube" ? source.transcript : source.file?.text ?? "";
      const snapshot = JSON.stringify([source.tab, title, sourceText.length, source.file?.path, source.youtubeUrl]);

      // Create (or reuse) the project and its source
      let projectId = projectRef.current?.id;
      if (projectId && projectRef.current?.snapshot !== snapshot) {
        await supabase.from("projects").delete().eq("id", projectId); // stale failed attempt
        projectId = undefined;
        projectRef.current = null;
        keyRef.current = crypto.randomUUID();
      }
      if (!projectId) {
        const { data: proj, error: pErr } = await supabase.from("projects")
          .insert({ workspace_id: current.id, created_by: user.id, title, source_type: source.tab })
          .select("id").single();
        if (pErr || !proj) throw pErr ?? new Error("Couldn't create the project");
        projectId = proj.id as string;
        const { error: sErr } = await supabase.from("source_contents").insert({
          project_id: projectId, workspace_id: current.id, source_type: source.tab, title,
          text_content: source.tab === "file" ? null : sourceText || null,
          file_path: source.tab === "file" ? source.file?.path : null,
          file_name: source.tab === "file" ? source.file?.name : null,
          youtube_url: source.tab === "youtube" ? source.youtubeUrl.trim().slice(0, 500) || null : null,
          word_count: source.tab === "file" && !source.file?.text ? 0 : wordCount(sourceText),
        });
        if (sErr) { await supabase.from("projects").delete().eq("id", projectId); throw sErr; }
        projectRef.current = { id: projectId, snapshot };
      }

      const res = await invokeFunction<GenerateResult>("generate", {
        action: "generate",
        project_id: projectId,
        idempotency_key: keyRef.current,
        platforms,
        options: {
          audience: options.audience, goal: options.goal, tone: options.tone, language: options.language,
          length: options.length, instructions: options.instructions,
          brand_id: options.brandId === "none" ? null : options.brandId,
        },
      });

      try { localStorage.removeItem(draftKey); } catch { /* ignore */ }
      await refresh(); // updated credit balance
      toast.success(res.demo ? "Demo content created (not AI-generated)" : `Created ${res.assets_count} assets`);
      navigate(`/app/projects/${projectId}`);
    } catch (e) {
      const code = e instanceof ApiError ? e.code : "";
      // A definitive server answer means a fresh attempt needs a fresh key; a network error does not.
      if (code && code !== "network_error") keyRef.current = crypto.randomUUID();
      setGenError(errMessage(e));
      await refresh();
    } finally {
      setGenerating(false);
    }
  }

  const stage = STAGES[Math.min(STAGES.length - 1, Math.floor(elapsed / 6))];
  const progress = Math.round(92 * (1 - Math.exp(-elapsed / 28)));

  if (!current) return null;

  return (
    <div className="animate-fade-up">
      <PageHeader title="Create Content" description="One source in, platform-ready content out." />

      {/* Stepper */}
      <ol className="mb-6 flex items-center gap-2 overflow-x-auto pb-1">
        {STEPS.map((label, i) => (
          <li key={label} className="flex items-center gap-2">
            <button
              type="button"
              disabled={generating || i > step}
              onClick={() => setStep(i)}
              className={cn(
                "flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-medium transition",
                i === step ? "border-primary bg-accent text-accent-foreground" : i < step ? "bg-card" : "bg-card text-muted-foreground",
              )}
            >
              <span className={cn("flex h-5 w-5 items-center justify-center rounded-full text-xs", i < step ? "bg-primary text-primary-foreground" : "bg-muted")}>
                {i < step ? <Check className="h-3 w-3" /> : i + 1}
              </span>
              {label}
            </button>
            {i < STEPS.length - 1 && <span className="h-px w-4 bg-border sm:w-8" />}
          </li>
        ))}
      </ol>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="min-w-0 space-y-4 lg:col-span-2">
          <Card>
            <CardContent className="p-5 sm:p-6">
              {step === 0 && <SourceStep value={source} onChange={setSource} workspaceId={current.id} cfg={cfg} />}

              {step === 1 && (
                <div>
                  <h2 className="text-lg font-semibold">Choose your content formats</h2>
                  <p className="mb-4 text-sm text-muted-foreground">Select one or more. Each is written natively for its platform.</p>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {PLATFORMS.map((p) => {
                      const on = platforms.includes(p.id);
                      return (
                        <button
                          type="button"
                          key={p.id}
                          onClick={() => togglePlatform(p.id)}
                          aria-pressed={on}
                          className={cn(
                            "relative flex items-start gap-3 rounded-2xl border p-4 text-left transition hover:-translate-y-0.5",
                            on ? "border-primary bg-accent ring-1 ring-primary/40" : "bg-card hover:bg-muted/50",
                          )}
                        >
                          <p.icon className={cn("mt-0.5 h-5 w-5 shrink-0", p.tint)} />
                          <div>
                            <p className="text-sm font-semibold">{p.label}</p>
                            <p className="mt-0.5 text-xs text-muted-foreground">{p.description}</p>
                          </div>
                          {on && <span className="absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground"><Check className="h-3 w-3" /></span>}
                        </button>
                      );
                    })}
                  </div>
                  <button type="button" className="mt-3 text-sm font-medium text-primary hover:underline" onClick={() => setPlatforms(platforms.length === PLATFORMS.length ? [] : PLATFORMS.map((p) => p.id))}>
                    {platforms.length === PLATFORMS.length ? "Clear all" : "Select all"}
                  </button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-5">
                  <div>
                    <h2 className="text-lg font-semibold">Customize generation</h2>
                    <p className="text-sm text-muted-foreground">The more specific you are, the sharper the output.</p>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="aud">Target audience</Label>
                    <Input id="aud" maxLength={500} value={options.audience} onChange={(e) => setOptions({ ...options, audience: e.target.value })} placeholder="e.g. early-stage founders who struggle with consistency" />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Content goal" value={options.goal} items={GOALS} onChange={(v) => setOptions({ ...options, goal: v })} />
                    <Field label="Tone of voice" value={options.tone} items={TONES} onChange={(v) => setOptions({ ...options, tone: v })} />
                    <Field label="Output language" value={options.language} items={LANGUAGES} onChange={(v) => setOptions({ ...options, language: v })} />
                    <Field label="Desired length" value={options.length} items={LENGTHS} onChange={(v) => setOptions({ ...options, length: v })} />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Brand voice</Label>
                    <Select value={options.brandId} onValueChange={(v) => setOptions({ ...options, brandId: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No brand voice</SelectItem>
                        {brands.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    {brands.length === 0 && <p className="text-xs text-muted-foreground">No brand voices yet — you can create one under Brand Voice.</p>}
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="inst">Additional instructions</Label>
                    <Textarea id="inst" maxLength={2000} value={options.instructions} onChange={(e) => setOptions({ ...options, instructions: e.target.value })} placeholder="e.g. Mention our free trial in the CTA. Avoid jargon." />
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-5">
                  <div>
                    <h2 className="text-lg font-semibold">Review & generate</h2>
                    <p className="text-sm text-muted-foreground">RECAST analyses your source first, then writes each format.</p>
                  </div>

                  {aiStatusError && (
                    <Banner tone="warn" icon={AlertTriangle}>
                      Couldn't check the AI backend: {aiStatusError}
                    </Banner>
                  )}
                  {aiStatus && !aiStatus.ai_configured && !aiStatus.demo_mode && (
                    <Banner tone="warn" icon={AlertTriangle}>
                      AI generation isn't configured on the server yet. Set <code>GEMINI_API_KEY</code> for the <code>generate</code> function (see the README), or enable <code>DEMO_MODE</code> to try the workflow with clearly-labelled placeholder content.
                    </Banner>
                  )}
                  {demo && (
                    <Banner tone="info" icon={Info}>
                      <b>Demo mode:</b> no AI provider is connected, so the output will be simple placeholder text built from your source and clearly labelled as not AI-generated. No credits are used.
                    </Banner>
                  )}

                  <dl className="grid gap-3 rounded-2xl bg-muted p-4 text-sm sm:grid-cols-2">
                    <Summary label="Source" value={`${source.title || "Untitled"} · ${source.tab === "file" ? source.file?.name : `${words.toLocaleString()} words`}`} />
                    <Summary label="Formats" value={platforms.map((p) => PLATFORMS.find((x) => x.id === p)?.short).join(", ")} />
                    <Summary label="Tone / language" value={`${options.tone} · ${options.language}`} />
                    <Summary label="Goal / length" value={`${options.goal} · ${options.length}`} />
                  </dl>

                  <div className="flex items-center justify-between rounded-2xl border p-4">
                    <div className="flex items-center gap-3">
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-accent-foreground"><Coins className="h-5 w-5" /></span>
                      <div>
                        <p className="text-sm font-medium">{demo ? "No credits used in demo mode" : `Estimated cost: ${estimate} credit${estimate === 1 ? "" : "s"}`}</p>
                        <p className="text-xs text-muted-foreground">
                          Balance: {balance}
                          {source.tab === "file" && !source.file?.text && " · final cost depends on document length"}
                          {" · refunded automatically if generation fails"}
                        </p>
                      </div>
                    </div>
                  </div>
                  {notEnough && <Banner tone="warn" icon={AlertTriangle}>You need {cost} credits but have {balance}. Choose fewer formats or a shorter source.</Banner>}
                  {genError && (
                    <div role="alert" className="rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">{genError}</div>
                  )}

                  {generating ? (
                    <div className="space-y-3 rounded-2xl border bg-card p-5">
                      <div className="flex items-center gap-2 text-sm font-medium"><Spinner className="text-primary" /> {stage}</div>
                      <Progress value={progress} />
                      <p className="text-xs text-muted-foreground">This usually takes 15–60 seconds. Please keep this tab open. ({elapsed}s)</p>
                    </div>
                  ) : (
                    <Button variant="brand" size="lg" className="w-full" onClick={generate} disabled={notEnough || !canEdit}>
                      <Sparkles className="h-4 w-4" /> Generate Content
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-between">
            <Button variant="outline" onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0 || generating}><ArrowLeft className="h-4 w-4" /> Back</Button>
            {step < 3 && <Button onClick={next}>Next <ArrowRight className="h-4 w-4" /></Button>}
          </div>
        </div>

        {/* Summary rail */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <Card>
            <CardContent className="space-y-3 p-5 sm:p-6 text-sm">
              <h3 className="font-semibold">Your project</h3>
              <Row k="Source" v={words ? `${words.toLocaleString()} words` : source.file ? "File uploaded" : "—"} />
              <Row k="Formats" v={platforms.length ? String(platforms.length) : "—"} />
              <Row k="Estimated credits" v={demo ? "0 (demo)" : platforms.length && (words || source.file) ? String(estimate) : "—"} />
              <Row k="Balance" v={String(balance)} />
              {!canEdit && <p className="rounded-lg bg-amber-500/10 p-2 text-xs text-amber-600 dark:text-amber-400">You have view-only access to this workspace.</p>}
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}

function Field({ label, value, items, onChange }: { label: string; value: string; items: readonly string[]; onChange: (v: string) => void }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger><SelectValue /></SelectTrigger>
        <SelectContent>{items.map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
      </Select>
    </div>
  );
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="truncate font-medium">{value}</dd>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between"><span className="text-muted-foreground">{k}</span><b>{v}</b></div>;
}

function Banner({ tone, icon: Icon, children }: { tone: "warn" | "info"; icon: typeof Info; children: React.ReactNode }) {
  return (
    <div className={cn("flex gap-2.5 rounded-xl border p-3 text-sm", tone === "warn" ? "border-amber-500/40 bg-amber-500/10" : "border-primary/30 bg-accent")}>
      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
      <div>{children}</div>
    </div>
  );
}

import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Download, Library as LibraryIcon, Search } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { PLATFORMS } from "@/lib/platforms";
import { exportProject } from "@/lib/export";
import { AssetCard } from "@/components/project/AssetCard";
import { PageHeader, EmptyState, ErrorState, Skeleton } from "@/components/ui/misc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { ContentAsset } from "@/types/db";

const PAGE = 20;

export default function Library() {
  const navigate = useNavigate();
  const { current, canEdit } = useWorkspace();
  const [assets, setAssets] = useState<ContentAsset[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [platform, setPlatform] = useState("all");
  const [status, setStatus] = useState("all");
  const [range, setRange] = useState("all");
  const [q, setQ] = useState("");
  const [visible, setVisible] = useState(PAGE);

  const load = useCallback(async () => {
    if (!current) return;
    setError(null);
    const { data, error } = await supabase.from("content_assets").select("*, projects(title)")
      .eq("workspace_id", current.id).order("created_at", { ascending: false }).limit(500);
    if (error) return setError(error.message);
    setAssets((data as ContentAsset[]) ?? []);
  }, [current?.id]);

  useEffect(() => { setAssets(null); load(); }, [load]);
  useEffect(() => setVisible(PAGE), [platform, status, range, q]);

  const shown = useMemo(() => {
    let list = assets ?? [];
    if (platform !== "all") list = list.filter((a) => a.platform === platform);
    if (status !== "all") list = list.filter((a) => a.status === status);
    if (range !== "all") {
      const since = Date.now() - Number(range) * 86400000;
      list = list.filter((a) => +new Date(a.created_at) >= since);
    }
    if (q.trim()) {
      const s = q.trim().toLowerCase();
      list = list.filter((a) => (a.title ?? "").toLowerCase().includes(s) || a.content.toLowerCase().includes(s) || (a.projects?.title ?? "").toLowerCase().includes(s));
    }
    return list;
  }, [assets, platform, status, range, q]);

  return (
    <div className="animate-fade-up">
      <PageHeader title="Content Library" description="Every saved asset across all your projects."
        actions={shown.length > 0 && <Button variant="outline" onClick={() => exportProject("RECAST library export", shown)}><Download className="h-4 w-4" /> Export {shown.length}</Button>} />

      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search content…" className="pl-9" />
        </div>
        <Select value={platform} onValueChange={setPlatform}>
          <SelectTrigger aria-label="Platform"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All platforms</SelectItem>
            {PLATFORMS.map((p) => <SelectItem key={p.id} value={p.id}>{p.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger aria-label="Draft status"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Draft & final</SelectItem><SelectItem value="draft">Drafts</SelectItem><SelectItem value="final">Final</SelectItem>
          </SelectContent>
        </Select>
        <Select value={range} onValueChange={setRange}>
          <SelectTrigger aria-label="Date"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Any time</SelectItem><SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem><SelectItem value="90">Last 90 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {error ? <ErrorState message={error} onRetry={load} /> : assets === null ? (
        <div className="space-y-4">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-44 w-full" />)}</div>
      ) : assets.length === 0 ? (
        <EmptyState icon={LibraryIcon} title="Your library is empty" description="Generated assets will appear here, ready to edit, copy and export." action={<Button variant="brand" onClick={() => navigate("/app/create")}>Create content</Button>} />
      ) : shown.length === 0 ? (
        <EmptyState icon={Search} title="Nothing matches those filters" action={<Button variant="outline" onClick={() => { setPlatform("all"); setStatus("all"); setRange("all"); setQ(""); }}>Clear filters</Button>} />
      ) : (
        <div className="space-y-5">
          {shown.slice(0, visible).map((a) => (
            <AssetCard key={a.id} asset={a} canEdit={canEdit} showProject
              onChange={(u) => setAssets((l) => l?.map((x) => (x.id === u.id ? { ...x, ...u, projects: x.projects } : x)) ?? l)}
              onDeleted={(id) => setAssets((l) => l?.filter((x) => x.id !== id) ?? l)} />
          ))}
          {visible < shown.length && <div className="text-center"><Button variant="outline" onClick={() => setVisible((v) => v + PAGE)}>Show more ({shown.length - visible} left)</Button></div>}
        </div>
      )}
    </div>
  );
}

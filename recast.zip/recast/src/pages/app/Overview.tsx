import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Coins, FileStack, FolderKanban, Lightbulb, Plus, Sparkles } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EmptyState, ErrorState, Skeleton } from "@/components/ui/misc";
import { PLATFORMS } from "@/lib/platforms";
import { formatDate } from "@/lib/utils";
import { StatusBadge } from "@/components/project/StatusBadge";
import type { Project } from "@/types/db";

const TIPS = [
  "Longer, idea-dense sources (articles, transcripts) produce the strongest content.",
  "Save a Brand Voice once and reuse it on every generation.",
  "Regenerating never overwrites your text — you compare first, then decide.",
  "Use the Content Calendar to plan when each asset should go live.",
];

export default function Overview() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const { current } = useWorkspace();
  const [stats, setStats] = useState<{ projects: number; assets: number } | null>(null);
  const [recent, setRecent] = useState<Project[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!current) return;
    setError(null);
    const [p, a, r] = await Promise.all([
      supabase.from("projects").select("id", { count: "exact", head: true }).eq("workspace_id", current.id),
      supabase.from("content_assets").select("id", { count: "exact", head: true }).eq("workspace_id", current.id),
      supabase.from("projects").select("*, content_assets(count)").eq("workspace_id", current.id).order("created_at", { ascending: false }).limit(5),
    ]);
    if (p.error || a.error || r.error) { setError((p.error ?? a.error ?? r.error)!.message); return; }
    setStats({ projects: p.count ?? 0, assets: a.count ?? 0 });
    setRecent((r.data as Project[]) ?? []);
  }, [current?.id]);

  useEffect(() => { setStats(null); setRecent(null); load(); }, [load]);

  const first = (profile?.full_name ?? "there").split(" ")[0];

  return (
    <div className="space-y-6 animate-fade-up">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Welcome back, {first} 👋</h1>
          <p className="mt-1 text-sm text-muted-foreground">Here's what's happening in <b>{current?.name}</b>.</p>
        </div>
        <Button variant="brand" size="lg" onClick={() => navigate("/app/create")}><Plus className="h-4 w-4" /> Create New Content</Button>
      </div>

      {error && <ErrorState message={error} onRetry={load} />}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="flex items-center gap-4 p-5 sm:p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent text-accent-foreground"><Coins className="h-5 w-5" /></span>
            <div>
              <p className="text-sm text-muted-foreground">Credits remaining</p>
              <p className="text-2xl font-bold">{current?.credits ?? 0}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-5 sm:p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent text-accent-foreground"><FolderKanban className="h-5 w-5" /></span>
            <div>
              <p className="text-sm text-muted-foreground">Total projects</p>
              {stats ? <p className="text-2xl font-bold">{stats.projects}</p> : <Skeleton className="mt-1 h-7 w-12" />}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-5 sm:p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent text-accent-foreground"><FileStack className="h-5 w-5" /></span>
            <div>
              <p className="text-sm text-muted-foreground">Generated assets</p>
              {stats ? <p className="text-2xl font-bold">{stats.assets}</p> : <Skeleton className="mt-1 h-7 w-12" />}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="min-w-0 space-y-3 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Recent projects</h2>
            <Link to="/app/projects" className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">View all <ArrowRight className="h-3.5 w-3.5" /></Link>
          </div>
          {recent === null ? (
            <div className="space-y-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
          ) : recent.length === 0 ? (
            <EmptyState
              icon={Sparkles}
              title="No projects yet"
              description="Paste an article or transcript and RECAST will turn it into platform-ready content."
              action={<Button variant="brand" onClick={() => navigate("/app/create")}>Create your first project</Button>}
            />
          ) : (
            <div className="space-y-3">
              {recent.map((p) => (
                <Link key={p.id} to={`/app/projects/${p.id}`} className="flex min-w-0 items-center justify-between gap-3 rounded-2xl border bg-card p-4 shadow-soft transition hover:-translate-y-0.5">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{p.title}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">{formatDate(p.created_at)} · {p.content_assets?.[0]?.count ?? 0} assets</p>
                  </div>
                  <StatusBadge status={p.status} />
                </Link>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="mb-3 text-lg font-semibold">Quick create</h2>
            <div className="grid grid-cols-2 gap-2">
              {PLATFORMS.slice(0, 6).map((p) => (
                <button
                  key={p.id}
                  onClick={() => navigate(`/app/create?platform=${p.id}`)}
                  className="flex items-center gap-2 rounded-xl border bg-card px-3 py-2.5 text-left text-sm font-medium shadow-soft transition hover:bg-accent"
                >
                  <p.icon className={`h-4 w-4 shrink-0 ${p.tint}`} /> <span className="truncate">{p.short}</span>
                </button>
              ))}
            </div>
          </div>
          <Card>
            <CardContent className="p-5">
              <div className="mb-3 flex items-center gap-2 font-semibold"><Lightbulb className="h-4 w-4 text-amber-500" /> Tips</div>
              <ul className="space-y-2.5 text-sm text-muted-foreground">
                {TIPS.map((t) => <li key={t} className="flex gap-2"><Badge variant="muted" className="mt-0.5 h-5 w-5 shrink-0 justify-center p-0">•</Badge>{t}</li>)}
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, ChevronDown, Copy, Download, FileText, Pencil, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { useAppConfig } from "@/hooks/useAppConfig";
import { ApiError, invokeFunction, type RegenResult } from "@/lib/api";
import { PLATFORMS, PLATFORM_MAP } from "@/lib/platforms";
import { assetToMarkdown, exportProject } from "@/lib/export";
import { copyToClipboard, errMessage, formatDate } from "@/lib/utils";
import { AssetCard } from "@/components/project/AssetCard";
import { StatusBadge } from "@/components/project/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ConfirmDialog, Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, ErrorState, Skeleton, Spinner } from "@/components/ui/misc";
import type { ContentAsset, Generation, Project, SourceContent } from "@/types/db";

const ORDER = Object.fromEntries(PLATFORMS.map((p, i) => [p.id, i]));

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { current, canEdit, refresh } = useWorkspace();
  const cfg = useAppConfig();

  const [project, setProject] = useState<Project | null>(null);
  const [source, setSource] = useState<SourceContent | null>(null);
  const [assets, setAssets] = useState<ContentAsset[]>([]);
  const [analysis, setAnalysis] = useState<Generation["options"] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);

  const [renaming, setRenaming] = useState(false);
  const [titleDraft, setTitleDraft] = useState("");
  const [showSource, setShowSource] = useState(false);

  const dirty = useRef(new Set<string>());
  const [regenTarget, setRegenTarget] = useState<ContentAsset | null>(null);   // awaiting cost confirmation
  const [regenBusy, setRegenBusy] = useState<string | null>(null);              // asset id being regenerated
  const [proposal, setProposal] = useState<{ asset: ContentAsset; data: RegenResult["proposal"] } | null>(null);
  const [applying, setApplying] = useState(false);

  const load = useCallback(async (silent = false) => {
    if (!id) return;
    if (!silent) setLoading(true);
    setError(null);
    const [p, s, a, g] = await Promise.all([
      supabase.from("projects").select("*").eq("id", id).maybeSingle(),
      supabase.from("source_contents").select("*").eq("project_id", id).order("created_at", { ascending: false }).limit(1).maybeSingle(),
      supabase.from("content_assets").select("*").eq("project_id", id),
      supabase.from("generations").select("analysis").eq("project_id", id).eq("status", "completed").order("created_at", { ascending: false }).limit(1).maybeSingle(),
    ]);
    if (p.error) { setError(p.error.message); setLoading(false); return; }
    if (!p.data) { setNotFound(true); setLoading(false); return; }
    setProject(p.data as Project);
    setSource((s.data as SourceContent) ?? null);
    setAssets(((a.data as ContentAsset[]) ?? []).sort((x, y) => (ORDER[x.platform] ?? 99) - (ORDER[y.platform] ?? 99)));
    setAnalysis((g.data as { analysis?: Generation["options"] } | null)?.analysis ?? null);
    setLoading(false);
  }, [id]);

  useEffect(() => { load(); }, [load]);

  // Poll while a generation is in flight (e.g. user returned to the page)
  useEffect(() => {
    if (project?.status !== "generating") return;
    const t = setInterval(() => load(true), 5000);
    return () => clearInterval(t);
  }, [project?.status, load]);

  // Warn before leaving with unsaved edits
  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => { if (dirty.current.size) { e.preventDefault(); e.returnValue = ""; } };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, []);

  const keyAnalysis = analysis as unknown as { summary?: string; key_ideas?: string[]; audience?: string; objective?: string } | null;

  async function saveTitle() {
    if (!project) return;
    const t = titleDraft.trim();
    if (!t || t === project.title) { setRenaming(false); return; }
    const { error } = await supabase.from("projects").update({ title: t.slice(0, 200) }).eq("id", project.id);
    if (error) return toast.error(errMessage(error));
    setProject({ ...project, title: t.slice(0, 200) });
    setRenaming(false);
    toast.success("Project renamed");
  }

  async function copyAll() {
    if (!project) return;
    const md = assets.map(assetToMarkdown).join("\n---\n\n");
    (await copyToClipboard(md)) ? toast.success(`Copied ${assets.length} assets`) : toast.error("Couldn't copy to clipboard.");
  }

  function askRegenerate(a: ContentAsset) {
    if (dirty.current.has(a.id)) return toast.error("Save or cancel your edits on this asset before regenerating.");
    setRegenTarget(a);
  }

  async function runRegenerate() {
    const a = regenTarget;
    if (!a || !project) return;
    setRegenTarget(null);
    setRegenBusy(a.id);
    try {
      const res = await invokeFunction<RegenResult>("generate", {
        action: "regenerate", project_id: project.id, asset_id: a.id, idempotency_key: crypto.randomUUID(),
      });
      await refresh();
      setProposal({ asset: a, data: res.proposal });
    } catch (e) {
      toast.error(errMessage(e), { description: e instanceof ApiError && e.code !== "insufficient_credits" ? "Any credits used were refunded." : undefined });
      await refresh();
    } finally {
      setRegenBusy(null);
    }
  }

  async function applyProposal() {
    if (!proposal) return;
    setApplying(true);
    const { data, error } = await supabase.from("content_assets")
      .update({ title: proposal.data.title, content: proposal.data.content, metadata: proposal.data.metadata, status: "draft" })
      .eq("id", proposal.asset.id).select("*").single();
    setApplying(false);
    if (error || !data) return toast.error(errMessage(error));
    setAssets((list) => list.map((x) => (x.id === proposal.asset.id ? { ...x, ...(data as ContentAsset) } : x)));
    setProposal(null);
    toast.success("Replaced with the new version");
  }

  const sourcePreview = useMemo(() => (source?.text_content ?? "").slice(0, 4000), [source]);

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-8 w-72" /><Skeleton className="h-48 w-full" /><Skeleton className="h-48 w-full" /></div>;
  }
  if (notFound) {
    return <EmptyState icon={FileText} title="Project not found" description="It may have been deleted, or you don't have access to it." action={<Button onClick={() => navigate("/app/projects")}>Back to projects</Button>} />;
  }
  if (error || !project) return <ErrorState message={error ?? "Couldn't load this project."} onRetry={() => load()} />;

  return (
    <div className="space-y-6 animate-fade-up">
      <div>
        <Link to="/app/projects" className="mb-3 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" /> My projects</Link>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0">
            {renaming ? (
              <form onSubmit={(e) => { e.preventDefault(); saveTitle(); }} className="flex items-center gap-2">
                <Input autoFocus value={titleDraft} maxLength={200} onChange={(e) => setTitleDraft(e.target.value)} className="max-w-md" />
                <Button type="submit" size="sm">Save</Button>
                <Button type="button" size="sm" variant="ghost" onClick={() => setRenaming(false)}>Cancel</Button>
              </form>
            ) : (
              <div className="flex items-center gap-2">
                <h1 className="truncate text-2xl font-bold tracking-tight sm:text-3xl">{project.title}</h1>
                {canEdit && <button aria-label="Rename project" onClick={() => { setTitleDraft(project.title); setRenaming(true); }} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted"><Pencil className="h-4 w-4" /></button>}
              </div>
            )}
            <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
              <StatusBadge status={project.status} />
              <span>Created {formatDate(project.created_at)}</span>
              <span>· {assets.length} asset{assets.length === 1 ? "" : "s"}</span>
              <span className="capitalize">· {project.source_type === "youtube" ? "YouTube" : project.source_type} source</span>
            </div>
          </div>
          {assets.length > 0 && (
            <div className="flex gap-2">
              <Button variant="outline" onClick={copyAll}><Copy className="h-4 w-4" /> Copy all</Button>
              <Button variant="outline" onClick={() => exportProject(project.title, assets)}><Download className="h-4 w-4" /> Export all</Button>
            </div>
          )}
        </div>
      </div>

      {project.status === "generating" && (
        <Card><CardContent className="flex items-center gap-3 p-5 sm:p-6"><Spinner className="text-primary" /><p className="text-sm">Generation is in progress. This page updates automatically.</p></CardContent></Card>
      )}

      {project.status === "failed" && assets.length === 0 && (
        <EmptyState
          icon={Sparkles}
          title="This generation didn't complete"
          description="Any credits used were refunded. You can try again with a new project."
          action={<Button variant="brand" onClick={() => navigate("/app/create")}>Start over</Button>}
        />
      )}

      {keyAnalysis?.key_ideas && keyAnalysis.key_ideas.length > 0 && (
        <Card>
          <CardContent className="space-y-3 p-5 sm:p-6">
            <div className="flex items-center gap-2 font-semibold"><Sparkles className="h-4 w-4 text-primary" /> What the AI found in your source</div>
            {keyAnalysis.summary && <p className="text-sm text-muted-foreground">{keyAnalysis.summary}</p>}
            <ul className="grid gap-2 sm:grid-cols-2">
              {keyAnalysis.key_ideas.map((k, i) => <li key={i} className="flex gap-2 rounded-xl bg-muted px-3 py-2 text-sm"><Badge className="h-5 shrink-0">{i + 1}</Badge>{k}</li>)}
            </ul>
            {(keyAnalysis.audience || keyAnalysis.objective) && (
              <p className="text-xs text-muted-foreground">
                {keyAnalysis.audience && <>Audience: <b>{keyAnalysis.audience}</b></>}
                {keyAnalysis.audience && keyAnalysis.objective && " · "}
                {keyAnalysis.objective && <>Objective: <b>{keyAnalysis.objective}</b></>}
              </p>
            )}
          </CardContent>
        </Card>
      )}

      <div className="space-y-5">
        {assets.map((a) => (
          <AssetCard
            key={a.id}
            asset={a}
            canEdit={canEdit}
            regenerating={regenBusy === a.id}
            onChange={(upd) => setAssets((list) => list.map((x) => (x.id === upd.id ? upd : x)))}
            onDeleted={(aid) => setAssets((list) => list.filter((x) => x.id !== aid))}
            onRegenerate={askRegenerate}
            onDirtyChange={(aid, d) => (d ? dirty.current.add(aid) : dirty.current.delete(aid))}
          />
        ))}
        {assets.length === 0 && project.status === "ready" && (
          <EmptyState icon={FileText} title="No assets in this project" description="All generated assets were deleted. Create a new project to generate more." action={<Button onClick={() => navigate("/app/create")}>Create content</Button>} />
        )}
      </div>

      {source && (
        <Card>
          <button className="flex w-full items-center justify-between p-5 text-left" onClick={() => setShowSource((s) => !s)} aria-expanded={showSource}>
            <span className="font-semibold">Original source{source.file_name ? ` · ${source.file_name}` : ""}</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${showSource ? "rotate-180" : ""}`} />
          </button>
          {showSource && (
            <CardContent>
              {source.youtube_url && <p className="mb-2 break-all text-xs text-muted-foreground">{source.youtube_url}</p>}
              {sourcePreview
                ? <p className="whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground">{sourcePreview}{(source.text_content?.length ?? 0) > 4000 && "…"}</p>
                : <p className="text-sm text-muted-foreground">The text of uploaded files is extracted on the server when you generate.</p>}
              <p className="mt-3 text-xs text-muted-foreground">{source.word_count ? `${source.word_count.toLocaleString()} words` : ""}</p>
            </CardContent>
          )}
        </Card>
      )}

      {/* Confirm cost before regenerating */}
      <ConfirmDialog
        open={!!regenTarget}
        onOpenChange={(o) => !o && setRegenTarget(null)}
        title={`Regenerate ${regenTarget ? PLATFORM_MAP[regenTarget.platform]?.label : ""}?`}
        description={`This uses ${cfg.costs.regeneration} credit. Your current version is NOT changed — you'll compare the new version with it and choose whether to replace it. Credits are refunded if it fails.`}
        confirmLabel={`Regenerate (${cfg.costs.regeneration} credit)`}
        onConfirm={runRegenerate}
      />

      {/* Compare & choose */}
      <Dialog open={!!proposal} onOpenChange={(o) => !o && !applying && setProposal(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Compare versions</DialogTitle>
            <DialogDescription>Nothing has been changed yet. Keep your current version, or replace it with the new one.</DialogDescription>
          </DialogHeader>
          {proposal && (
            <div className="grid gap-3 md:grid-cols-2">
              <div className="rounded-xl border p-3">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Current</p>
                <p className="mb-1 text-sm font-semibold">{proposal.asset.title}</p>
                <p className="max-h-[50vh] overflow-y-auto whitespace-pre-wrap text-sm leading-relaxed">{proposal.asset.content}</p>
              </div>
              <div className="rounded-xl border border-primary/50 bg-accent/40 p-3">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-primary">New version</p>
                <p className="mb-1 text-sm font-semibold">{proposal.data.title}</p>
                <p className="max-h-[50vh] overflow-y-auto whitespace-pre-wrap text-sm leading-relaxed">{proposal.data.content}</p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" disabled={applying} onClick={() => setProposal(null)}>Keep current</Button>
            <Button variant="brand" disabled={applying} onClick={applyProposal}>{applying && <Spinner />} Replace with new version</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

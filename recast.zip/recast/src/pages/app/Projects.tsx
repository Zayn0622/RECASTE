import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { FolderKanban, MoreHorizontal, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { errMessage, formatDate } from "@/lib/utils";
import { PageHeader, EmptyState, ErrorState, Skeleton, Spinner } from "@/components/ui/misc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { ConfirmDialog, Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { StatusBadge } from "@/components/project/StatusBadge";
import type { Project } from "@/types/db";

type SortKey = "newest" | "oldest" | "name";

export default function Projects() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const { current, canEdit } = useWorkspace();
  const [projects, setProjects] = useState<Project[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState("all");
  const [sourceType, setSourceType] = useState("all");
  const [sort, setSort] = useState<SortKey>("newest");
  const q = params.get("q") ?? "";

  const [renameTarget, setRenameTarget] = useState<Project | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [renaming, setRenaming] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Project | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    if (!current) return;
    setError(null);
    const { data, error } = await supabase.from("projects").select("*, content_assets(count)")
      .eq("workspace_id", current.id).order("created_at", { ascending: false });
    if (error) return setError(error.message);
    setProjects((data as Project[]) ?? []);
  }, [current?.id]);

  useEffect(() => { setProjects(null); load(); }, [load]);

  const shown = useMemo(() => {
    let list = projects ?? [];
    if (q.trim()) list = list.filter((p) => p.title.toLowerCase().includes(q.trim().toLowerCase()));
    if (status !== "all") list = list.filter((p) => p.status === status);
    if (sourceType !== "all") list = list.filter((p) => p.source_type === sourceType);
    const sorted = [...list];
    if (sort === "oldest") sorted.sort((a, b) => +new Date(a.created_at) - +new Date(b.created_at));
    else if (sort === "name") sorted.sort((a, b) => a.title.localeCompare(b.title));
    else sorted.sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at));
    return sorted;
  }, [projects, q, status, sourceType, sort]);

  async function rename() {
    if (!renameTarget) return;
    const t = renameValue.trim();
    if (!t) return toast.error("Name can't be empty.");
    setRenaming(true);
    const { error } = await supabase.from("projects").update({ title: t.slice(0, 200) }).eq("id", renameTarget.id);
    setRenaming(false);
    if (error) return toast.error(errMessage(error));
    setProjects((l) => l?.map((p) => (p.id === renameTarget.id ? { ...p, title: t.slice(0, 200) } : p)) ?? l);
    setRenameTarget(null);
    toast.success("Project renamed");
  }

  async function remove() {
    if (!deleteTarget) return;
    setDeleting(true);
    // Clean up any uploaded source file, then delete the project (cascades to assets).
    const { data: src } = await supabase.from("source_contents").select("file_path").eq("project_id", deleteTarget.id);
    const paths = (src ?? []).map((s: { file_path: string | null }) => s.file_path).filter(Boolean) as string[];
    if (paths.length) await supabase.storage.from("sources").remove(paths);
    const { error } = await supabase.from("projects").delete().eq("id", deleteTarget.id);
    setDeleting(false);
    if (error) return toast.error(errMessage(error));
    setProjects((l) => l?.filter((p) => p.id !== deleteTarget.id) ?? l);
    setDeleteTarget(null);
    toast.success("Project deleted");
  }

  return (
    <div className="animate-fade-up">
      <PageHeader title="My Projects" description="Every source you've recast, in one place."
        actions={<Button variant="brand" onClick={() => navigate("/app/create")}><Plus className="h-4 w-4" /> New project</Button>} />

      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="relative lg:col-span-2">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => { const p = new URLSearchParams(params); e.target.value ? p.set("q", e.target.value) : p.delete("q"); setParams(p, { replace: true }); }} placeholder="Search projects…" className="pl-9" />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger aria-label="Filter by status"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem><SelectItem value="ready">Ready</SelectItem>
            <SelectItem value="generating">Generating</SelectItem><SelectItem value="failed">Failed</SelectItem><SelectItem value="draft">Draft</SelectItem>
          </SelectContent>
        </Select>
        <div className="grid grid-cols-2 gap-3">
          <Select value={sourceType} onValueChange={setSourceType}>
            <SelectTrigger aria-label="Filter by source"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All sources</SelectItem><SelectItem value="text">Text</SelectItem>
              <SelectItem value="file">File</SelectItem><SelectItem value="youtube">YouTube</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
            <SelectTrigger aria-label="Sort"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem><SelectItem value="oldest">Oldest</SelectItem><SelectItem value="name">Name A–Z</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {error ? <ErrorState message={error} onRetry={load} /> : projects === null ? (
        <div className="space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
      ) : projects.length === 0 ? (
        <EmptyState icon={FolderKanban} title="No projects yet" description="Create your first project from an article, transcript or file." action={<Button variant="brand" onClick={() => navigate("/app/create")}>Create content</Button>} />
      ) : shown.length === 0 ? (
        <EmptyState icon={Search} title="No matching projects" description="Try a different search or clear the filters." action={<Button variant="outline" onClick={() => { setStatus("all"); setSourceType("all"); setParams({}, { replace: true }); }}>Clear filters</Button>} />
      ) : (
        <div className="space-y-3">
          {shown.map((p) => (
            <Card key={p.id} className="flex items-center gap-3 p-4 transition hover:-translate-y-0.5">
              <Link to={`/app/projects/${p.id}`} className="min-w-0 flex-1">
                <p className="truncate font-medium">{p.title}</p>
                <p className="mt-1 text-xs capitalize text-muted-foreground">
                  {p.source_type === "youtube" ? "YouTube" : p.source_type} · {formatDate(p.created_at)} · {p.content_assets?.[0]?.count ?? 0} assets
                </p>
              </Link>
              <StatusBadge status={p.status} />
              <DropdownMenu>
                <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" aria-label="Project actions"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onSelect={() => navigate(`/app/projects/${p.id}`)}>Open</DropdownMenuItem>
                  {canEdit && <DropdownMenuItem onSelect={() => { setRenameTarget(p); setRenameValue(p.title); }}><Pencil className="h-4 w-4" /> Rename</DropdownMenuItem>}
                  {canEdit && <DropdownMenuItem destructive onSelect={() => setDeleteTarget(p)}><Trash2 className="h-4 w-4" /> Delete</DropdownMenuItem>}
                </DropdownMenuContent>
              </DropdownMenu>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!renameTarget} onOpenChange={(o) => !o && setRenameTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Rename project</DialogTitle></DialogHeader>
          <Input autoFocus value={renameValue} maxLength={200} onChange={(e) => setRenameValue(e.target.value)} onKeyDown={(e) => e.key === "Enter" && rename()} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRenameTarget(null)}>Cancel</Button>
            <Button onClick={rename} disabled={renaming}>{renaming && <Spinner />} Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)} destructive loading={deleting}
        title={`Delete "${deleteTarget?.title ?? ""}"?`}
        description="This permanently deletes the project, its source and all generated assets. Credits already used are not refunded."
        confirmLabel="Delete project" onConfirm={remove}
      />
    </div>
  );
}

import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { useTheme } from "@/contexts/ThemeContext";
import { PLANS } from "@/lib/config";
import { errMessage } from "@/lib/utils";
import { PageHeader, Spinner } from "@/components/ui/misc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

export default function Settings() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile, signOut } = useAuth();
  const { current, workspaces, refresh } = useWorkspace();
  const { theme, toggle } = useTheme();
  const [name, setName] = useState("");
  const [wsName, setWsName] = useState("");
  const [savingP, setSavingP] = useState(false);
  const [savingW, setSavingW] = useState(false);
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [savingPw, setSavingPw] = useState(false);
  const [members, setMembers] = useState<{ user_id: string; role: string }[]>([]);

  useEffect(() => { setName(profile?.full_name ?? ""); }, [profile?.full_name]);
  useEffect(() => { setWsName(current?.name ?? ""); }, [current?.id, current?.name]);
  useEffect(() => {
    if (!current) return;
    supabase.from("workspace_members").select("user_id, role").eq("workspace_id", current.id).then(({ data }) => setMembers(data ?? []));
  }, [current?.id]);

  const canRename = current?.role === "owner" || current?.role === "admin";
  const plan = PLANS.find((p) => p.id === current?.plan);

  async function saveProfile() {
    if (!user) return;
    if (name.trim().length < 2) return toast.error("Enter your name.");
    setSavingP(true);
    const { error } = await supabase.from("profiles").update({ full_name: name.trim().slice(0, 120) }).eq("id", user.id);
    setSavingP(false);
    if (error) return toast.error(errMessage(error));
    await refreshProfile();
    toast.success("Profile saved");
  }

  async function saveWorkspace() {
    if (!current) return;
    if (!wsName.trim()) return toast.error("Workspace name can't be empty.");
    setSavingW(true);
    const { error } = await supabase.from("workspaces").update({ name: wsName.trim().slice(0, 80) }).eq("id", current.id);
    setSavingW(false);
    if (error) return toast.error(errMessage(error));
    await refresh();
    toast.success("Workspace renamed");
  }

  async function changePassword() {
    if (pw.length < 8) return toast.error("Password must be at least 8 characters.");
    if (pw !== pw2) return toast.error("Passwords don't match.");
    setSavingPw(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setSavingPw(false);
    if (error) return toast.error(error.message);
    setPw(""); setPw2("");
    toast.success("Password updated");
  }

  return (
    <div className="animate-fade-up max-w-3xl space-y-6">
      <PageHeader title="Settings" description="Manage your profile, workspace and appearance." />

      <Card>
        <CardHeader><CardTitle>Profile</CardTitle><CardDescription>{user?.email}</CardDescription></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5"><Label htmlFor="pn">Full name</Label><Input id="pn" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} /></div>
          <Button onClick={saveProfile} disabled={savingP || name.trim() === (profile?.full_name ?? "")}>{savingP && <Spinner />} Save profile</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Workspace</CardTitle><CardDescription>Your role: <b className="capitalize">{current?.role}</b> · {workspaces.length} workspace{workspaces.length === 1 ? "" : "s"}</CardDescription></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5"><Label htmlFor="wn">Workspace name</Label><Input id="wn" value={wsName} maxLength={80} disabled={!canRename} onChange={(e) => setWsName(e.target.value)} /></div>
          {canRename ? (
            <Button onClick={saveWorkspace} disabled={savingW || wsName.trim() === current?.name}>{savingW && <Spinner />} Save workspace</Button>
          ) : <p className="text-xs text-muted-foreground">Only owners and admins can rename the workspace.</p>}
          <p className="text-xs text-muted-foreground">Members: {members.length}. Inviting teammates isn't available in this version.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Plan</CardTitle><CardDescription>Billing isn't enabled yet.</CardDescription></CardHeader>
        <CardContent className="flex items-center justify-between gap-3">
          <div>
            <p className="flex items-center gap-2 font-semibold">{plan?.name ?? current?.plan} <Badge>Current</Badge></p>
            <p className="text-sm text-muted-foreground">{current?.credits ?? 0} credits remaining</p>
          </div>
          <Button variant="outline" onClick={() => navigate("/pricing")}>View proposed plans</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Appearance</CardTitle></CardHeader>
        <CardContent className="flex items-center justify-between">
          <p className="text-sm">Theme: <b className="capitalize">{theme}</b></p>
          <Button variant="outline" onClick={toggle}>Switch to {theme === "dark" ? "light" : "dark"}</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Security</CardTitle><CardDescription>Change your password.</CardDescription></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5"><Label htmlFor="np">New password</Label><Input id="np" type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} /></div>
            <div className="space-y-1.5"><Label htmlFor="np2">Confirm</Label><Input id="np2" type="password" autoComplete="new-password" value={pw2} onChange={(e) => setPw2(e.target.value)} /></div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={changePassword} disabled={savingPw || !pw}>{savingPw && <Spinner />} Update password</Button>
            <Button variant="outline" onClick={async () => { await signOut(); navigate("/"); }}>Sign out</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

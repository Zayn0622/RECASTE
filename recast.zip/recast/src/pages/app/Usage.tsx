import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Coins, History, TrendingDown } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { PLANS } from "@/lib/config";
import { PLATFORM_MAP } from "@/lib/platforms";
import { formatDate } from "@/lib/utils";
import { PageHeader, EmptyState, ErrorState, Skeleton } from "@/components/ui/misc";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Generation, LedgerEntry } from "@/types/db";

export default function Usage() {
  const { current } = useWorkspace();
  const [ledger, setLedger] = useState<LedgerEntry[] | null>(null);
  const [gens, setGens] = useState<(Generation & { projects: { title: string } | null })[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!current) return;
    setError(null);
    const [l, g] = await Promise.all([
      supabase.from("usage_ledger").select("*").eq("workspace_id", current.id).order("created_at", { ascending: false }).limit(500),
      supabase.from("generations").select("*, projects(title)").eq("workspace_id", current.id).order("created_at", { ascending: false }).limit(25),
    ]);
    if (l.error || g.error) return setError((l.error ?? g.error)!.message);
    setLedger((l.data as LedgerEntry[]) ?? []);
    setGens((g.data as any) ?? []);
  }, [current?.id]);

  useEffect(() => { setLedger(null); setGens(null); load(); }, [load]);

  const { consumed, refunded, byFormat } = useMemo(() => {
    let consumed = 0, refunded = 0;
    const byFormat: Record<string, number> = {};
    for (const e of ledger ?? []) {
      if (e.kind === "deduction") { consumed += e.amount; }
      if (e.kind === "refund") { refunded += e.amount; }
    }
    // Net spend per format: deductions minus refunds, split evenly across the formats of each charge
    for (const e of ledger ?? []) {
      if (e.kind === "grant") continue;
      const plats = e.platforms ?? [];
      if (!plats.length) continue;
      const share = (e.kind === "deduction" ? e.amount : -e.amount) / plats.length;
      for (const p of plats) byFormat[p] = (byFormat[p] ?? 0) + share;
    }
    return { consumed, refunded, byFormat };
  }, [ledger]);

  const plan = PLANS.find((p) => p.id === current?.plan);
  const formatRows = Object.entries(byFormat).filter(([, v]) => v > 0.001).sort((a, b) => b[1] - a[1]);
  const maxFormat = formatRows[0]?.[1] ?? 1;

  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader title="Usage & Credits" description="Every credit movement is recorded server-side and can't be edited from the browser." />
      {error && <ErrorState message={error} onRetry={load} />}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card><CardContent className="p-5 sm:p-6">
          <div className="flex items-center gap-2 text-sm text-muted-foreground"><Coins className="h-4 w-4" /> Available credits</div>
          <p className="mt-1 text-3xl font-bold">{current?.credits ?? 0}</p>
          <p className="mt-1 text-xs text-muted-foreground">Plan: <b>{plan?.name ?? current?.plan}</b></p>
        </CardContent></Card>
        <Card><CardContent className="p-5 sm:p-6">
          <div className="flex items-center gap-2 text-sm text-muted-foreground"><TrendingDown className="h-4 w-4" /> Credits consumed</div>
          {ledger ? <p className="mt-1 text-3xl font-bold">{Math.max(0, consumed - refunded)}</p> : <Skeleton className="mt-2 h-8 w-16" />}
          <p className="mt-1 text-xs text-muted-foreground">Net of refunds{refunded > 0 ? ` (${refunded} refunded)` : ""}</p>
        </CardContent></Card>
        <Card><CardContent className="p-5 sm:p-6">
          <div className="flex items-center gap-2 text-sm text-muted-foreground"><History className="h-4 w-4" /> Generations</div>
          {gens ? <p className="mt-1 text-3xl font-bold">{gens.filter((g) => g.status === "completed").length}</p> : <Skeleton className="mt-2 h-8 w-16" />}
          <p className="mt-1 text-xs text-muted-foreground">Completed (latest 25 shown)</p>
        </CardContent></Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Usage by content format</CardTitle></CardHeader>
          <CardContent>
            {ledger === null ? <Skeleton className="h-32" /> : formatRows.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">No usage yet. Credits spent will be split across the formats you generate.</p>
            ) : (
              <ul className="space-y-3">
                {formatRows.map(([id, v]) => (
                  <li key={id}>
                    <div className="mb-1 flex justify-between text-sm"><span>{PLATFORM_MAP[id]?.label ?? id}</span><b>{Math.round(v * 10) / 10}</b></div>
                    <div className="h-2 overflow-hidden rounded-full bg-muted"><div className="h-full bg-brand-gradient" style={{ width: `${(v / maxFormat) * 100}%` }} /></div>
                  </li>
                ))}
              </ul>
            )}
            {formatRows.length > 0 && <p className="mt-4 text-xs text-muted-foreground">A charge covering several formats is split evenly between them.</p>}
          </CardContent>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader><CardTitle>Credit ledger</CardTitle></CardHeader>
          <CardContent>
            {ledger === null ? <Skeleton className="h-40" /> : ledger.length === 0 ? (
              <EmptyState icon={Coins} title="No credit activity yet" description="Grants, charges and refunds will be listed here." />
            ) : (
              <div className="max-h-[420px] overflow-y-auto">
                <ul className="divide-y">
                  {ledger.map((e) => (
                    <li key={e.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                      <div className="min-w-0">
                        <p className="truncate">{e.reason ?? e.kind}</p>
                        <p className="text-xs text-muted-foreground">{formatDate(e.created_at)} · balance {e.balance_after}</p>
                      </div>
                      <Badge variant={e.kind === "deduction" ? "danger" : "success"}>{e.kind === "deduction" ? "−" : "+"}{e.amount}</Badge>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Generation history</CardTitle></CardHeader>
        <CardContent>
          {gens === null ? <Skeleton className="h-32" /> : gens.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No generations yet.</p>
          ) : (
            <ul className="divide-y">
              {gens.map((g) => (
                <li key={g.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
                  <div className="min-w-0">
                    <Link to={`/app/projects/${g.project_id}`} className="block truncate font-medium hover:underline">{g.projects?.title ?? "Project"}</Link>
                    <p className="text-xs text-muted-foreground">{formatDate(g.created_at)} · {g.platforms.map((p) => PLATFORM_MAP[p]?.short ?? p).join(", ")}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{g.credits_charged} credit{g.credits_charged === 1 ? "" : "s"}</span>
                    <Badge variant={g.status === "completed" ? "success" : g.status === "failed" ? "danger" : "warning"}>{g.status}</Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex flex-col gap-3 p-5 sm:p-6 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="font-semibold">Need more credits?</p>
            <p className="text-sm text-muted-foreground">Paid plans aren't available yet — checkout hasn't been enabled. You can review the proposed plans.</p>
          </div>
          <Button asChild variant="outline"><Link to="/pricing">View proposed plans</Link></Button>
        </CardContent>
      </Card>
    </div>
  );
}

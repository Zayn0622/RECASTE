import { useEffect, useState, type FormEvent } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Briefcase, Building2, Clapperboard, Sparkles, User } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Spinner } from "@/components/ui/misc";
import { Logo } from "@/components/Logo";
import { cn, errMessage } from "@/lib/utils";

const USE_CASES = [
  { id: "creator", label: "Creator / YouTuber", icon: Clapperboard },
  { id: "freelancer", label: "Freelancer", icon: User },
  { id: "agency", label: "Agency", icon: Building2 },
  { id: "business", label: "Business / Brand", icon: Briefcase },
  { id: "other", label: "Something else", icon: Sparkles },
] as const;

export default function Onboarding() {
  const navigate = useNavigate();
  const { profile, user, refreshProfile } = useAuth();
  const { current, refresh, canEdit } = useWorkspace();
  const [name, setName] = useState("");
  const [workspaceName, setWorkspaceName] = useState("");
  const [useCase, setUseCase] = useState<string>("creator");
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (profile?.full_name) setName(profile.full_name); }, [profile?.full_name]);
  useEffect(() => { if (current) setWorkspaceName(current.name); }, [current?.id]);

  if (profile?.onboarded) return <Navigate to="/app" replace />;

  async function finish(skip: boolean, e?: FormEvent) {
    e?.preventDefault();
    if (!user) return;
    setSaving(true);
    try {
      const patch: Record<string, unknown> = { onboarded: true };
      if (!skip) {
        if (name.trim()) patch.full_name = name.trim().slice(0, 120);
        patch.use_case = useCase;
      }
      const { error } = await supabase.from("profiles").update(patch).eq("id", user.id);
      if (error) throw error;

      if (!skip && current && canEdit && workspaceName.trim() && workspaceName.trim() !== current.name) {
        const { error: wsErr } = await supabase.from("workspaces").update({ name: workspaceName.trim().slice(0, 80) }).eq("id", current.id);
        if (wsErr) throw wsErr;
        await refresh();
      }
      await refreshProfile();
      navigate("/app", { replace: true });
    } catch (err) {
      toast.error(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="hero-glow flex min-h-screen flex-col items-center justify-center p-6">
      <Logo />
      <form onSubmit={(e) => finish(false, e)} className="mt-8 w-full max-w-lg rounded-3xl border bg-card p-6 shadow-soft sm:p-8">
        <h1 className="text-2xl font-bold tracking-tight">Let's set up your workspace</h1>
        <p className="mt-1 text-sm text-muted-foreground">Takes 20 seconds. You can change everything later in Settings.</p>

        <div className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="n">Your name</Label>
            <Input id="n" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="w">Workspace name</Label>
            <Input id="w" value={workspaceName} onChange={(e) => setWorkspaceName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>What best describes you?</Label>
            <div className="grid grid-cols-2 gap-2">
              {USE_CASES.map((u) => (
                <button
                  type="button"
                  key={u.id}
                  onClick={() => setUseCase(u.id)}
                  className={cn(
                    "flex items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-sm transition",
                    useCase === u.id ? "border-primary bg-accent text-accent-foreground" : "hover:bg-muted",
                  )}
                >
                  <u.icon className="h-4 w-4" /> {u.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-7 flex flex-col-reverse gap-2 sm:flex-row sm:justify-between">
          <Button type="button" variant="ghost" onClick={() => finish(true)} disabled={saving}>Skip for now</Button>
          <Button type="submit" variant="brand" disabled={saving}>{saving && <Spinner />} Continue to dashboard</Button>
        </div>
      </form>
    </div>
  );
}

import { useEffect, useState } from "react";
import { Link, Navigate, useLocation } from "react-router-dom";
import { MailCheck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { AuthShell } from "@/components/layout/AuthShell";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/misc";

export default function VerifyEmail() {
  const location = useLocation();
  const { session, user, loading } = useAuth();
  const stateEmail = (location.state as { email?: string } | null)?.email;
  const email = stateEmail ?? user?.email ?? "";
  const [sending, setSending] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  if (loading) return <div className="flex min-h-screen items-center justify-center"><Spinner className="h-6 w-6 text-primary" /></div>;
  // Once the email link is clicked, Supabase signs the user in and we move on.
  if (session && (session.user.email_confirmed_at || session.user.confirmed_at)) return <Navigate to="/app" replace />;

  async function resend() {
    if (!email) return toast.error("Enter your email on the sign-up page first.");
    setSending(true);
    const { error } = await supabase.auth.resend({
      type: "signup",
      email,
      options: { emailRedirectTo: `${window.location.origin}/verify-email` },
    });
    setSending(false);
    if (error) return toast.error(error.message);
    toast.success("Verification email sent");
    setCooldown(60);
  }

  return (
    <AuthShell
      title="Verify your email"
      subtitle={email ? `We sent a confirmation link to ${email}.` : "We sent you a confirmation link."}
      footer={<Link to="/login" className="font-medium text-primary hover:underline">Back to log in</Link>}
    >
      <div className="rounded-2xl border bg-card p-6 text-center">
        <MailCheck className="mx-auto h-9 w-9 text-primary" />
        <p className="mt-3 text-sm text-muted-foreground">Click the link in the email to activate your account. It may take a minute — check spam too.</p>
        <Button variant="outline" className="mt-5 w-full" onClick={resend} disabled={sending || cooldown > 0 || !email}>
          {sending && <Spinner />} {cooldown > 0 ? `Resend in ${cooldown}s` : "Resend email"}
        </Button>
      </div>
    </AuthShell>
  );
}

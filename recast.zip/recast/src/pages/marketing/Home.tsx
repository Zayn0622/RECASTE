import { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { ArrowRight, BrainCircuit, CalendarDays, FileUp, Layers, Palette, PenLine, ShieldCheck, Sparkles, Wand2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductPreview } from "@/components/marketing/ProductPreview";
import { PricingCards } from "@/components/marketing/PricingCards";
import { Faq } from "@/components/marketing/Faq";
import { PLATFORMS } from "@/lib/platforms";

const STEPS = [
  { icon: FileUp, title: "Add your source", text: "Paste text, upload a PDF or TXT, or add a YouTube link with public captions." },
  { icon: Layers, title: "Pick your formats", text: "Choose Reels, Shorts, LinkedIn, carousels, X threads, blog articles and captions." },
  { icon: Wand2, title: "Set audience & voice", text: "Define the goal, tone, language, length and your saved brand voice." },
  { icon: PenLine, title: "Edit & ship", text: "Refine every asset in the workspace, copy it, export it, or plan it on your calendar." },
];

const FEATURES = [
  { icon: BrainCircuit, title: "Analyses before it writes", text: "Extracts key ideas, audience and objective first — so output is rewritten for each platform, not just reformatted." },
  { icon: Palette, title: "Brand voice profiles", text: "Save tone, style, preferred and banned words. Switch profiles per client or channel." },
  { icon: PenLine, title: "Editable asset cards", text: "Every asset has its own card: edit, save drafts, copy, export, or regenerate with confirmation." },
  { icon: CalendarDays, title: "Content calendar", text: "Plan drafts on a monthly or weekly calendar. Planning only — no auto-posting." },
  { icon: ShieldCheck, title: "Secure by design", text: "Workspace isolation with row-level security, private file storage, and server-side credit accounting." },
  { icon: Sparkles, title: "Fair credits", text: "Transparent credit estimates up front, and automatic refunds if a generation fails." },
];

const USE_CASES = [
  { title: "Creators & YouTubers", text: "Turn each video transcript into Shorts scripts, a thread, and a blog post." },
  { title: "Freelancers", text: "Repurpose client articles into a month of social content in one sitting." },
  { title: "Marketing agencies", text: "Separate workspaces and brand voices per client, with roles for your team." },
];

export default function Home() {
  const location = useLocation();
  useEffect(() => {
    if (location.hash) {
      const el = document.getElementById(location.hash.slice(1));
      el?.scrollIntoView({ behavior: "smooth" });
    }
  }, [location.hash]);

  return (
    <>
      <section className="hero-glow">
        <div className="container py-16 text-center sm:py-24">
          <span className="inline-flex items-center gap-2 rounded-full border bg-card px-3.5 py-1 text-xs font-medium text-muted-foreground shadow-soft">
            <Sparkles className="h-3.5 w-3.5 text-primary" /> One Source. Endless Content.
          </span>
          <h1 className="mx-auto mt-6 max-w-3xl text-4xl font-extrabold tracking-tight sm:text-6xl">
            One idea. A hundred ways to <span className="gradient-text">grow.</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Turn your content into platform-ready posts, videos, threads and articles with the power of AI.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button asChild size="lg" variant="brand"><Link to="/signup">Start Creating Free <ArrowRight className="h-4 w-4" /></Link></Button>
            <Button size="lg" variant="outline" onClick={() => document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })}>
              Explore Features
            </Button>
          </div>
          <div className="mt-14"><ProductPreview /></div>
        </div>
      </section>

      <section className="container py-16 sm:py-20" id="how">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight">How RECAST works</h2>
          <p className="mt-2 text-muted-foreground">From one source to a full content set in four steps.</p>
        </div>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((s, i) => (
            <div key={s.title} className="rounded-2xl border bg-card p-6 shadow-soft">
              <div className="mb-4 flex items-center justify-between">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-accent-foreground"><s.icon className="h-5 w-5" /></span>
                <span className="text-sm font-semibold text-muted-foreground">0{i + 1}</span>
              </div>
              <h3 className="font-semibold">{s.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y bg-card/40 py-16">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight">Every platform, natively</h2>
            <p className="mt-2 text-muted-foreground">Seven formats, each written the way that channel actually works.</p>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {PLATFORMS.map((p) => (
              <div key={p.id} className="flex items-start gap-3 rounded-2xl border bg-card p-4 shadow-soft">
                <p.icon className={`mt-0.5 h-5 w-5 shrink-0 ${p.tint}`} />
                <div>
                  <p className="text-sm font-semibold">{p.label}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{p.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container py-16 sm:py-20" id="features">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight">Built like a workspace, not a chatbot</h2>
          <p className="mt-2 text-muted-foreground">Everything you need to go from raw source to ready-to-publish.</p>
        </div>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="rounded-2xl border bg-card p-6 shadow-soft transition hover:-translate-y-0.5">
              <span className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-brand-gradient text-white"><f.icon className="h-5 w-5" /></span>
              <h3 className="font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y bg-card/40 py-16">
        <div className="container">
          <h2 className="text-center text-3xl font-bold tracking-tight">Made for people who publish</h2>
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {USE_CASES.map((u) => (
              <div key={u.title} className="rounded-2xl border bg-card p-6 shadow-soft">
                <h3 className="font-semibold">{u.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{u.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container py-16 sm:py-20" id="pricing">
        <div className="mx-auto mb-10 max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight">Simple, creator-friendly pricing</h2>
          <p className="mt-2 text-muted-foreground">Start free. Upgrade when your content engine needs more fuel.</p>
        </div>
        <PricingCards />
      </section>

      <section className="container pb-16 sm:pb-24" id="faq">
        <h2 className="mb-8 text-center text-3xl font-bold tracking-tight">Frequently asked questions</h2>
        <Faq />
      </section>

      <section className="container pb-20">
        <div className="rounded-3xl bg-navy px-6 py-14 text-center text-white">
          <h2 className="text-3xl font-bold tracking-tight">Ready to recast your first idea?</h2>
          <p className="mx-auto mt-2 max-w-xl text-white/70">Create a free account and turn your next article or transcript into a full set of content.</p>
          <Button asChild size="lg" variant="brand" className="mt-6"><Link to="/signup">Start Creating Free</Link></Button>
        </div>
      </section>
    </>
  );
}

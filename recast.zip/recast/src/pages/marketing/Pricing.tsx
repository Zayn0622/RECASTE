import { PricingCards } from "@/components/marketing/PricingCards";
import { Faq } from "@/components/marketing/Faq";
import { CREDIT_COSTS } from "@/lib/config";

export default function Pricing() {
  return (
    <div className="hero-glow">
      <div className="container py-16 sm:py-20">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <h1 className="text-4xl font-extrabold tracking-tight">Pricing</h1>
          <p className="mt-3 text-muted-foreground">Pick the plan that matches how much you publish. Start free, no card needed.</p>
        </div>
        <PricingCards />

        <div className="mx-auto mt-16 max-w-3xl rounded-2xl border bg-card p-6 shadow-soft">
          <h2 className="text-lg font-semibold">How credits are used</h2>
          <div className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
            <div className="flex justify-between rounded-xl bg-muted px-4 py-3"><span>Single platform</span><b>{CREDIT_COSTS.basic} credit</b></div>
            <div className="flex justify-between rounded-xl bg-muted px-4 py-3"><span>Multiple platforms</span><b>{CREDIT_COSTS.multi} credits</b></div>
            <div className="flex justify-between rounded-xl bg-muted px-4 py-3"><span>Long transcript</span><b>{CREDIT_COSTS.longTranscript} credits</b></div>
            <div className="flex justify-between rounded-xl bg-muted px-4 py-3"><span>Regenerate one asset</span><b>{CREDIT_COSTS.regeneration} credit</b></div>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">Credit costs are provisional and may change. Failed generations are refunded automatically.</p>
        </div>

        <h2 className="mb-6 mt-16 text-center text-2xl font-bold tracking-tight">Questions</h2>
        <Faq />
      </div>
    </div>
  );
}

export type Role = "owner" | "admin" | "editor" | "viewer";

export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  onboarded: boolean;
  default_workspace_id: string | null;
}

export interface Workspace {
  id: string;
  name: string;
  owner_id: string;
  plan: "free" | "creator" | "pro" | "agency";
  credits: number;
  created_at: string;
}

export interface WorkspaceWithRole extends Workspace {
  role: Role;
}

export interface Brand {
  id: string;
  workspace_id: string;
  name: string;
  description: string | null;
  target_audience: string | null;
  preferred_tone: string | null;
  writing_style: string | null;
  words_to_use: string[];
  words_to_avoid: string[];
  instructions: string | null;
  is_default: boolean;
  created_at: string;
}

export interface Project {
  id: string;
  workspace_id: string;
  created_by: string;
  title: string;
  source_type: "text" | "file" | "youtube";
  status: "draft" | "generating" | "ready" | "failed";
  created_at: string;
  updated_at: string;
  content_assets?: { count: number }[];
}

export interface SourceContent {
  id: string;
  project_id: string;
  workspace_id: string;
  source_type: "text" | "file" | "youtube";
  title: string | null;
  text_content: string | null;
  file_path: string | null;
  file_name: string | null;
  youtube_url: string | null;
  word_count: number;
}

export interface ContentAsset {
  id: string;
  project_id: string;
  workspace_id: string;
  generation_id: string | null;
  platform: string;
  title: string | null;
  content: string;
  metadata: Record<string, unknown>;
  status: "draft" | "final";
  version: number;
  created_at: string;
  updated_at: string;
  projects?: { title: string } | null;
}

export interface LedgerEntry {
  id: string;
  workspace_id: string;
  kind: "grant" | "deduction" | "refund";
  amount: number;
  balance_after: number;
  reason: string | null;
  generation_id: string | null;
  platforms: string[];
  created_at: string;
}

export interface Generation {
  id: string;
  project_id: string;
  workspace_id: string;
  status: "pending" | "processing" | "completed" | "failed";
  platforms: string[];
  credits_charged: number;
  options: Record<string, unknown>;
  error: string | null;
  created_at: string;
}

export interface CalendarItem {
  id: string;
  workspace_id: string;
  asset_id: string | null;
  title: string;
  platform: string;
  scheduled_for: string; // date (YYYY-MM-DD)
  notes: string | null;
  status: "planned" | "done";
}

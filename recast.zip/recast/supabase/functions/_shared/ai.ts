// AI provider abstraction. Gemini is implemented; add OpenAI (or others) by
// implementing AiProvider and registering it in getProvider().

export interface AiRequest {
  system: string;
  user: string;
  maxOutputTokens?: number;
  temperature?: number;
}

export interface AiProvider {
  name: string;
  /** Returns the raw model text, expected to be a single JSON document. */
  generateJson(req: AiRequest): Promise<string>;
}

export class AiError extends Error {
  constructor(public code: "blocked" | "rate_limited" | "upstream" | "timeout" | "empty", message: string) {
    super(message);
  }
}

class GeminiProvider implements AiProvider {
  name = "gemini";
  constructor(private apiKey: string, private model: string) {}

  async generateJson(req: AiRequest): Promise<string> {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(this.model)}:generateContent`;
    const body = {
      systemInstruction: { parts: [{ text: req.system }] },
      contents: [{ role: "user", parts: [{ text: req.user }] }],
      generationConfig: {
        responseMimeType: "application/json",
        temperature: req.temperature ?? 0.8,
        maxOutputTokens: req.maxOutputTokens ?? 12000,
      },
    };

    let lastErr: AiError | null = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 110_000);
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-goog-api-key": this.apiKey },
          body: JSON.stringify(body),
          signal: ctrl.signal,
        });
        if (res.status === 429 || res.status >= 500) {
          lastErr = new AiError(res.status === 429 ? "rate_limited" : "upstream", `Gemini HTTP ${res.status}`);
          await new Promise((r) => setTimeout(r, 1500));
          continue;
        }
        if (!res.ok) {
          const t = await res.text();
          throw new AiError("upstream", `Gemini HTTP ${res.status}: ${t.slice(0, 300)}`);
        }
        const data = await res.json();
        if (data.promptFeedback?.blockReason) throw new AiError("blocked", `Blocked: ${data.promptFeedback.blockReason}`);
        const cand = data.candidates?.[0];
        if (cand?.finishReason === "SAFETY") throw new AiError("blocked", "Blocked by safety filter");
        const text = (cand?.content?.parts ?? []).map((p: { text?: string }) => p.text ?? "").join("");
        if (!text.trim()) throw new AiError("empty", "Empty model response");
        return text;
      } catch (e) {
        if (e instanceof AiError) {
          if (e.code === "blocked" || e.code === "empty") throw e;
          lastErr = e;
        } else if ((e as Error).name === "AbortError") {
          lastErr = new AiError("timeout", "AI request timed out");
        } else {
          lastErr = new AiError("upstream", (e as Error).message);
        }
      } finally {
        clearTimeout(timer);
      }
    }
    throw lastErr ?? new AiError("upstream", "Unknown AI error");
  }
}

/** Returns null when no provider is configured (the caller then uses demo mode or errors). */
export function getProvider(): AiProvider | null {
  const which = (Deno.env.get("AI_PROVIDER") ?? "gemini").toLowerCase();
  if (which === "gemini") {
    const key = Deno.env.get("GEMINI_API_KEY");
    if (!key) return null;
    return new GeminiProvider(key, Deno.env.get("GEMINI_MODEL") ?? "gemini-2.5-flash");
  }
  // OpenAI adapter intentionally not implemented in V1 — add a class implementing
  // AiProvider here (chat.completions with response_format json) and return it.
  return null;
}

export function isDemoMode(): boolean {
  return (Deno.env.get("DEMO_MODE") ?? "").toLowerCase() === "true";
}

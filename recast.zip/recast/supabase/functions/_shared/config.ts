import type { SupabaseClient } from "npm:@supabase/supabase-js@2";

// Authoritative server-side configuration. Values are read from the `app_config`
// table so they can be changed without redeploying; these are the fallbacks.
export interface ServerConfig {
  costs: { basic: number; multi: number; long_transcript: number; regeneration: number };
  limits: { long_source_words: number; max_source_words: number; max_file_mb: number };
}

const DEFAULTS: ServerConfig = {
  costs: { basic: 1, multi: 3, long_transcript: 5, regeneration: 1 },
  limits: { long_source_words: 3000, max_source_words: 20000, max_file_mb: 10 },
};

export async function loadConfig(admin: SupabaseClient): Promise<ServerConfig> {
  const { data } = await admin.from("app_config").select("key, value").in("key", ["credit_costs", "limits"]);
  const map = Object.fromEntries((data ?? []).map((r: { key: string; value: unknown }) => [r.key, r.value as Record<string, number>]));
  return {
    costs: { ...DEFAULTS.costs, ...(map.credit_costs ?? {}) },
    limits: { ...DEFAULTS.limits, ...(map.limits ?? {}) },
  };
}

export function generationCost(cfg: ServerConfig, platformCount: number, sourceWords: number): number {
  if (sourceWords > cfg.limits.long_source_words) return cfg.costs.long_transcript;
  return platformCount >= 2 ? cfg.costs.multi : cfg.costs.basic;
}

export const PLATFORM_IDS = [
  "instagram_reels", "youtube_shorts", "linkedin_post", "instagram_carousel",
  "x_thread", "blog_article", "captions",
] as const;
export type PlatformId = typeof PLATFORM_IDS[number];

export const TONES = ["Professional", "Conversational", "Educational", "Funny", "Inspirational", "Persuasive", "Storytelling"];
export const LENGTHS = ["Short", "Medium", "Long"];

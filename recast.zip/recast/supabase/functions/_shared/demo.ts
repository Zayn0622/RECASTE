import type { PlatformId } from "./config.ts";
import type { AiOutput } from "./validate.ts";

const BANNER = "⚠ DEMO MODE — placeholder built from your source with simple rules. This is NOT AI-generated. Connect an AI provider for real output.";

function sentences(text: string): string[] {
  return text.replace(/\s+/g, " ").split(/(?<=[.!?])\s+/).map((s) => s.trim()).filter((s) => s.length > 25).slice(0, 12);
}

/** Clearly-labelled sample output used only when no AI key is configured and DEMO_MODE=true. */
export function demoOutput(title: string, source: string, platforms: PlatformId[]): AiOutput {
  const s = sentences(source);
  const pick = (i: number) => s[i % Math.max(1, s.length)] ?? title;
  const ideas = [pick(0), pick(1), pick(2)];
  return {
    analysis: {
      summary: `[DEMO] First sentences of the source: ${s.slice(0, 2).join(" ")}`,
      key_ideas: ideas,
      audience: "Not analysed in demo mode",
      objective: "Not analysed in demo mode",
    },
    assets: platforms.map((p) => ({
      platform: p,
      title: `[DEMO] ${title}`,
      content: `${BANNER}\n\n${ideas.map((x, i) => `${i + 1}. ${x}`).join("\n")}`,
      hashtags: [],
      hooks: [],
    })),
  };
}

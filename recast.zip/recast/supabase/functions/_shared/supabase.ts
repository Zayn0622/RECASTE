import { createClient, type SupabaseClient, type User } from "npm:@supabase/supabase-js@2";

// Service-role client: bypasses RLS. Only ever used server-side, and only after
// the caller's identity and workspace membership have been verified in code.
export function adminClient(): SupabaseClient {
  const url = Deno.env.get("SUPABASE_URL")!;
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

export async function getUser(req: Request, admin: SupabaseClient): Promise<User | null> {
  const header = req.headers.get("Authorization") ?? "";
  const token = header.replace(/^Bearer\s+/i, "").trim();
  if (!token) return null;
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data.user) return null;
  return data.user;
}

export type WorkspaceRole = "owner" | "admin" | "editor" | "viewer";

export async function getRole(admin: SupabaseClient, workspaceId: string, userId: string): Promise<WorkspaceRole | null> {
  const { data } = await admin
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  return (data?.role as WorkspaceRole) ?? null;
}

export const CAN_EDIT: WorkspaceRole[] = ["owner", "admin", "editor"];

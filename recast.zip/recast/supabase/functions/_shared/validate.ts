import { z } from "npm:zod@3";
import { PLATFORM_IDS, TONES, LENGTHS, type PlatformId } from "./config.ts";

export const uuid = z.string().uuid();

export const OptionsSchema = z.object({
  audience: z.string().trim().max(500).default(""),
  goal: z.string().trim().max(200).default(""),
  tone: z.enum(TONES as [string, ...string[]]).default("Conversational"),
  language: z.string().trim().min(2).max(40).default("English"),
  length: z.enum(LENGTHS as [string, ...string[]]).default("Medium"),
  brand_id: uuid.nullable().optional(),
  instructions: z.string().trim().max(2000).default(""),
});

export const RequestSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("status") }),
  z.object({
    action: z.literal("generate"),
    project_id: uuid,
    idempotency_key: uuid,
    platforms: z.array(z.enum(PLATFORM_IDS)).min(1).max(PLATFORM_IDS.length),
    options: OptionsSchema,
  }),
  z.object({
    action: z.literal("regenerate"),
    project_id: uuid,
    asset_id: uuid,
    idempotency_key: uuid,
    options: OptionsSchema.partial().optional(),
  }),
]);

const AssetOut = z.object({
  platform: z.enum(PLATFORM_IDS),
  title: z.string().trim().min(1).max(300),
  content: z.string().trim().min(20).max(60000),
  hashtags: z.array(z.string().trim().max(60)).max(30).optional().default([]),
  hooks: z.array(z.string().trim().max(300)).max(10).optional().default([]),
});

export const OutputSchema = z.object({
  analysis: z.object({
    summary: z.string().trim().max(3000),
    key_ideas: z.array(z.string().trim().max(600)).min(1).max(20),
    audience: z.string().trim().max(600),
    objective: z.string().trim().max(600),
  }),
  assets: z.array(AssetOut).min(1),
});
export type AiOutput = z.infer<typeof OutputSchema>;
export type AiAsset = z.infer<typeof AssetOut>;

/** Tolerant JSON extraction (handles accidental code fences / leading text). */
export function parseJson(raw: string): unknown {
  let t = raw.trim();
  t = t.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "").trim();
  try {
    return JSON.parse(t);
  } catch {
    const s = t.indexOf("{");
    const e = t.lastIndexOf("}");
    if (s >= 0 && e > s) return JSON.parse(t.slice(s, e + 1));
    throw new Error("Model did not return valid JSON");
  }
}

export function wordCount(text: string): number {
  const t = text.trim();
  return t ? t.split(/\s+/).length : 0;
}

/** Fraction of an asset's 8-word shingles that appear verbatim in the source. */
export function verbatimOverlap(asset: string, source: string): number {
  const norm = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter(Boolean);
  const a = norm(asset);
  const s = norm(source);
  const N = 8;
  if (a.length < N || s.length < N) return 0;
  const src = new Set<string>();
  for (let i = 0; i <= s.length - N; i++) src.add(s.slice(i, i + N).join(" "));
  let hit = 0;
  const total = a.length - N + 1;
  for (let i = 0; i < total; i++) if (src.has(a.slice(i, i + N).join(" "))) hit++;
  return hit / total;
}

export type { PlatformId };

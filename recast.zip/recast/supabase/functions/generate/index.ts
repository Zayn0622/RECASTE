// RECAST — secure AI generation endpoint.
// Verifies the caller and workspace membership, accounts for credits atomically,
// calls the AI provider server-side, validates the output and persists results.

import type { SupabaseClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders, fail, json } from "../_shared/cors.ts";
import { adminClient, CAN_EDIT, getRole, getUser } from "../_shared/supabase.ts";
import { generationCost, loadConfig, type PlatformId, type ServerConfig } from "../_shared/config.ts";
import { AiError, getProvider, isDemoMode, type AiProvider } from "../_shared/ai.ts";
import { buildSystemPrompt, buildUserPrompt, type BrandVoice, type GenOptions } from "../_shared/prompts.ts";
import {
  OutputSchema, RequestSchema, parseJson, verbatimOverlap, wordCount, type AiAsset, type AiOutput,
} from "../_shared/validate.ts";
import { demoOutput } from "../_shared/demo.ts";
import { extractText, getDocumentProxy } from "npm:unpdf@0.12.1";

class HttpError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

const MIN_SOURCE_WORDS = 30;
const STALE_JOB_MINUTES = 10;
const BUSY_WINDOW_MINUTES = 3;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return fail(405, "method_not_allowed", "Use POST.");

  const admin = adminClient();
  const user = await getUser(req, admin);
  if (!user) return fail(401, "unauthorized", "Please sign in again.");

  let parsed;
  try {
    parsed = RequestSchema.safeParse(await req.json());
  } catch {
    return fail(400, "invalid_request", "Request body must be valid JSON.");
  }
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    return fail(400, "invalid_request", `Invalid input: ${issue.path.join(".") || "body"} — ${issue.message}`);
  }
  const body = parsed.data;
  const provider = getProvider();
  const demo = !provider && isDemoMode();

  if (body.action === "status") {
    return json({ ok: true, ai_configured: !!provider, demo_mode: demo, provider: provider?.name ?? null });
  }

  if (!provider && !demo) {
    return fail(
      503,
      "ai_not_configured",
      "AI generation isn't configured yet. The site owner needs to set GEMINI_API_KEY (or enable DEMO_MODE) on the server.",
    );
  }

  try {
    const cfg = await loadConfig(admin);
    if (body.action === "generate") return await handleGenerate(admin, user.id, body, cfg, provider, demo);
    return await handleRegenerate(admin, user.id, body, cfg, provider, demo);
  } catch (e) {
    if (e instanceof HttpError) return fail(e.status, e.code, e.message);
    console.error("generate: unhandled", e);
    return fail(500, "internal_error", "Something went wrong on our side. No credits were kept for this request.");
  }
});

// ───────────────────────────────────────────────────────────────────────────
type Body = ReturnType<typeof RequestSchema.parse>;
type GenerateBody = Extract<Body, { action: "generate" }>;
type RegenBody = Extract<Body, { action: "regenerate" }>;

async function loadProject(admin: SupabaseClient, userId: string, projectId: string) {
  const { data: project } = await admin.from("projects").select("*").eq("id", projectId).maybeSingle();
  // 404 for both "missing" and "not yours" so existence isn't leaked
  if (!project) throw new HttpError(404, "not_found", "Project not found.");
  const role = await getRole(admin, project.workspace_id, userId);
  if (!role) throw new HttpError(404, "not_found", "Project not found.");
  if (!CAN_EDIT.includes(role)) throw new HttpError(403, "forbidden", "Your role in this workspace can't generate content.");
  return project;
}

async function loadSource(admin: SupabaseClient, project: { id: string; workspace_id: string }, cfg: ServerConfig) {
  const { data: src } = await admin
    .from("source_contents").select("*").eq("project_id", project.id)
    .order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (!src) throw new HttpError(422, "no_source", "This project has no source content.");

  let text: string = src.text_content ?? "";

  if (!text.trim() && src.file_path) {
    // The path is client-supplied: it must live inside this project's workspace folder.
    if (!String(src.file_path).startsWith(`${project.workspace_id}/`)) {
      throw new HttpError(403, "forbidden", "Invalid file location.");
    }
    const { data: blob, error } = await admin.storage.from("sources").download(src.file_path);
    if (error || !blob) throw new HttpError(422, "file_unreadable", "We couldn't read the uploaded file. Please upload it again.");
    if (blob.size > cfg.limits.max_file_mb * 1024 * 1024) throw new HttpError(413, "file_too_large", "The uploaded file is too large.");
    const name = String(src.file_name ?? src.file_path).toLowerCase();
    if (name.endsWith(".pdf")) {
      try {
        const pdf = await getDocumentProxy(new Uint8Array(await blob.arrayBuffer()));
        const out = await extractText(pdf, { mergePages: true });
        text = Array.isArray(out.text) ? out.text.join("\n") : out.text;
      } catch (e) {
        console.error("pdf extract failed", e);
        throw new HttpError(422, "pdf_unreadable", "We couldn't read text from this PDF. If it's a scanned image, paste the text instead.");
      }
    } else if (name.endsWith(".txt")) {
      text = await blob.text();
    } else {
      throw new HttpError(422, "unsupported_file", "Only PDF and TXT files are supported.");
    }
    text = text.replace(/\u0000/g, "").trim();
    if (text) {
      await admin.from("source_contents")
        .update({ text_content: text.slice(0, 300000), word_count: wordCount(text) }).eq("id", src.id);
    }
  }

  const words = wordCount(text);
  if (words < MIN_SOURCE_WORDS) {
    throw new HttpError(422, "source_too_short", `The source needs at least ${MIN_SOURCE_WORDS} words to generate meaningful content.`);
  }
  if (words > cfg.limits.max_source_words) {
    throw new HttpError(413, "source_too_large", `The source is ${words.toLocaleString()} words; the limit is ${cfg.limits.max_source_words.toLocaleString()}. Please shorten it.`);
  }
  return { title: (src.title as string) || "Untitled source", text, words };
}

async function loadBrand(admin: SupabaseClient, workspaceId: string, brandId?: string | null): Promise<BrandVoice | null> {
  if (!brandId) return null;
  const { data } = await admin.from("brands").select("*").eq("id", brandId).eq("workspace_id", workspaceId).maybeSingle();
  return (data as BrandVoice) ?? null;
}

/** Marks long-running jobs (e.g. crashed workers) as failed and refunds any charge. */
async function reapStaleJobs(admin: SupabaseClient, workspaceId: string) {
  const cutoff = new Date(Date.now() - STALE_JOB_MINUTES * 60_000).toISOString();
  const { data: stale } = await admin
    .from("generation_jobs").select("id, generation_id, charge_ledger_id")
    .eq("workspace_id", workspaceId).eq("status", "processing").lt("started_at", cutoff);
  for (const j of stale ?? []) {
    if (j.charge_ledger_id) await admin.rpc("refund_charge", { p_ledger_id: j.charge_ledger_id, p_reason: "Refund: generation timed out" });
    await admin.from("generation_jobs").update({ status: "failed", error: "timed_out", finished_at: new Date().toISOString() }).eq("id", j.id);
    if (j.generation_id) await admin.from("generations").update({ status: "failed", error: "timed_out" }).eq("id", j.generation_id);
  }
}

async function assertNotBusy(admin: SupabaseClient, workspaceId: string) {
  await reapStaleJobs(admin, workspaceId);
  const since = new Date(Date.now() - BUSY_WINDOW_MINUTES * 60_000).toISOString();
  const { count } = await admin
    .from("generation_jobs").select("id", { count: "exact", head: true })
    .eq("workspace_id", workspaceId).eq("status", "processing").gte("started_at", since);
  if ((count ?? 0) >= 2) {
    throw new HttpError(429, "busy", "Two generations are already running in this workspace. Please wait for one to finish.");
  }
}

/** Creates the job row; the unique (workspace, idempotency_key) index blocks duplicate submissions. */
async function createJob(
  admin: SupabaseClient,
  args: { workspaceId: string; userId: string; projectId: string; kind: "generate" | "regenerate"; key: string },
) {
  const { data, error } = await admin.from("generation_jobs").insert({
    workspace_id: args.workspaceId, user_id: args.userId, project_id: args.projectId,
    kind: args.kind, idempotency_key: args.key,
  }).select("*").single();
  if (error) {
    if ((error as { code?: string }).code === "23505") {
      const { data: existing } = await admin
        .from("generation_jobs").select("status, generation_id")
        .eq("workspace_id", args.workspaceId).eq("idempotency_key", args.key).maybeSingle();
      if (existing?.status === "completed" && args.kind === "generate") {
        throw new HttpError(409, "duplicate_completed", "This generation was already completed. Open the project to see it.");
      }
      throw new HttpError(409, "duplicate_request", "This request was already submitted. Refresh and check your project.");
    }
    throw error;
  }
  return data as { id: string };
}

async function charge(
  admin: SupabaseClient,
  args: { workspaceId: string; userId: string; amount: number; reason: string; generationId: string | null; platforms: string[] },
): Promise<{ ledgerId: string; balance: number }> {
  const { data, error } = await admin.rpc("charge_credits", {
    p_workspace: args.workspaceId, p_user: args.userId, p_amount: args.amount,
    p_reason: args.reason, p_generation: args.generationId, p_platforms: args.platforms,
  });
  if (error) {
    if (String(error.message).includes("insufficient_credits")) {
      throw new HttpError(402, "insufficient_credits", `Not enough credits. This needs ${args.amount}, check Usage & Credits.`);
    }
    throw error;
  }
  const row = Array.isArray(data) ? data[0] : data;
  return { ledgerId: row.out_ledger_id, balance: row.out_balance };
}

// ───────────────────────────────────────────────────────────────────────────
// AI invocation with validation, gap-filling and an anti-echo check
// ───────────────────────────────────────────────────────────────────────────
async function attempt(
  provider: AiProvider,
  args: { source: string; title: string; platforms: PlatformId[]; options: GenOptions; brand: BrandVoice | null; extra?: string },
): Promise<AiOutput> {
  let lastError = "";
  for (let i = 0; i < 2; i++) {
    const extra = [args.extra, i > 0 ? "Your previous reply was not valid. Return ONLY one valid JSON object that matches the schema exactly." : ""]
      .filter(Boolean).join("\n");
    const raw = await provider.generateJson({
      system: buildSystemPrompt(),
      user: buildUserPrompt({ ...args, extra }),
      temperature: 0.8,
    });
    try {
      const out = OutputSchema.safeParse(parseJson(raw));
      if (out.success) return out.data;
      lastError = out.error.issues[0]?.message ?? "schema mismatch";
    } catch (e) {
      lastError = (e as Error).message;
    }
  }
  throw new HttpError(502, "invalid_ai_output", `The AI returned an unusable response (${lastError}).`);
}

async function produce(
  provider: AiProvider,
  args: { source: string; title: string; platforms: PlatformId[]; options: GenOptions; brand: BrandVoice | null },
): Promise<AiOutput> {
  const first = await attempt(provider, args);
  const byPlatform = new Map<PlatformId, AiAsset>();
  const collect = (assets: AiAsset[]) => {
    for (const a of assets) {
      if (args.platforms.includes(a.platform as PlatformId) && !byPlatform.has(a.platform as PlatformId)) {
        byPlatform.set(a.platform as PlatformId, a);
      }
    }
  };
  collect(first.assets);

  // Fill any formats the model skipped
  const missing = args.platforms.filter((p) => !byPlatform.has(p));
  if (missing.length) {
    const r = await attempt(provider, { ...args, platforms: missing, extra: "Produce ONLY the listed formats." });
    collect(r.assets);
  }

  // Guard against "same text, different format"
  const echoed = args.platforms.filter((p) => {
    const a = byPlatform.get(p);
    return a && verbatimOverlap(a.content, args.source) > 0.45;
  });
  if (echoed.length) {
    try {
      const r = await attempt(provider, {
        ...args, platforms: echoed,
        extra: "IMPORTANT: a previous attempt copied too much wording from the source. Write entirely in fresh wording; never reuse any run of more than 5 consecutive words from the source.",
      });
      for (const a of r.assets) {
        const cur = byPlatform.get(a.platform as PlatformId);
        if (cur && echoed.includes(a.platform as PlatformId) &&
            verbatimOverlap(a.content, args.source) < verbatimOverlap(cur.content, args.source)) {
          byPlatform.set(a.platform as PlatformId, a);
        }
      }
    } catch (e) {
      console.warn("echo-retry failed; keeping original", (e as Error).message);
    }
  }

  const stillMissing = args.platforms.filter((p) => !byPlatform.has(p));
  if (stillMissing.length) {
    throw new HttpError(502, "incomplete_ai_output", `The AI didn't return: ${stillMissing.join(", ")}.`);
  }
  return { analysis: first.analysis, assets: args.platforms.map((p) => byPlatform.get(p)!) };
}

function friendlyAiError(e: unknown): HttpError {
  if (e instanceof HttpError) return e;
  if (e instanceof AiError) {
    switch (e.code) {
      case "blocked": return new HttpError(422, "content_blocked", "The AI provider declined to process this content. Try different source material.");
      case "rate_limited": return new HttpError(429, "ai_rate_limited", "The AI provider is busy right now. Please try again in a minute.");
      case "timeout": return new HttpError(504, "ai_timeout", "The AI took too long to respond. Try fewer formats or a shorter source.");
      default: return new HttpError(502, "ai_failed", "The AI provider returned an error. Please try again.");
    }
  }
  return new HttpError(500, "internal_error", "Something went wrong while generating. Your credits were refunded.");
}

// ───────────────────────────────────────────────────────────────────────────
async function handleGenerate(
  admin: SupabaseClient, userId: string, body: GenerateBody, cfg: ServerConfig, provider: AiProvider | null, demo: boolean,
) {
  const project = await loadProject(admin, userId, body.project_id);
  await assertNotBusy(admin, project.workspace_id);
  const platforms = [...new Set(body.platforms)] as PlatformId[];

  const job = await createJob(admin, { workspaceId: project.workspace_id, userId, projectId: project.id, kind: "generate", key: body.idempotency_key });

  const { data: gen, error: genErr } = await admin.from("generations").insert({
    project_id: project.id, workspace_id: project.workspace_id, created_by: userId,
    status: "pending", platforms, options: body.options, is_demo: demo,
  }).select("id").single();
  if (genErr || !gen) throw genErr ?? new Error("generation insert failed");
  await admin.from("generation_jobs").update({ generation_id: gen.id }).eq("id", job.id);

  let ledgerId: string | null = null;
  const fail_ = async (err: HttpError) => {
    if (ledgerId) await admin.rpc("refund_charge", { p_ledger_id: ledgerId, p_reason: "Refund: generation failed" });
    const now = new Date().toISOString();
    await admin.from("generations").update({ status: "failed", error: err.code, completed_at: now }).eq("id", gen.id);
    await admin.from("generation_jobs").update({ status: "failed", error: err.code, finished_at: now }).eq("id", job.id);
    const { count } = await admin.from("content_assets").select("id", { count: "exact", head: true }).eq("project_id", project.id);
    await admin.from("projects").update({ status: (count ?? 0) > 0 ? "ready" : "failed" }).eq("id", project.id);
    throw err;
  };

  try {
    const claimed = await admin.rpc("claim_generation_job", { p_job: job.id });
    if (!claimed.data) throw new HttpError(409, "duplicate_request", "This request is already being processed.");

    const source = await loadSource(admin, project, cfg);
    const brand = await loadBrand(admin, project.workspace_id, body.options.brand_id);
    const cost = demo ? 0 : generationCost(cfg, platforms.length, source.words);

    await admin.from("projects").update({ status: "generating" }).eq("id", project.id);
    await admin.from("generations").update({ status: "processing" }).eq("id", gen.id);

    let balance: number | null = null;
    if (cost > 0) {
      const c = await charge(admin, {
        workspaceId: project.workspace_id, userId, amount: cost, generationId: gen.id, platforms,
        reason: `Generation: ${platforms.length} format${platforms.length > 1 ? "s" : ""}`,
      });
      ledgerId = c.ledgerId;
      balance = c.balance;
      await admin.from("generation_jobs").update({ charge_ledger_id: ledgerId }).eq("id", job.id);
    }

    const options: GenOptions = {
      audience: body.options.audience, goal: body.options.goal, tone: body.options.tone,
      language: body.options.language, length: body.options.length, instructions: body.options.instructions,
    };

    let output: AiOutput;
    try {
      output = demo
        ? demoOutput(source.title, source.text, platforms)
        : await produce(provider!, { source: source.text, title: source.title, platforms, options, brand });
    } catch (e) {
      console.error("generation failed", e);
      throw friendlyAiError(e);
    }

    const rows = output.assets.map((a) => ({
      project_id: project.id, workspace_id: project.workspace_id, generation_id: gen.id,
      platform: a.platform, title: a.title, content: a.content,
      metadata: { hashtags: a.hashtags, hooks: a.hooks, ...(demo ? { demo: true } : {}) },
    }));
    const { error: insErr } = await admin.from("content_assets").insert(rows);
    if (insErr) { console.error("asset insert failed", insErr); throw new HttpError(500, "save_failed", "We generated your content but couldn't save it. Your credits were refunded."); }

    const now = new Date().toISOString();
    await admin.from("generations").update({
      status: "completed", analysis: output.analysis, credits_charged: cost, completed_at: now,
    }).eq("id", gen.id);
    await admin.from("generation_jobs").update({ status: "completed", finished_at: now }).eq("id", job.id);
    await admin.from("projects").update({ status: "ready" }).eq("id", project.id);

    return json({ ok: true, generation_id: gen.id, assets_count: rows.length, credits_charged: cost, balance, demo });
  } catch (e) {
    return await fail_(e instanceof HttpError ? e : friendlyAiError(e));
  }
}

async function handleRegenerate(
  admin: SupabaseClient, userId: string, body: RegenBody, cfg: ServerConfig, provider: AiProvider | null, demo: boolean,
) {
  const project = await loadProject(admin, userId, body.project_id);
  const { data: asset } = await admin.from("content_assets").select("*").eq("id", body.asset_id).eq("project_id", project.id).maybeSingle();
  if (!asset) throw new HttpError(404, "not_found", "Asset not found.");
  await assertNotBusy(admin, project.workspace_id);

  const job = await createJob(admin, { workspaceId: project.workspace_id, userId, projectId: project.id, kind: "regenerate", key: body.idempotency_key });
  await admin.from("generation_jobs").update({ generation_id: asset.generation_id }).eq("id", job.id);

  let ledgerId: string | null = null;
  const fail_ = async (err: HttpError) => {
    if (ledgerId) await admin.rpc("refund_charge", { p_ledger_id: ledgerId, p_reason: "Refund: regeneration failed" });
    await admin.from("generation_jobs").update({ status: "failed", error: err.code, finished_at: new Date().toISOString() }).eq("id", job.id);
    throw err;
  };

  try {
    const claimed = await admin.rpc("claim_generation_job", { p_job: job.id });
    if (!claimed.data) throw new HttpError(409, "duplicate_request", "This request is already being processed.");

    const source = await loadSource(admin, project, cfg);

    // Reuse the original generation's settings unless the caller overrides them
    let saved: Record<string, string> = {};
    if (asset.generation_id) {
      const { data: g } = await admin.from("generations").select("options").eq("id", asset.generation_id).maybeSingle();
      saved = (g?.options as Record<string, string>) ?? {};
    }
    const merged = { ...saved, ...(body.options ?? {}) } as Record<string, string | null | undefined>;
    const options: GenOptions = {
      audience: merged.audience ?? "", goal: merged.goal ?? "", tone: merged.tone ?? "Conversational",
      language: merged.language ?? "English", length: merged.length ?? "Medium", instructions: merged.instructions ?? "",
    };
    const brand = await loadBrand(admin, project.workspace_id, merged.brand_id);
    const cost = demo ? 0 : cfg.costs.regeneration;

    if (cost > 0) {
      const c = await charge(admin, {
        workspaceId: project.workspace_id, userId, amount: cost, generationId: asset.generation_id,
        platforms: [asset.platform], reason: "Regeneration",
      });
      ledgerId = c.ledgerId;
      await admin.from("generation_jobs").update({ charge_ledger_id: ledgerId }).eq("id", job.id);
    }

    let out: AiOutput;
    try {
      out = demo
        ? demoOutput(source.title, source.text, [asset.platform as PlatformId])
        : await produce(provider!, {
            source: source.text, title: source.title, platforms: [asset.platform as PlatformId], options, brand,
          });
    } catch (e) {
      console.error("regeneration failed", e);
      throw friendlyAiError(e);
    }
    const a = out.assets[0];

    await admin.from("generation_jobs").update({ status: "completed", finished_at: new Date().toISOString() }).eq("id", job.id);

    // Proposal only — nothing is overwritten until the user confirms in the UI.
    const { data: ws } = await admin.from("workspaces").select("credits").eq("id", project.workspace_id).maybeSingle();
    return json({
      ok: true, credits_charged: cost, balance: ws?.credits ?? null, demo,
      proposal: { title: a.title, content: a.content, metadata: { hashtags: a.hashtags, hooks: a.hooks, ...(demo ? { demo: true } : {}) } },
    });
  } catch (e) {
    return await fail_(e instanceof HttpError ? e : friendlyAiError(e));
  }
}

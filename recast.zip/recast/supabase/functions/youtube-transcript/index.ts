// Best-effort retrieval of PUBLICLY AVAILABLE captions for a YouTube video.
// This is not a video downloader: it never touches video/audio streams. If captions
// aren't accessible, it says so and the UI asks the user to paste or upload the transcript.
// For production reliability and ToS compliance, consider a licensed transcript provider
// or the official YouTube Data API for videos you own. Set YOUTUBE_TRANSCRIPTS_ENABLED=false to disable.

import { corsHeaders, fail, json } from "../_shared/cors.ts";
import { adminClient, getUser } from "../_shared/supabase.ts";

const ALLOWED_HOSTS = new Set(["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"]);

function extractVideoId(raw: string): string | null {
  let u: URL;
  try { u = new URL(raw.trim()); } catch { return null; }
  if (u.protocol !== "https:" && u.protocol !== "http:") return null;
  if (!ALLOWED_HOSTS.has(u.hostname.toLowerCase())) return null;
  let id: string | null = null;
  if (u.hostname === "youtu.be") id = u.pathname.slice(1).split("/")[0];
  else if (u.pathname === "/watch") id = u.searchParams.get("v");
  else if (u.pathname.startsWith("/shorts/") || u.pathname.startsWith("/embed/")) id = u.pathname.split("/")[2];
  return id && /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
}

async function fetchTitle(id: string): Promise<string | null> {
  try {
    const r = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${id}`)}&format=json`);
    if (!r.ok) return null;
    const j = await r.json();
    return typeof j.title === "string" ? j.title.slice(0, 200) : null;
  } catch { return null; }
}

interface CaptionTrack { baseUrl: string; languageCode: string; kind?: string; }

async function fetchCaptions(id: string): Promise<string | null> {
  const page = await fetch(`https://www.youtube.com/watch?v=${id}`, {
    headers: { "Accept-Language": "en-US,en;q=0.9", "User-Agent": "Mozilla/5.0 (compatible; RecastBot/1.0)" },
  });
  if (!page.ok) return null;
  const html = await page.text();
  const m = html.match(/"captionTracks":(\[.*?\])/);
  if (!m) return null;
  let tracks: CaptionTrack[];
  try { tracks = JSON.parse(m[1]); } catch { return null; }
  if (!tracks.length) return null;

  // Prefer manually-authored English, then any English, then the first track
  const pick =
    tracks.find((t) => t.languageCode?.startsWith("en") && t.kind !== "asr") ??
    tracks.find((t) => t.languageCode?.startsWith("en")) ??
    tracks[0];

  let trackUrl: URL;
  try { trackUrl = new URL(pick.baseUrl); } catch { return null; }
  // SSRF guard: only follow caption URLs on YouTube's own domain
  if (!/(^|\.)youtube\.com$/i.test(trackUrl.hostname)) return null;
  trackUrl.searchParams.set("fmt", "json3");

  const r = await fetch(trackUrl.toString());
  if (!r.ok) return null;
  let data: { events?: { segs?: { utf8?: string }[] }[] };
  try { data = await r.json(); } catch { return null; }
  const text = (data.events ?? [])
    .flatMap((e) => (e.segs ?? []).map((s) => s.utf8 ?? ""))
    .join("")
    .replace(/\n+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return text || null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return fail(405, "method_not_allowed", "Use POST.");

  const admin = adminClient();
  const user = await getUser(req, admin);
  if (!user) return fail(401, "unauthorized", "Please sign in again.");

  if ((Deno.env.get("YOUTUBE_TRANSCRIPTS_ENABLED") ?? "true").toLowerCase() === "false") {
    return fail(503, "disabled", "YouTube transcript lookup is disabled. Please paste or upload the transcript instead.");
  }

  let url = "";
  try { url = String((await req.json()).url ?? ""); } catch { return fail(400, "invalid_request", "Send JSON with a url."); }
  const id = extractVideoId(url);
  if (!id) return fail(400, "invalid_url", "That doesn't look like a valid YouTube link.");

  try {
    const [title, transcript] = await Promise.all([fetchTitle(id), fetchCaptions(id)]);
    if (!transcript) {
      return fail(404, "no_captions", "We couldn't access captions for this video. Please paste the transcript or upload it as a file instead.");
    }
    return json({ ok: true, video_id: id, title, transcript, source: "public_captions" });
  } catch (e) {
    console.error("youtube-transcript failed", e);
    return fail(502, "lookup_failed", "We couldn't fetch captions right now. Please paste the transcript instead.");
  }
});

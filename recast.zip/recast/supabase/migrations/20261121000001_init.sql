-- RECAST — initial schema, RLS, atomic credit functions, storage policies.
-- Run with: supabase db push   (or paste into the Supabase SQL editor)

-- ───────────────────────────────────────────────────────────────────────────
-- Helpers
-- ───────────────────────────────────────────────────────────────────────────
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ───────────────────────────────────────────────────────────────────────────
-- Server-side configuration (credit costs, limits). Read-only for clients.
-- ───────────────────────────────────────────────────────────────────────────
create table public.app_config (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

insert into public.app_config (key, value) values
  ('credit_costs', '{"basic":1,"multi":3,"long_transcript":5,"regeneration":1}'),
  ('limits', '{"free_plan_credits":10,"long_source_words":3000,"max_source_words":20000,"max_file_mb":10}'),
  ('plan_credits', '{"free":10,"creator":150,"pro":400,"agency":1500}');

-- ───────────────────────────────────────────────────────────────────────────
-- Core tables
-- ───────────────────────────────────────────────────────────────────────────
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text check (full_name is null or char_length(full_name) <= 120),
  avatar_url text,
  use_case text check (use_case is null or use_case in ('creator','freelancer','agency','business','other')),
  onboarded boolean not null default false,
  default_workspace_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  owner_id uuid not null references auth.users(id) on delete cascade,
  plan text not null default 'free' check (plan in ('free','creator','pro','agency')),
  credits integer not null default 0 check (credits >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index workspaces_owner_idx on public.workspaces(owner_id);

alter table public.profiles
  add constraint profiles_default_workspace_fk
  foreign key (default_workspace_id) references public.workspaces(id) on delete set null;

create table public.workspace_members (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','editor','viewer')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (workspace_id, user_id)
);
create index workspace_members_user_idx on public.workspace_members(user_id);

create table public.brands (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  description text check (description is null or char_length(description) <= 2000),
  target_audience text check (target_audience is null or char_length(target_audience) <= 500),
  preferred_tone text check (preferred_tone is null or char_length(preferred_tone) <= 80),
  writing_style text check (writing_style is null or char_length(writing_style) <= 1000),
  words_to_use text[] not null default '{}',
  words_to_avoid text[] not null default '{}',
  instructions text check (instructions is null or char_length(instructions) <= 2000),
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index brands_workspace_idx on public.brands(workspace_id);
create unique index brands_one_default_per_ws on public.brands(workspace_id) where is_default;

create table public.projects (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 200),
  source_type text not null check (source_type in ('text','file','youtube')),
  status text not null default 'draft' check (status in ('draft','generating','ready','failed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index projects_workspace_created_idx on public.projects(workspace_id, created_at desc);

create table public.source_contents (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  source_type text not null check (source_type in ('text','file','youtube')),
  title text check (title is null or char_length(title) <= 200),
  text_content text check (text_content is null or char_length(text_content) <= 300000),
  file_path text,
  file_name text,
  youtube_url text check (youtube_url is null or char_length(youtube_url) <= 500),
  word_count integer not null default 0 check (word_count >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index source_contents_project_idx on public.source_contents(project_id);
create index source_contents_workspace_idx on public.source_contents(workspace_id);

create table public.generations (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','processing','completed','failed')),
  platforms text[] not null default '{}',
  options jsonb not null default '{}',
  analysis jsonb,
  credits_charged integer not null default 0 check (credits_charged >= 0),
  is_demo boolean not null default false,
  error text,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
create index generations_project_idx on public.generations(project_id);
create index generations_workspace_created_idx on public.generations(workspace_id, created_at desc);

create table public.content_assets (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  generation_id uuid references public.generations(id) on delete set null,
  platform text not null check (platform in (
    'instagram_reels','youtube_shorts','linkedin_post','instagram_carousel','x_thread','blog_article','captions')),
  title text check (title is null or char_length(title) <= 300),
  content text not null check (char_length(content) <= 100000),
  metadata jsonb not null default '{}',
  status text not null default 'draft' check (status in ('draft','final')),
  version integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index content_assets_project_idx on public.content_assets(project_id);
create index content_assets_workspace_platform_idx on public.content_assets(workspace_id, platform);
create index content_assets_workspace_created_idx on public.content_assets(workspace_id, created_at desc);

create table public.usage_ledger (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  kind text not null check (kind in ('grant','deduction','refund')),
  amount integer not null check (amount > 0),
  balance_after integer not null check (balance_after >= 0),
  reason text,
  generation_id uuid references public.generations(id) on delete set null,
  platforms text[] not null default '{}',
  refund_of uuid unique references public.usage_ledger(id),
  created_at timestamptz not null default now()
);
create index usage_ledger_workspace_created_idx on public.usage_ledger(workspace_id, created_at desc);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null unique references public.workspaces(id) on delete cascade,
  plan text not null default 'free' check (plan in ('free','creator','pro','agency')),
  status text not null default 'active' check (status in ('inactive','active','past_due','canceled')),
  provider text,
  provider_subscription_id text,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  subscription_id uuid references public.subscriptions(id) on delete set null,
  amount_inr integer not null check (amount_inr >= 0),
  currency text not null default 'INR',
  status text not null check (status in ('pending','succeeded','failed','refunded')),
  provider text,
  provider_payment_id text,
  created_at timestamptz not null default now()
);
create index payments_workspace_idx on public.payments(workspace_id);

create table public.generation_jobs (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  project_id uuid references public.projects(id) on delete cascade,
  generation_id uuid references public.generations(id) on delete set null,
  kind text not null default 'generate' check (kind in ('generate','regenerate')),
  idempotency_key uuid not null,
  status text not null default 'queued' check (status in ('queued','processing','completed','failed')),
  attempts integer not null default 0,
  charge_ledger_id uuid references public.usage_ledger(id) on delete set null,
  error text,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  finished_at timestamptz,
  unique (workspace_id, idempotency_key)
);
create index generation_jobs_workspace_status_idx on public.generation_jobs(workspace_id, status);

-- Planning calendar (MVP: planning only — no auto-publishing)
create table public.calendar_items (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete cascade,
  asset_id uuid references public.content_assets(id) on delete set null,
  title text not null check (char_length(title) between 1 and 200),
  platform text not null check (platform in ('Instagram','YouTube','LinkedIn','X','Blog','Social')),
  scheduled_for date not null,
  notes text check (notes is null or char_length(notes) <= 2000),
  status text not null default 'planned' check (status in ('planned','done')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index calendar_items_ws_date_idx on public.calendar_items(workspace_id, scheduled_for);

-- updated_at triggers
create trigger trg_profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();
create trigger trg_workspaces_touch before update on public.workspaces for each row execute function public.touch_updated_at();
create trigger trg_members_touch before update on public.workspace_members for each row execute function public.touch_updated_at();
create trigger trg_brands_touch before update on public.brands for each row execute function public.touch_updated_at();
create trigger trg_projects_touch before update on public.projects for each row execute function public.touch_updated_at();
create trigger trg_sources_touch before update on public.source_contents for each row execute function public.touch_updated_at();
create trigger trg_assets_touch before update on public.content_assets for each row execute function public.touch_updated_at();
create trigger trg_subs_touch before update on public.subscriptions for each row execute function public.touch_updated_at();
create trigger trg_calendar_touch before update on public.calendar_items for each row execute function public.touch_updated_at();

-- bump asset version whenever its text is edited
create or replace function public.bump_asset_version()
returns trigger language plpgsql as $$
begin
  if new.content is distinct from old.content or new.title is distinct from old.title then
    new.version = old.version + 1;
  end if;
  return new;
end $$;
create trigger trg_assets_version before update on public.content_assets for each row execute function public.bump_asset_version();

-- ───────────────────────────────────────────────────────────────────────────
-- Authorization helpers (SECURITY DEFINER avoids RLS recursion on members)
-- ───────────────────────────────────────────────────────────────────────────
create or replace function public.is_workspace_member(ws uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.workspace_members m where m.workspace_id = ws and m.user_id = auth.uid()
  );
$$;

create or replace function public.has_workspace_role(ws uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.workspace_members m
    where m.workspace_id = ws and m.user_id = auth.uid() and m.role = any(roles)
  );
$$;

create or replace function public.safe_uuid(t text)
returns uuid language plpgsql immutable as $$
begin
  return t::uuid;
exception when others then
  return null;
end $$;

-- ───────────────────────────────────────────────────────────────────────────
-- New-user bootstrap: profile + personal workspace + starter credits
-- ───────────────────────────────────────────────────────────────────────────
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  ws uuid;
  free_credits integer;
  display text;
begin
  select coalesce((value->>'free_plan_credits')::int, 10) into free_credits
  from public.app_config where key = 'limits';
  free_credits := coalesce(free_credits, 10);

  display := nullif(btrim(coalesce(new.raw_user_meta_data->>'full_name', '')), '');
  display := left(coalesce(display, split_part(coalesce(new.email, 'user'), '@', 1)), 60);

  insert into public.profiles (id, full_name) values (new.id, display);

  insert into public.workspaces (name, owner_id, plan, credits)
  values (display || '''s Workspace', new.id, 'free', free_credits)
  returning id into ws;

  insert into public.workspace_members (workspace_id, user_id, role) values (ws, new.id, 'owner');
  insert into public.subscriptions (workspace_id, plan, status) values (ws, 'free', 'active');

  if free_credits > 0 then
    insert into public.usage_ledger (workspace_id, user_id, kind, amount, balance_after, reason)
    values (ws, new.id, 'grant', free_credits, free_credits, 'Free plan starter credits');
  end if;

  update public.profiles set default_workspace_id = ws where id = new.id;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Additional workspaces (e.g. one per client). They start with 0 credits so the
-- free allowance cannot be farmed by creating workspaces.
create or replace function public.create_workspace(p_name text)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  ws uuid;
  n integer;
  nm text := btrim(coalesce(p_name, ''));
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if char_length(nm) < 1 or char_length(nm) > 80 then raise exception 'invalid_name'; end if;
  select count(*) into n from public.workspaces where owner_id = auth.uid();
  if n >= 5 then raise exception 'workspace_limit'; end if;

  insert into public.workspaces (name, owner_id, plan, credits) values (nm, auth.uid(), 'free', 0)
  returning id into ws;
  insert into public.workspace_members (workspace_id, user_id, role) values (ws, auth.uid(), 'owner');
  insert into public.subscriptions (workspace_id, plan, status) values (ws, 'free', 'active');
  return ws;
end $$;
revoke all on function public.create_workspace(text) from public, anon;
grant execute on function public.create_workspace(text) to authenticated;

-- ───────────────────────────────────────────────────────────────────────────
-- Atomic credit functions — callable ONLY by the service role (Edge Functions)
-- ───────────────────────────────────────────────────────────────────────────
create or replace function public.charge_credits(
  p_workspace uuid, p_user uuid, p_amount integer, p_reason text, p_generation uuid, p_platforms text[]
) returns table (out_ledger_id uuid, out_balance integer)
language plpgsql security definer set search_path = public as $$
declare
  bal integer;
  lid uuid;
begin
  if p_amount is null or p_amount <= 0 then raise exception 'invalid_amount'; end if;

  select credits into bal from public.workspaces where id = p_workspace for update;
  if bal is null then raise exception 'workspace_not_found'; end if;
  if bal < p_amount then raise exception 'insufficient_credits'; end if;

  update public.workspaces set credits = credits - p_amount where id = p_workspace
  returning credits into bal;

  insert into public.usage_ledger (workspace_id, user_id, kind, amount, balance_after, reason, generation_id, platforms)
  values (p_workspace, p_user, 'deduction', p_amount, bal, p_reason, p_generation, coalesce(p_platforms, '{}'))
  returning id into lid;

  return query select lid, bal;
end $$;

create or replace function public.refund_charge(p_ledger_id uuid, p_reason text)
returns table (out_balance integer, out_refunded boolean)
language plpgsql security definer set search_path = public as $$
declare
  l public.usage_ledger%rowtype;
  bal integer;
begin
  select * into l from public.usage_ledger where id = p_ledger_id and kind = 'deduction';
  if not found then raise exception 'ledger_not_found'; end if;

  perform 1 from public.workspaces where id = l.workspace_id for update;

  if exists (select 1 from public.usage_ledger where refund_of = p_ledger_id) then
    select credits into bal from public.workspaces where id = l.workspace_id;
    return query select bal, false;
    return;
  end if;

  update public.workspaces set credits = credits + l.amount where id = l.workspace_id
  returning credits into bal;

  insert into public.usage_ledger (workspace_id, user_id, kind, amount, balance_after, reason, generation_id, platforms, refund_of)
  values (l.workspace_id, l.user_id, 'refund', l.amount, bal, p_reason, l.generation_id, l.platforms, l.id);

  return query select bal, true;
end $$;

-- Atomically claim a queued job so it can only be processed once.
create or replace function public.claim_generation_job(p_job uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  update public.generation_jobs
     set status = 'processing', started_at = now(), attempts = attempts + 1
   where id = p_job and status = 'queued';
  get diagnostics n = row_count;
  return n = 1;
end $$;

revoke all on function public.charge_credits(uuid, uuid, integer, text, uuid, text[]) from public, anon, authenticated;
revoke all on function public.refund_charge(uuid, text) from public, anon, authenticated;
revoke all on function public.claim_generation_job(uuid) from public, anon, authenticated;
grant execute on function public.charge_credits(uuid, uuid, integer, text, uuid, text[]) to service_role;
grant execute on function public.refund_charge(uuid, text) to service_role;
grant execute on function public.claim_generation_job(uuid) to service_role;

-- ───────────────────────────────────────────────────────────────────────────
-- Row Level Security
-- ───────────────────────────────────────────────────────────────────────────
alter table public.app_config enable row level security;
alter table public.profiles enable row level security;
alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.brands enable row level security;
alter table public.projects enable row level security;
alter table public.source_contents enable row level security;
alter table public.generations enable row level security;
alter table public.content_assets enable row level security;
alter table public.usage_ledger enable row level security;
alter table public.subscriptions enable row level security;
alter table public.payments enable row level security;
alter table public.generation_jobs enable row level security;
alter table public.calendar_items enable row level security;

-- app_config: readable by signed-in users, writable only by service role
create policy app_config_read on public.app_config for select to authenticated using (true);

-- profiles: own row only
create policy profiles_select_own on public.profiles for select to authenticated using (id = auth.uid());
create policy profiles_update_own on public.profiles for update to authenticated
  using (id = auth.uid())
  with check (id = auth.uid() and (default_workspace_id is null or public.is_workspace_member(default_workspace_id)));

-- workspaces: members read; owner/admin rename. Credits/plan are server-controlled.
create policy workspaces_select_member on public.workspaces for select to authenticated
  using (public.is_workspace_member(id));
create policy workspaces_update_admin on public.workspaces for update to authenticated
  using (public.has_workspace_role(id, array['owner','admin']))
  with check (public.has_workspace_role(id, array['owner','admin']));

-- members: see co-members; owner/admin manage non-owner rows
create policy members_select on public.workspace_members for select to authenticated
  using (public.is_workspace_member(workspace_id));
create policy members_insert on public.workspace_members for insert to authenticated
  with check (public.has_workspace_role(workspace_id, array['owner','admin']) and role <> 'owner');
create policy members_update on public.workspace_members for update to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin']) and role <> 'owner')
  with check (public.has_workspace_role(workspace_id, array['owner','admin']) and role <> 'owner');
create policy members_delete on public.workspace_members for delete to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin']) and role <> 'owner');

-- brands
create policy brands_select on public.brands for select to authenticated using (public.is_workspace_member(workspace_id));
create policy brands_insert on public.brands for insert to authenticated
  with check (public.has_workspace_role(workspace_id, array['owner','admin','editor']) and created_by = auth.uid());
create policy brands_update on public.brands for update to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin','editor']))
  with check (public.has_workspace_role(workspace_id, array['owner','admin','editor']));
create policy brands_delete on public.brands for delete to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin','editor']));

-- projects
create policy projects_select on public.projects for select to authenticated using (public.is_workspace_member(workspace_id));
create policy projects_insert on public.projects for insert to authenticated
  with check (public.has_workspace_role(workspace_id, array['owner','admin','editor']) and created_by = auth.uid());
create policy projects_update on public.projects for update to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin','editor']))
  with check (public.has_workspace_role(workspace_id, array['owner','admin','editor']));
create policy projects_delete on public.projects for delete to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin','editor']));

-- source_contents (workspace_id must match the parent project's workspace)
create policy sources_select on public.source_contents for select to authenticated using (public.is_workspace_member(workspace_id));
create policy sources_insert on public.source_contents for insert to authenticated
  with check (
    public.has_workspace_role(workspace_id, array['owner','admin','editor'])
    and exists (select 1 from public.projects p where p.id = project_id and p.workspace_id = source_contents.workspace_id)
  );
create policy sources_delete on public.source_contents for delete to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin','editor']));

-- generations / jobs / ledger / subscriptions / payments: read-only for clients
create policy generations_select on public.generations for select to authenticated using (public.is_workspace_member(workspace_id));
create policy jobs_select on public.generation_jobs for select to authenticated using (public.is_workspace_member(workspace_id));
create policy ledger_select on public.usage_ledger for select to authenticated using (public.is_workspace_member(workspace_id));
create policy subs_select on public.subscriptions for select to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin']));
create policy payments_select on public.payments for select to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin']));

-- content_assets: created by the server; editors may edit text/status or delete
create policy assets_select on public.content_assets for select to authenticated using (public.is_workspace_member(workspace_id));
create policy assets_update on public.content_assets for update to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin','editor']))
  with check (public.has_workspace_role(workspace_id, array['owner','admin','editor']));
create policy assets_delete on public.content_assets for delete to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin','editor']));

-- calendar
create policy cal_select on public.calendar_items for select to authenticated using (public.is_workspace_member(workspace_id));
create policy cal_insert on public.calendar_items for insert to authenticated
  with check (
    public.has_workspace_role(workspace_id, array['owner','admin','editor']) and created_by = auth.uid()
    and (asset_id is null or exists (select 1 from public.content_assets a where a.id = asset_id and a.workspace_id = calendar_items.workspace_id))
  );
create policy cal_update on public.calendar_items for update to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin','editor']))
  with check (
    public.has_workspace_role(workspace_id, array['owner','admin','editor'])
    and (asset_id is null or exists (select 1 from public.content_assets a where a.id = asset_id and a.workspace_id = calendar_items.workspace_id))
  );
create policy cal_delete on public.calendar_items for delete to authenticated
  using (public.has_workspace_role(workspace_id, array['owner','admin','editor']));

-- ───────────────────────────────────────────────────────────────────────────
-- Table privileges (defence in depth on top of RLS)
-- ───────────────────────────────────────────────────────────────────────────
revoke all on all tables in schema public from anon;

-- server-controlled tables: clients may only read
revoke insert, update, delete on public.generations, public.generation_jobs, public.usage_ledger,
  public.subscriptions, public.payments, public.app_config from authenticated;

-- workspaces: no client inserts/deletes; only the name is editable (never credits/plan/owner)
revoke insert, update, delete on public.workspaces from authenticated;
grant update (name) on public.workspaces to authenticated;

-- profiles: no client inserts/deletes; limited editable columns
revoke insert, update, delete on public.profiles from authenticated;
grant update (full_name, avatar_url, use_case, onboarded, default_workspace_id) on public.profiles to authenticated;

-- projects: clients may rename only; status is server-managed
revoke update on public.projects from authenticated;
grant update (title) on public.projects to authenticated;

-- content_assets: clients cannot insert; may edit only text/status/metadata
revoke insert, update on public.content_assets from authenticated;
grant update (title, content, status, metadata) on public.content_assets to authenticated;

-- brands / calendar: restrict immutable columns
revoke update on public.brands from authenticated;
grant update (name, description, target_audience, preferred_tone, writing_style, words_to_use,
              words_to_avoid, instructions, is_default) on public.brands to authenticated;
revoke update on public.calendar_items from authenticated;
grant update (asset_id, title, platform, scheduled_for, notes, status) on public.calendar_items to authenticated;

-- membership rows: role changes only
revoke update on public.workspace_members from authenticated;
grant update (role) on public.workspace_members to authenticated;

-- ───────────────────────────────────────────────────────────────────────────
-- Private storage for uploaded sources. Path convention: {workspace_id}/{project_id}/{file}
-- ───────────────────────────────────────────────────────────────────────────
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('sources', 'sources', false, 10485760, array['application/pdf','text/plain'])
on conflict (id) do update
  set public = false, file_size_limit = 10485760, allowed_mime_types = array['application/pdf','text/plain'];

create policy sources_obj_select on storage.objects for select to authenticated
  using (bucket_id = 'sources'
         and public.safe_uuid((storage.foldername(name))[1]) is not null
         and public.is_workspace_member(public.safe_uuid((storage.foldername(name))[1])));
create policy sources_obj_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'sources'
         and public.safe_uuid((storage.foldername(name))[1]) is not null
         and public.has_workspace_role(public.safe_uuid((storage.foldername(name))[1]), array['owner','admin','editor']));
create policy sources_obj_delete on storage.objects for delete to authenticated
  using (bucket_id = 'sources'
         and public.safe_uuid((storage.foldername(name))[1]) is not null
         and public.has_workspace_role(public.safe_uuid((storage.foldername(name))[1]), array['owner','admin','editor']));
